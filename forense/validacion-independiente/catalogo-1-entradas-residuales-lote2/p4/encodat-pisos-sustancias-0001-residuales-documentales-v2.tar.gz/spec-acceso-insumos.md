# Insumos y separación de la sesión

Solo una sesión nueva sin historial recibirá estos documentos; este contenedor no autoriza ejecución ni apertura de datos por sí mismo. Una misión de recálculo debe autorizar las olas abiertas y firmar los contratos propuestos antes de iniciar. No abrir resultados, productores, dictámenes ni material exterior; retornar únicamente salida propia según esquema y sellarla antes de comparar.

Payload `encodat_2016_2017__encodat_2016_2017_hogar_stata_stata_zip`; archivo `ENCODAT/2016-2017/Bases de datos de ENCODAT 2016 2017/01-Cuestionario de Hogar/01-Información sobre el hogar/ENCODAT_2016_2017_Hogar.stata.stata.zip`; SHA256 `716f58f817f3203ec2cba8d265d8812d3015bb9ffdb56a39ff50bd3ce1d0d781`.

Payload `encodat_2016_2017__encodat_2016_2017_individual_stata_stata_zip`; archivo `ENCODAT/2016-2017/Bases de datos de ENCODAT 2016 2017/02-Cuestionario individual/ENCODAT_2016_2017_Individual.stata.stata.zip`; SHA256 `bb0c7d999e45bebcffb3a26da00bd2d5caa2d982de7d9e330211c11960153346`.

