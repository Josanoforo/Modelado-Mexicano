# Método: extracción fiel de especificación humana

## Qué mide

**Dos constructos, un payload.**

## Unidad de observación — declarada, porque cambia el denominador

| universo | unidad | tabla | filtro | ponderador |
|---|---|---|---|---|
| **`U_A` (punto de A)** | persona seleccionada | `SEC_4_5` | contacto `AP5_16_k = 1` para algún `k` · `AP5_17 ∈ {1,2}` · `AP5_18 ∈ {1,2}` | `FAC_SEL` |
| `U_A_POB` (secundario) | persona seleccionada | `SEC_4_5` | sólo `FAC_SEL` válido; «sin contacto» cuenta como `0` | `FAC_SEL` |
| **`U_B` (punto de B)** | persona seleccionada | `SEC_6_7_8` ⨝ `SEC_4_5` por `ID_PER` | `AP7_3_5 ∈ {1,2}` · `AP4_3_2 ∈ {1,2}` · `DOMINIO ∈ {U,C,R}` | `FAC_SEL` |

`9` (NS/NR) y blanco **salen contados**, jamás imputados a `0`.

**Familia B:** `d = 1` si `AP7_3_5 = 1`, `0` si `= 2`. Eje congelado:
`urbano = {U, C}` (el descriptor llama a `C` «**Complemento urbano**»),
`rural = {R}`; la agrupación alternativa `{U}` vs `{R,C}` se emite como
**sensibilidad declarada**, no adoptable.

**Escala:** proporción en `[0,1]`. Nunca porcentaje, nunca puntos
porcentuales. Más alto = más mordida (A) / más protesta (B).

## Tipos: manda el header del DBF, no el descriptor

`AP5_16_*` y `AP4_3_2` son **`N` 19,15** (el texto crudo llega
`1.000000000000000`); `AP5_17`/`AP5_18` son **`C` 6**; `AP7_3_5` es **`C` 7**;
`FAC_SEL` es **`N` 19,10** y **no se normaliza**; `EST_DIS`/`UPM_DIS` son
**llaves opacas de texto** (el descriptor dice ancho 3 para `EST_DIS`; el DBF
dice 7). `_cod()` normaliza `'1'` y `'1.000000000000000'` al mismo entero, y la
guardia `G-3` **mide** la trampa emitiendo los dos conteos.

## Incertidumbre de diseño

## Guardias que PARAN (no arreglan)

`NO-ESTIMABLE-MIEMBRO-AUSENTE:<m>` · `NO-ESTIMABLE-COLUMNA-AUSENTE:<col>` ·
`NO-ESTIMABLE-COLUMNA-VACIA:<col>` · `NO-ESTIMABLE-UNIVERSO-VACIO` ·
`NO-ESTIMABLE-LLAVE-NO-UNICA` · `NO-ESTIMABLE-DISENO-INCOMPLETO`.
