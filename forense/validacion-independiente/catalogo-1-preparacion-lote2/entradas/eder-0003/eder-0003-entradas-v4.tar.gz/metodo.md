# Método humano

## Qué mide

| familia | unidad | archivos | desenlace | ponderador |
|---|---|---|---|---|
| **A** · tipo de primera unión | **PERSONA** | `historiavida.csv` × `antecedentes.csv` × `vivienda.csv` | primer `edo_civil1` no-cero en orden de `anio_retro` | `factor_per` |
| **B** · eje de cohorte | persona | idem | idem por tramo de `anio_nac` | `factor_per` |

**El desenlace, el ponderador y el diseño viven en tres archivos distintos**
(`A.15(c)`): `edo_civil1` en `historiavida.csv`, `factor_per` en
`antecedentes.csv`, `est_dis`/`upm` en `vivienda.csv`.

| rama | códigos | qué son |
|---|---|---|
| **`LIBRE`** | `{1, 12, 13, 14, 17, 18, 126}` | inicio de unión libre, **y** las transiciones *«posterior a inicio de unión libre»* — el código confirma que la unión empezó como libre aunque la fila de inicio esté censurada por el borde del panel |
| **`DIRECTO`** | `{2, 3, 4, 26, 27, 28, 46, 47, 48}` | matrimonio civil / religioso / ambos, inicio o transición |

Los códigos se leen **como cadena cruda** (`dtype=str`): `'1'` y `'1.0'` no
son el mismo texto y `pandas` produce uno u otro según el `dtype` inferido.
`G-VEREDICTO-TIPO-CODIGO` lo declara antes de usar el mapa.

---


Personas de EDER 2017 (unidad: persona de 20 a 54 años, FD §1.1.2) con al
menos un `edo_civil1` distinto de `0` en `historiavida.csv`. El **primer**
código no-cero por persona, en orden ascendente de `anio_retro`, es el
desenlace. Entran las que además tienen `factor_per` finito y `> 0` en
`antecedentes.csv`.


`A-P-LIBRE` = `Σ(w·d)/Σ(w)` sobre el universo, con `w = factor_per` y
`d = 1[edo_civil1 ∈ LIBRE]`. `A-P-DIRECTO` se **cuenta directamente** sobre
`d = 1[edo_civil1 ∈ DIRECTO]` — **nunca** `1 − A-P-LIBRE`, porque el código
`37` está fuera de las dos ramas y el complemento lo borraría.
`A-SUMA-LIBRE-DIRECTO-MAS-SIN-CLASIFICAR` cierra la partición y sale como
`RESULT`. **DESCRIPTIVO**; ningún `RESULT` es causal.


Bootstrap de `upm` con reemplazo **dentro de**
`est_dis`, conservando el número de UPM por estrato, 2 000 réplicas,
`numpy.PCG64`, semilla `20260915`, percentiles 2.5/97.5. `est_dis`/`upm` como
**cadena cruda opaca**. Estrato con UPM única se re-muestrea a sí mismo,
**no se colapsa ni se descarta**; si el conteo es `> 0`, `A-METODO-IC` sale
`IC-CON-ESTRATOS-DE-UPM-UNICA` y el IC se lee como **límite inferior** de la
anchura verdadera. 
`B-*`: cohorte de nacimiento (`anio_nac`) en cuatro tramos
(`≤1970`, `1971-1980`, `1981-1990`, `1991+`), **descriptivo**, con su propio
IC de diseño por celda. 