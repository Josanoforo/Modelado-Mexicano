# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2016-PAREJA-FISICA-0002 · preregistro





El primer resultado que produzca este procedimiento es el que se reporta. V1 (0001) falló sin sello porque usó `ID_PER` en lugar de la llave `ID_MUJ` documentada para 2016. Esta V2 cambia solo la llave de unión y conserva estimando, reactivos y diseño. GEN2 descriptivo retrospectivo; ninguna cifra GEN1 es input. Unidad: mujer de 15+ con cuestionario A1 (pareja residente) o A2 (pareja temporalmente ausente) en ENDIREH 2016, pareja actual. Subcomponente físico, no el agregado de cualquier violencia.





La pregunta 13.1 «Desde que inició la relación con su esposo o pareja» contiene los nueve actos físicos `P13_1_1` empujar/jalar cabello, `_2` abofetear/cachetear, `_3` amarrar, `_4` patear, `_5` aventar objeto, `_6` golpear con puño u objeto, `_7` ahorcar/asfixiar, `_8` agredir con cuchillo/navaja y `_9` disparar arma de fuego. La pregunta 13.3 con los mismos nueve actos `P13_3_1`…`P13_3_9` usa la ventana exacta «De octubre de 2015 a la fecha». Ambas acaban en entrevista de 2016. Cada reactivo 1=muchas veces, 2=pocas veces, 3=una vez, 4=no ocurrió, 9=no especificado, blanco/salto=no observado. Unión vale 1 si cualquier 1–3, 0 solo si los nueve son 4, desconocido en otro caso. Si 13.1=4 un acto reciente se codifica 4 por salto; si unión 13.1 desconocida, unión reciente desconocida. Nunca suma prevalencias.





Módulo `TB_SEC_XIII.csv`; TSDem por `ID_MUJ` para edad `EDAD` y nivel `NIV`; factor `FAC_MUJ`, estrato `EST_DIS`, conglomerado `UPM_DIS` del módulo XIII. Factor positivo, edad 15–120, A1/A2. Ejes univariados nacional, edad 15–29/30–44/45–59/60+, escolaridad 0 ninguno, 1–3/5–6 básica, 4/7–8 media superior/técnica, 9–11 superior, localidad `DOMINIO` U/C/R, A1/A2 y entidad 01–32. No cruces, municipio ni inferencia individual. Cada celda exige n de respuesta conocida ≥100, ≥5 UPM con casos, ancho IC≤0.20 y CV≤0.30 si p>0; se suprime si falla. Se remuestrean todas las UPM A1/A2 por estrato, incluyendo aporte cero de las que no tienen casos del dominio; 500 réplicas, semilla 20260923, IC percentil 2.5/97.5. Singleton autorremuestreado aporta varianza cero. Réplicas agregadas conservadas sin identificadores.





Fuente `endireh_2016_bd_mujeres_endireh2016_sitioinegi_csv` SHA256 recalculado `02c06ab73a53942ddb575e3e35d8c1dd775406277b74e0605735e3eced4e6f10`. FD del ZIP `fd_endireh2016_dbf.pdf` SHA256 `d6b1805e4e0eae0d12df5acd834e4913e59e56dcc101d80d1036535e8c3f1cba`. La comparación con 2021 se limita a población A1/A2 y actos homólogos, sin llamar a una diferencia cambio social. Si hay correspondencia de ventana, 2016 y 2021 son dos observaciones, insuficientes para calibrar IC predictivo temporal.
