# Método: extracción fiel de especificación humana

## Qué mide

**Dos estimandos sobre la misma lectura del mismo archivo**, cada uno con su escala declarada:

**`U_R` y `U1` no se comparan entre sí** (`A-bis.4`): están en la misma corrida porque salen de
la misma lectura, no porque sean comparables.

## Identidad del insumo

| campo | valor |
|---|---|
| `id` de manifiesto | **`envipe2021_csv`** — resuelto por `tests/payload_resolver.py`, nunca por heurística |
| miembro | `conjunto_de_datos_TMod_Vic_ENVIPE_2021/conjunto_de_datos/conjunto_de_datos_TMod_Vic_ENVIPE_2021.csv` |
| `Identifier` (metadato) | `DDI-MEX-INEGI-ENVIPE-2021-V01` |
| `Temporal` (metadato) | `2020-01-01-2020-12-31` → **delitos de 2020** |
| catálogo `bp1_23` | leído en **latin-1** (la codificación se prueba por archivo, no por ZIP) |

**Nota de esta ola:** el catalogo y el descriptor de esta ola NO declaran el codigo b (blanco); 2023 y 2024 si. El tratamiento del blanco es identico en las tres.
**Redacción del reactivo en esta ola:** 'ante el Ministerio Publico' (sin 'o Fiscalia Estatal'); 'Por miedo al agresor' — ninguna de esas diferencias mueve un código.

## Diseño

`EST_DIS` y `UPM_DIS` se agrupan como **cadenas opacas** (nunca `int()`, nunca `zfill()`). El
descriptor de esta ola declara `EST_DIS Numerico(3), 001..303 SEGUN DESCRIPTOR` y `UPM_DIS Numerico(5), 00001..99999 SEGUN DESCRIPTOR`; el perfil **real**
se emite en `RESULT-R-CIV-M-10-PERFIL-DISENO`, porque el descriptor ya mintió sobre esto en la
ola 2025. `EE` e `IC95` por conglomerado último con `tests/svystat.py:prop_ultimate_cluster`,
**importado y no reimplementado**. Un estrato con una sola UPM entra al punto, aporta varianza
cero, y su conteo va en `N-ESTRATOS-UPM-UNICA`; si es `> 0`, el IC es **límite inferior** de la
anchura verdadera.
