# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2021-DECISIONES-0001 · preregistro





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo. No usar números GEN1 ni inferir rasgos psicológicos, dependencia o control coercitivo desde un solo ítem. La situación económica propia y la decisión sobre gasto son constructos separados.





Universo: mujeres de 15 años o más entrevistadas con cuestionario A1/A2 ENDIREH 2021, pareja actual; unidad mujer. En `TB_SEC_IV.csv`, 4.11 `P4_11`: «¿Usted cuenta con dinero que puede utilizar como quiera?», 1 sí, 2 no. En `TB_SEC_XV.csv`, 15.1 `P15_1AB_3`: «qué hacer con el dinero que usted gana o del que dispone?» y `P15_1AB_7`: «cómo se gasta o economiza el dinero?». Códigos para ambos: 1 solo usted; 2 solo esposo/pareja; 3 entre ambos pero él un poco más; 4 entre ambos pero usted un poco más; 5 entre ambos por igual; 6 otras personas; 7 no aplica; blanco no respuesta. Resultado `decide_*_ella` = 1 para 1/4/5, 0 para 2/3. Las categorías 6/7/blanco salen del denominador; no se transforman en elección del esposo ni de ella. `P4_11` 1=1, 2=0; blancos excluidos.





Factor `FAC_MUJ`; estrato `EST_DIS`, UPM `UPM_DIS`, ambos de la tabla XV. Llave `ID_PER` para unir `TB_SEC_IV`, `TB_SEC_XV`, `TSDem`. Edad válida 15–120. Se exige llave de mujer y factor positivo; si no, se omite de los tres estimandos. Se usa remuestreo de todas las UPM A1/A2 dentro de estrato, con contribución cero cuando no hay caso válido en el dominio: 500 réplicas, semilla 20260923, IC percentil 2.5/97.5. Un estrato singleton se autorremuestrea y aporta varianza cero.





Ejes univariados, sin cruces: nacional; edad 15–29, 30–44, 45–59, 60+; escolaridad TSDem `NIV` (00 ninguna; 01–03/05–06 básica; 04/07–08 media superior o técnica; 09–11 superior); localidad U/C/R; A1/A2; entidad 01–32. Cada estimando/celda exige n conocido ≥100, al menos cinco UPM con casos, ancho IC ≤0.20 y CV≤0.30 si p>0. Se suprime la celda que no pase y no se publican sus réplicas. Se conservan solo réplicas agregadas de proporción por celda publicable, sin registros ni identificadores. Temporalidad: situación declarada a la entrevista de 2021, sin ventana retrospectiva anual explícita.





Origen: ZIP CSV ENDIREH 2021 id `endireh2021_bd_csv_zip`, SHA256 recalculado `e4f1e7b1898cc53b3126ed959a9089091afd2ffdd1439911f5419e6c99c6037e`; FD id `endireh2021_fd_pdf` SHA `5c30a3f7f88123ca672f1042ec3b5c37cc1d7989f07fd23ecbf088cca6dda180`; cuestionario A id `endireh2021_cuestionario_a_pdf` SHA `d2de0f03b8d347b298f7355312953d772a94edf21443bded042dd2a2ec487ae1`. Decisión y dinero disponible son prevalencias descriptivas; no se atribuye causalidad ni libertad de elección irrestricta.
