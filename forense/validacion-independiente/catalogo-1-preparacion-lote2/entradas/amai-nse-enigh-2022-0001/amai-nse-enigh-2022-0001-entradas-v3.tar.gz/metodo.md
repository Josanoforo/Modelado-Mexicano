## §1 · Regla

Regla NSE AMAI 2024 = regla 2022 ratificada sin cambios (nota metodológica AMAI 2024, octubre 2023, pp. 15–16; `data/raw/amai/NOTA_METODOLOGICA_NSE_AMAI_2024_v6.pdf`, sha256 `c268c3dc9f39bcc9b4de573429806fb787b141e2219501684e8bd566b87d89d1`). Unidad: **hogar**. Seis componentes y puntos, transcritos del Anexo «Códigos de Análisis en R», pp. 16–17:

| Componente | Puntos |
|---|---|
| Escolaridad de la jefatura (`educa_jefe` 01..11) | 01–02: 0 · 03: 6 · 04: 11 · 05: 12 · 06: 18 · 07: 23 · 08: 27 · 09: 36 · 10: 59 · 11: 85 |
| Baños completos | 0: 0 · 1: 24 · 2+: 47 |
| Autos (auto + van + pickup) | 0: 0 · 1: 22 · 2+: 43 |
| Internet (`conex_inte = 1`) | no: 0 · sí: 32 |
| Ocupados | 0: 0 · 1: 15 · 2: 31 · 3: 46 · 4+: 61 |
| Cuartos para dormir | 0: 0 · 1: 8 · 2: 16 · 3: 24 · 4+: 32 |

Cortes (a,b]: E ≤ 47 < D ≤ 94 < D+ ≤ 115 < C− ≤ 140 < C ≤ 167 < C+ ≤ 201 < A/B. INTERPRETACIÓN-DECLARADA: el `cut` del Anexo deja el puntaje 0 fuera de (0,47]; aquí 0 → E y la masa con puntaje 0 se reporta aparte (`masa_puntaje_cero`). Hogar con cualquier componente no válido: sin NSE (el Anexo excluye «casos en donde alguna de las variables … no contaba con datos válidos», p. 3); se reporta su conteo.

## §2 · Agrupación y umbrales — congelados aquí, antes de abrir microdato

- **Agrupación primaria de los pisos** (tres grupos): **BAJO** = E, D, D+ · **MEDIO** = C−, C · **ALTO** = C+, A/B. Los siete niveles se reportan sólo como distribución de hogares, no como pisos.
- **Supresión (F-U5-2)**: `SUPRIMIDA-N` si n < 200 personas/hogares del denominador en el grupo; `VARIANZA-NO-ESTIMABLE` en los casos del estimador U5 (réplica sin denominador, < 2 UPM, dispersión nula). No se ajusta con el resultado.

## §3 · Escolaridad de la jefatura fuera de ENIGH

Jefatura: parentesco = 1 (ENIF 2024 `PAREN`, ENIF 2021 `P2_3`, ENDUTIH `PAREN`); un hogar con dos jefaturas es error . Nivel/grado → `educa_jefe` con la regla de construcción de ENIGH 2022 (Descripción de la base, concentradohogar #12): 00→01; 01→02; primaria grado < 6 → 03, ≥ 6 → 04; secundaria grado < 3 → 05, ≥ 3 → 06; preparatoria grado < 3 → 07, ≥ 3 → 08; licenciatura grado < 4 → 09, ≥ 4 → 10; maestría y doctorado → 11. Normal básica y estudios técnicos con secundaria terminada → 06 y técnicos con preparatoria terminada → 08 (regla ENIGH: técnica/normal al nivel de su antecedente escolar). INTERPRETACIÓN-DECLARADA: especialidad → 11. «No sabe», blanco o grado no numérico donde el nivel lo exige → sin dato. Códigos: ENIF 2024 y ENDUTIH 2023–2025 (04 normal básica, 05 técnica con secundaria, 07 técnica con preparatoria, 09 especialidad, 10 maestría, 11 doctorado); ENIF 2021 (04 técnica con secundaria, 05 normal básica, 07 técnica con preparatoria, 09 maestría o doctorado). Un código fuera del codebook detiene el medidor.

## §4 · Construcción por instrumento

**4.1 · ENIGH 2022 — CALCULABLE** (`CALC-AMAI-NSE-ENIGH-2022-0001`, payload `enigh2022_nc_csv`). Réplica del Anexo: concentradohogar ⋈ hogares por (folioviv, foliohog) ⋈ viviendas por folioviv. `educa_jefe` y `ocupados` de concentradohogar; `conex_inte`, `num_auto+num_van+num_pickup` de hogares; `cuart_dorm`, `bano_comp` de viviendas. Factor `factor`, estrato `est_dis`, UPM `upm` de concentradohogar. ENIGH 2024 está RESERVADA (`decisiones.tsv` `reserva:enigh2024`) y no se abre.

**4.2 · ENIF 2021 y 2024 — APROXIMABLE** (`CALC-AMAI-NSE-ENIF-2021-0001`, `CALC-AMAI-NSE-ENIF-2024-0001`). Vivienda (TVIVIENDA, compartida por sus hogares como el merge por folioviv del Anexo): dormitorios `P0_1`; baños completos `P0_3`; autos `P0_4_1`=2 → 0, =1 → `P0_4_1A`; internet = 1 si `P0_4_2`=1 y `P0_4_2A`=1 (fijo), 0 si `P0_4_2`=2 o `P0_4_2A`=2. Hogar (THOGAR): ocupados = `P2_8` («¿Cuántas personas de su hogar tienen trabajo remunerado?» en 2024; «… trabajan?» en 2021) — **aproximación**: no filtra 14+ y en 2024 excluye trabajo sin pago; códigos > 90 → sin dato. Factor `FAC_HOG`; diseño `EST_DIS`, `UPM_DIS`. Llaves: 2024 `LLAVEVIV`/`LLAVEHOG`; 2021 (`FOLIO`,`VIV_SEL`)/(`FOLIO`,`VIV_SEL`,`HOGAR`). ENIF 2021 no tiene conducta adoptable en el catálogo U1 (sólo pisos históricos de crédito): su CALC construye y valida el NSE y no emite pisos.

**4.3 · ENDUTIH 2023, 2024, 2025 — APROXIMABLE** (`CALC-AMAI-NSE-ENDUTIH-<ola>-0001`). Observa: jefatura `PAREN`=1 con `NIVEL`/`GRADO`; ocupados = residentes con `EDAD` 14..97 y (`P3_10` ∈ {1,2} o `P3_11` ∈ {1,2,3}); internet = 1 si `P4_4`=1 y `P4_5` ∈ {1 sólo fija, 3 ambas}, 0 si `P4_4`=2 o `P4_5`=2; auto sí/no `P1_5_3` (vivienda). No observa baños ni dormitorios, ni el número de autos. **Aproximación declarada**: los puntos de baños + dormitorios + autos se sustituyen por su media ponderada (factor de hogar) en ENIGH 2022 (hogares con los seis componentes válidos, regla exacta) dentro de la celda (educa_jefe, internet, ocupados topado en 4, con_auto); celda con < 30 hogares donantes → (educa_jefe, internet, con_auto) → (con_auto). Determinista. El payload ENIGH 2022 entra como segundo input (`input_donante`). Factor `FAC_HOG`; diseño `EST_DIS`, `UPM_DIS`; llave (UPM, VIV_SEL, HOGAR).

**Diagnóstico de la aproximación ENDUTIH** (en el CALC ENIGH): se aplica la misma aproximación a los hogares ENIGH 2022 (autos a sí/no; baños, dormitorios y autos imputados) y se reporta la concordancia ponderada con la regla exacta, por nivel y por grupo. Es descriptivo; no cambia ningún estado.

con el grupo NSE del hogar como dominio (BAJO, MEDIO, ALTO; las personas/hogares sin NSE forman el dominio `SIN-NSE`, no publicado, y sus conteos se reportan). p_g = Σ w·1(D,g)·Y / Σ w·1(D,g). Plan común de 1 000 réplicas de UPM con reposición dentro de estrato sobre el marco completo de la tabla de la conducta (no se filtra antes de las réplicas), PCG64(20260924); IC95 percentil. Las réplicas quedan en el JSON para las diferencias entre grupos (P4).

- **ENIGH 2022** (unidad hogar, factor `factor`): `recibe_remesas` = `remesas` > 0 sobre todos los hogares de concentradohogar (definición de `CALC-B-0001`).
