# Método: extracción fiel de especificación humana

## Qué mide

**Dos estimandos sobre la misma lectura del mismo archivo**, cada uno con su escala declarada:

**`U_R` y `U1` no se comparan entre sí** (`A-bis.4`): están en la misma corrida porque salen de
la misma lectura, no porque sean comparables.

## Identidad del insumo

| campo | valor |
|---|---|
| `id` de manifiesto | **`envipe2023_csv`** — resuelto por `tests/payload_resolver.py`, nunca por heurística |
| miembro | `tmod_vic_envipe2023/conjunto_de_datos/conjunto_de_datos_tmod_vic_envipe2023.csv` |
| `Identifier` (metadato) | `MEX-INEGI.EGS3.02-ENVIPE-2023` |
| `Temporal` (metadato) | `2022-01-01-2022-12-31, 2023-03-01-2023-04-30 y 2023-03-01-2023-12-31` → **delitos de 2022** |
| catálogo `bp1_23` | leído en **latin-1** (la codificación se prueba por archivo, no por ZIP) |

**Nota de esta ola:** el catalogo y el descriptor declaran el codigo b (blanco).
**Redacción del reactivo en esta ola:** anade 'o Fiscalia Estatal'; sigue 'Por miedo al agresor' — ninguna de esas diferencias mueve un código.

## Diseño

`EST_DIS` y `UPM_DIS` se agrupan como **cadenas opacas** (nunca `int()`, nunca `zfill()`). El
descriptor de esta ola declara `EST_DIS Alfanumerico(3), 001..595 SEGUN DESCRIPTOR` y `UPM_DIS Alfanumerico(5) SEGUN DESCRIPTOR`; el perfil **real**
se emite en `RESULT-R-CIV-M-12-PERFIL-DISENO`, porque el descriptor ya mintió sobre esto en la
ola 2025. `EE` e `IC95` por conglomerado último con `tests/svystat.py:prop_ultimate_cluster`,
**importado y no reimplementado**. Un estrato con una sola UPM entra al punto, aporta varianza
cero, y su conteo va en `N-ESTRATOS-UPM-UNICA`; si es `> 0`, el IC es **límite inferior** de la
anchura verdadera.
