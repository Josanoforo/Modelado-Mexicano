# Método: extracción fiel de especificación humana

## 1 · Unidad, universo, diseño

Unidad: **persona elegida de 18+** (TENBIARE), ponderador `FAC_ELE`, estrato `EST_DIS`, UPM
`UPM_DIS` (llaves opacas). SEXO, EDAD, NIVEL de TSDEM por llave `FOLIO`+`VIV_SEL`+`HOGAR`+
`N_REN` (sólo llaves únicas en TSDEM; no pareados en `G-JOIN-SIN-SOCIODEMOGRAFICO`). Válido:
`FAC_ELE > 0`, estrato y UPM no vacíos. Universo: EDAD ≥ 18.

## 2 · Conductas (por texto)

Tabla en `forense/analisis/salud-bienestar/lista-cerrada-P1.md` §2 (ENBIARE), parte de esta
spec. Escalas 0–10 (PA1, PA5, PB1_01, PB1_02, PB1_04, PB1_11) se publican como **media**
(fuera de 0–10 → fuera). CESD-7 (PD2_1–7, 0–3, PD2_6 invertido): ≥ 9 (18–59) / ≥ 5 (60+),
mismos cortes que ENSANUT. GAD-2 (PD3_1–2, 0–3): suma ≥ 3. PB2_x: 1 → 1; 2 y 3 («no tiene
familia») → 0. ASISTE-SERVICIO-RELIGIOSO: PG7 1/2, y PG6 = 2 → 0 (blanco por secuencia).

## 3 · Ejes (uno a la vez)

TOTAL · SEXO (1/2) · EDAD 18–29 / 30–44 / 45–59 / 60+ · ESCOLARIDAD (`NIVEL`):
HASTA-PRIMARIA {00 ninguno, 01 preescolar, 02 primaria}, SECUNDARIA {03, 04 técnica con
secundaria}, MEDIA-SUPERIOR {05 normal básica, 06 preparatoria, 07 técnica con
preparatoria}, SUPERIOR {08 licenciatura, 09 especialidad, 10 maestría o doctorado}; 99 y
blanco fuera · TLOC (1 ≥ 100 mil, 2 15 000–99 999, 3 2 500–14 999, 4 < 2 500).

## 4 · Estimación

Razón ponderada (proporción o media) con bootstrap de UPM dentro de `EST_DIS` (certeza para
UPM única, `PCG64(20260924)`, 2 000 réplicas, percentiles 2.5/97.5, contrato conservador),
receta común por sha256.

