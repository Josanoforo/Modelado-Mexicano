# Reconstrucción independiente

Sesión nueva sin historial. Recibe únicamente esta carpeta y los insumos enumerados. Implementa desde metodo.md, cuestionarios y FD, con dependencias estadísticas genéricas. No uses helpers del productor. Si falta método o acceso, informa el faltante sin adivinar.

Reconstruye cada llave de estimandos.tsv. Entrega reconstruccion.tsv con columnas llave, punto, ic95_inf, ic95_sup y estado. No sustituyas un IC aleatorio por el esperado: conserva semilla y criterio de la spec y documenta diferencias de RNG. Congela código, entradas y números con SHA-256 y commit ANTES de solicitar revelación. Adjunta el SHA-256 de manifiesto.json recibido y conserva su lista de entradas.

El preparador conoce resultados; no ejecuta esta reconstrucción. Si el entorno permite leer el clon, la comparación u otras reservas, rotula REIMPLEMENTACIÓN-INDEPENDIENTE-NO-CIEGA. Nunca declares COINCIDE en preparación.
