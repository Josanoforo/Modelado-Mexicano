# Insumos y separación de la sesión

Solo una sesión nueva sin historial recibirá estos documentos; este contenedor no autoriza ejecución ni apertura de datos por sí mismo. Una misión de recálculo debe autorizar las olas abiertas y firmar los contratos propuestos antes de iniciar. No abrir resultados, productores, dictámenes ni material exterior; retornar únicamente salida propia según esquema y sellarla antes de comparar.

Payload `enigh2022_nc_csv`; archivo `enigh2022_nc_csv.zip`; SHA256 `3b2b0bc9c95323b470608113d2902ff3a832764367135f136270b4ce092c9e06`.

