# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2021-ESCOLAR-0001 · preregistro





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo; ninguna cifra GEN1 es input. Unidad mujer 15+ A1/A2/B1/B2/C1/C2 ENDIREH 2021. Ámbito escolar. Elegibilidad de vida: `P7_1=1`, asistió alguna vez a escuela; `P7_1=2` no se incluye, no se trata como ausencia de violencia. Pregunta 7.6 «Durante su vida de estudiante, ¿alguna o algunas personas de las escuelas a las que asistió…» contiene los 18 actos `P7_6_1`…`P7_6_18`, códigos 1 sí, 2 no, blanco/salto desconocido. Unión vida=1 si algún 1, =0 solo si todos 2, desconocida en otro caso.





Elegibilidad reciente: además `P7_2=1`, asistió a escuela de octubre de 2020 a la entrevista. `P7_2=2` no entra al denominador reciente; no se imputa ausencia de violencia. Pregunta 7.8 sobre los mismos 18 actos `P7_8_1`…`P7_8_18` en ese lapso, 1 muchas veces, 2 pocas veces, 3 una vez, 4 no ocurrió; blanco/salto desconocido. 7.8 se pregunta solo si 7.2=1 y acto de 7.6=1: para acto 7.6=2 se imputa 7.8=4 por salto documentado; unión reciente=1 si algún 1–3, =0 solo si todos 4, desconocida si falta respuesta sin positivo. Si vida desconocida, reciente desconocida. Uniones, nunca sumas.





Módulo `TB_SEC_VII.csv`; FD 2021 y cuestionario A, sección VII. Fuente `endireh2021_bd_csv_zip`, SHA `e4f1e7b1898cc53b3126ed959a9089091afd2ffdd1439911f5419e6c99c6037e`; FD SHA `5c30a3f7f88123ca672f1042ec3b5c37cc1d7989f07fd23ecbf088cca6dda180`; cuestionario A SHA `d2de0f03b8d347b298f7355312953d772a94edf21443bded042dd2a2ec487ae1`. `FAC_MUJ`, `EST_DIS`, `UPM_DIS` del módulo; TSDem unido por `ID_PER`, edad 15–120 y factor positivo.





Ejes univariados nacional, edad 15–29/30–44/45–59/60+, escolaridad `NIV` (00 ninguna; 01–03/05–06 básica; 04/07–08 media superior/técnica; 09–11 superior), localidad U/C/R, condición A1/A2/B1/B2/C1/C2 y entidad 01–32. IC percentil 2.5/97.5 con 200 réplicas de UPM completas dentro de estrato, incluidas sin casos del dominio, semilla 20260923. Singleton autorremuestreado con varianza cero. Publicación solo n conocido≥100, ≥5 UPM con casos, ancho IC≤0.20 y CV≤0.30 si p>0. Se suprime celda que falla; solo réplicas agregadas de las publicables. No cruces, municipio ni causalidad.
