# Método: extracción fiel de especificación humana

## Qué mide

**Dos estimandos sobre la misma lectura del mismo archivo:**

1. **PRIMARIO — el árbitro `R`.** Proporción ponderada de delitos con razón principal de
   no-denuncia en `{01, 02, 06}`, sobre **todos** los delitos con `BP1_23 ∈ {01…09}`,
   ponderador `FAC_DEL`, diseño `EST`/`UPM`. Codificación, universo, ponderador y
   diseño **verbatim** de `codificacion-R-v1_0.tsv`; variable y escala, de `espec-R-ciega-v1_2.tsv`.
2. **SECUNDARIO HOMOLOGADO — el punto de serie.** Mismo desenlace bajo `U1` y `C1` de
   `prereg-caja-ENVIPE-DENUNCIA`: delitos **personales** (`BPCOD ∈ {04,…,14}` **en esta ola**),
   `BP1_20 = 2`, denominador `{01…08}`. Se emite también `C2` (partición GEN1) y el delta.

**⚠️ Esta ola lleva el corrimiento de `BPCOD`.** Su catálogo tiene **catorce** códigos (`01…14`), no quince, y su bloque personal es **`{04,…,14}`**, que equivale uno a uno al `{05,…,15}` de 2013/2015. Las once parejas de etiquetas están verbatim en la spec sellada §3.1, y el residuo (código moderno `03`, vandalismo, del bloque hogar, fuera de `U1` por construcción) en §3.2.

**`U_R` y `U1` no se comparan entre sí** (`A-bis.4`).

## Identidad del insumo

| campo | valor |
|---|---|
| `id` de manifiesto | **`envipe_2012_base_de_datos_envipe_2012_dbf`** |
| miembro del ZIP | `Tmod_Vic.DBF` — literal, nunca por plantilla |
| filas (cabecera DBF) | 32,493 |
| descriptor citado | `FD_ENVIPE12.zip -> FD_ENVIPE_2012.xls, hoja TMod_Vic` — `BP1_23` fila 231, `BPCOD` fila 26, diseño filas 621 (FAC_DEL), 627 (EST), 628 (UPM) |

## Vínculo de columnas (rol → nombre físico en ESTA ola)

| rol | nombre físico | tipo en la cabecera del `.dbf` |
|---|---|---|
| `BP1_23` | `BP1_23` | Caracter(2) |
| `BP1_20` | `BP1_20` | Caracter(1) |
| `BPCOD` | `BPCOD` | Caracter(2) |
| `FAC_DEL` | `FAC_DEL` | Caracter(6) |
| `ESTRATO` | **`EST`** | Caracter(3) |
| `UPM` | **`UPM`** | Caracter(5) |

El medidor no conoce ninguno de estos nombres por su cuenta: los recibe en
`parametros.mapa_columnas`. La guardia de columna ausente de la familia **no se edita**.

