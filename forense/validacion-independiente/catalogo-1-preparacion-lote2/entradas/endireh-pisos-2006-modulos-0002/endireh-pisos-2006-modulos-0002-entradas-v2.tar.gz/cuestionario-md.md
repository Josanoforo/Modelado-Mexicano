                                               ENCUESTA NACIONAL SOBRE LA DINÁMICA
                                              DE LAS RELACIONES EN LOS HOGARES 2006
                                                              MÓDULO PARA MUJERES DIVORCIADAS,




                                                                                                                                                                                                INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                    SEPARADAS Y VIUDAS

1. DATOS DE IDENTIFICACIÓN                                                                    2. CONTROL DE VIVIENDA




                                                           $
 ENTIDAD FEDERATIVA                                                                             NÚMERO DE CONTROL ....................

 MUNICIPIO O DELEGACIÓN
                                                                                                NÚMERO DE VIVIENDA SELECCIONADA ...............................




                                                          5
 LOCALIDAD
                                                                                                TIPO DE INSTRUMENTO ...................................................................   B
 AGEB ............................................................




                                                         7
3. DIRECCIÓN DE LA VIVIENDA




                                                        6
                                                                       CALLE, AVENIDA, CALLEJÓN, CARRETERA, CAMINO



    NÚMERO                 NÚMERO                                                COLONIA, FRACCIONAMIENTO, BARRIO, UNIDAD HABITACIONAL




                                                       (
    EXTERIOR               INTERIOR



4. CONTROL DE PAQUETE




                                                      8
 FOLIO DE PAQUETE .......................................................                      CONSECUTIVO DEL CUESTIONARIO EN EL PAQUETE .........


                                                                     O B S E R V A C I O N E S




                                                     0

CONFIDENCIALIDAD                                                                                           OBLIGATORIEDAD
 Conforme a las disposiciones del Artículo 38, párrafo primero, de la Ley de                                 De acuerdo con el Artículo 42, párrafo primero, de la Ley
 Información Estadística y Geográfica en vigor: “Los datos e informes que los                                de Información Estadística y Geográfica en vigor: “Los
 particulares proporcionen para fines estadísticos o provengan de registros                                  informantes estarán obligados a proporcionar con veraci-
 administrativos o civiles, serán manejados, para efectos de esta Ley, bajo la                               dad y oportunidad los datos e informes que les soliciten las
 observancia de los principios de confidencialidad y reserva y no podrán                                     autoridades competentes para fines estadísticos, censales
 comunicarse, en ningún caso, en forma nominativa o individualizada, ni harán                                y geográficos, y a prestar el auxilio y cooperación que
 prueba ante autoridad administrativa o fiscal, ni en juicio o fuera de él”.                                 requieran las mismas”.


                                                                                                                                                                                          175
                                                                                                                                                                                                 III. ÁMBITOS LABORAL, ESCOLAR Y SOCIAL


                                                                                                                                           3.1 Nombre de la mujer elegida




                                                                                                                                                                                             ANOTE EL NÚMERO DEL RENGLÓN DE LA SECCIÓN II DEL CUESTIONARIO GENERAL




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                           3.2 ¿Usted trabaja?                                                        3.3 ¿Cuánto gana o recibe usted por su trabajo?

                                                                                                                                                               CIRCULE UN SOLO CÓDIGO                                                ANOTE LA CANTIDAD RECIBIDA Y EL CÓDIGO DEL PERIODO INDICADO


                                                                                                                                                                                                                                                                                             Periodo




                                                                                                                                                                                      $
                                                                                                                                                        Sí ........ 1                                                 $              ,              ¿cada cuándo?               semana ...................... 1
                                                                                                                                                                                                                           ANOTE CON NÚMERO
                                                                                                                                                                                                                                                                                quincena .................... 2
                                                                                                                                                        No ...... 2              PASE A 3.4
                                                                                                                                                                                                                                                                                mes ............................. 3




                                                                                                                                                                                     5
                                                                                                                                                                                                                                                                                no recibe ingresos ..... 4




                                                                                                                                                                                    7
                                                                                                                                           3.4 ¿Usted recibe ingresos por apoyo                        3.5 ¿Desde hace cuánto tiempo recibe                    3.6 ¿Usted recibe ingresos de
                                                                                                                                           del Programa Oportunidades?                                 apoyo del Programa Oportunidades?                       familiares o conocidos?




                                                                                                                                                                                   6
                                                                                                                                                       CIRCULE UN SOLO CÓDIGO                                                                                               CIRCULE SÓLO UN CÓDIGO




                                                                                                                                                                                  (
                                                                                                                                                    Sí ....... 1                                                                                                        Sí ....... 1
                                                                                                                                                                                                                              AÑOS

                                                                                                                                                    No ..... 2              PASE A 3.6
                                                                                                                                                                                                         SI LA RESPUESTA ES MENOS DE UN AÑO, ANOTE 00                   No ..... 2           PASE A 3.9




                                                                                                                                                                                 8
                                                                                                                                       3.7 ¿Qué familiares le ayudan con                               3.8 Los familiares o conocidos que la                   3.9 ¿Usted recibe ingresos por
                                                                                                                                       dinero?                                                         ayudan, ¿viven o trabajan …                             jubilación o pensión?




                                                                                                                                                                                0
                                                                                                                                                   CIRCULE LAS OPCIONES INDICADAS                               CIRCULE LAS OPCIONES INDICADAS                              CIRCULE UN SOLO CÓDIGO



                                                                                                                                            Padre o madre ......................         1               en Estados Unidos? .............. 1
                                                                                                                                                                                                                                                                                  Sí ....... 1
                                                                                                                                            Hija(s)/hijo(s) ........................     2               en otro país distinto
                                                                                                                                                                                                         a Estados Unidos? ................ 2
                                                                                                                                            Hermano(s)/hermana(s) ......                 3                                                                                        No ..... 2
                                                                                                                                                                                                         en otro lugar del país? .......... 3
                                                                                                                                            Otros familiares ....................        4
                                                                                                                                                                                                         en esta misma localidad? .... 4
                                                                                                                                            Personas conocidas ............              5


                                                                                                                                       3.10 ¿Usted recibe ingresos por apoyo                           3.11 ¿Recibe otro tipo de ingresos?                     SI AL MENOS HUBO UNA RESPUESTA
                                                                                                                                       de otro(s) programa(s) de gobierno?                                                                                     AFIRMATIVA EN 3.4, 3.6, 3.9, 3.10 Ó 3.11
                                                                                                                                                                                                                                                               SIEMPRE APLICAR 3.12. SI TODAS FUERON
                                                                                                                                                                                                                      CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                                                                               NEGATIVAS PASE A LA PREGUNTA 3.13
                                                                                                                                                       CIRCULE UN SOLO CÓDIGO

                                                                                                                                                                                                                                                               3.12 En total, ¿cuánto recibe usted al
                                                                                                                                                             Sí ....... 1                              Sí ....... 1                                            mes de estos otros ingresos?
                                                                                                                                                                                                                                     ESPECIFIQUE

                                                                                                                                                             No ..... 2                                No ..... 2
                                                                                                                                                                                                                                                                        $                ,
                                                                                                                                                                                                                                                                               ANOTE CON NÚMERO




                                                                                                                                       2         Módulo para mujeres divorciadas, separadas y viudas
                                                                                                                                      176
                                                        III. ÁMBITOS LABORAL, ESCOLAR Y SOCIAL

3.13 Durante el último año (octubre de 2005 a la fecha),                                         3.14 ¿Su lugar de trabajo es …
¿usted trabajó como …
                                                                                                                                 CIRCULE UN SOLO CÓDIGO
                             CIRCULE UN SOLO CÓDIGO
                                                                                                  oficina de dependencia pública? ................................. 01
empleada? ............................................................. 1
                                                                                                  oficina de empresa privada? ....................................... 02
obrera? .................................................................. 2
                                                                                                  comercio? ..................................................................... 03




                                                                                                                                                                                                       INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
jornalera? .............................................................. 3
                                                                                                  banco o servicios privados? ........................................ 04
trabajadora por su cuenta? ................................. 4
                                                                                                  escuela? ........................................................................ 05
patrona? ................................................................ 5
                                                                                                  fábrica? .......................................................................... 06




                                                 $
trabajadora sin pago en negocio                                                    PASE
familiar? ................................................................. 6        A
                                                                                                  taller, maquila? .............................................................. 07
                                                                                    3.19

trabajadora sin pago en negocio                                                                   casa? .............................................................................. 08




                                                5
no familiar? ............................................................ 7                       campo? .......................................................................... 09
No trabajó ............................................................... 8                      Otro ................................................................................. 10




                                               7
3.15 ¿Cuánto               3.16 Durante el último año (octubre de 2005 a la fecha), ¿usted vivió alguna de                                                                 Sí ................ 1
                                                                                                                                                                           No ............... 2




                                              6
tiempo ha                  las siguientes situaciones en su trabajo?
trabajado o                                                                                                                                                                No aplica .... 3
trabajó en ese                                                         ANOTE LAS OPCIONES INDICADAS

lugar?




                                             (
                           1) ¿Le pidieron la prueba de embarazo como requisito para entrar? ..................................................

                           2) ¿La despidieron, no le renovaron contrato o le bajaron el salario por embarazarse? ...................




                                            8
                           3) ¿Le pagaron menos que a un hombre que hace lo mismo? ..............................................................
       AÑOS

                           4) ¿Tuvo menos oportunidad para ascender que un hombre? ..............................................................
MENOS DE UN AÑO




                                           0
   ANOTE 00
                           5) ¿Recibió menos prestaciones que un hombre? .................................................................................

                           6) ¿Debido a su edad o a su estado civil, la despidieron, le bajaron el salario
                              o no la contrataron? ..............................................................................................................................


3.17 Durante el último año (octubre de 2005 a la fecha) en                                                                                                 APLIQUE ESTA PREGUNTA
su trabajo, ¿su jefe inmediato, algún directivo o algún                                                                                                    SÓLO SI EN 3.16 Ó 3.17
compañero, alguna vez …                                                                                                                                    HUBO AL MENOS UNA RES-
                                                                                                                                                           PUESTA AFIRMATIVA
         ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS
                                                                                           Sí ........... 1     ¿Quién o quiénes?
            DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO                                No .......... 2    NO ANOTE NOMBRES PROPIOS                      3.18. Debido a estos
                                                                                                                                                            problemas, ¿hizo
1) la humilló o denigró? ..................................................................                                                                 alguna denuncia o
                                                                                                                                                            puso alguna queja
2) la agredió físicamente? .............................................................                                                                    administrativa?

3) la ignoró o hizo sentir menos por ser mujer? .........................                                                                                      CIRCULE UN SOLO CÓDIGO


4) le hizo insinuaciones o propuestas para tener relaciones
   sexuales a cambio de mejores condiciones en el trabajo? ..                                                                                                          Sí ........ 1

5) la acarició o manoseó sin su consentimiento? ......................                                                                                                 No ...... 2
6) la obligó a tener relaciones sexuales? ....................................

7) tomó represalias contra usted por haberse negado
   a sus pretensiones? ..................................................................

                                                                                                  Módulo para mujeres divorciadas, separadas y viudas                                              3
                                                                                                                                                                                               177
                                                                                                                                                                                              III. ÁMBITOS LABORAL, ESCOLAR Y SOCIAL

                                                                                                                                           3.19 ¿Usted asiste o asistió alguna vez a la escuela?                              Sí ....... 1

                                                                                                                                                                                                                              No ..... 2         PASE A 3.22



                                                                                                                                           3.20 Durante su vida de estudiante, ¿algún compañero, maestro, personal                                             APLIQUE ESTA PREGUNTA SÓLO SI EN 3.20
                                                                                                                                           o autoridad escolar …                                                                                                   HUBO AL MENOS UNA RESPUESTA
                                                                                                                                                                                                                                                                            AFIRMATIVA




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                               ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS
                                                                                                                                                                  DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO
                                                                                                                                                                                                                                                               3.21 Cuando esto ocurrió, ¿avisó o
                                                                                                                                                                                                                                                               denunció este hecho …
                                                                                                                                                                                                         Sí ........... 1       ¿Quién o quiénes?
                                                                                                                                                                                                         No .......... 2      NO ANOTE NOMBRES PROPIOS                    CIRCULE LAS OPCIONES INDICADAS


                                                                                                                                           1) la humilló o denigró? ...........................................




                                                                                                                                                                                     $
                                                                                                                                                                                                                                                                a familiares? .................................. 1
                                                                                                                                           2) la agredió físicamente? ......................................
                                                                                                                                                                                                                                                                en el ministerio público? .............. 2
                                                                                                                                           3) la ignoró o le hizo sentir menos por ser mujer?




                                                                                                                                                                                    5
                                                                                                                                                                                                                                                                a la policía? .................................... 3
                                                                                                                                           4) le propuso tener relaciones sexuales
                                                                                                                                              a cambio de calificaciones? ..............................                                                        a las autoridades escolares? ...... 4




                                                                                                                                                                                   7
                                                                                                                                           5) la acarició o manoseó sin su consentimiento?                                                                      Otro                                              5
                                                                                                                                                                                                                                                                                    ESPECIFIQUE
                                                                                                                                           6) la obligó a tener relaciones sexuales? .............




                                                                                                                                                                                  6
                                                                                                                                                                                                                                                                No dio aviso ni denunció ............... 6
                                                                                                                                           7) le impuso castigos o represalias por haberse
                                                                                                                                              negado a sus pretensiones? ..............................




                                                                                                                                                                                 (
                                                                                                                                           3.22 Dígame si a lo largo de su vida (en la calle, en fiestas, en un club, en su                                    APLIQUE ESTA PREGUNTA SÓLO SI EN 3.22
                                                                                                                                           casa, etc.), usted ha experimentado alguna de las siguientes situaciones y de                                           HUBO AL MENOS UNA RESPUESTA




                                                                                                                                                                                8
                                                                                                                                                                                                                                                                            AFIRMATIVA
                                                                                                                                           parte de quién.
                                                                                                                                                                                                                                                               3.23 Cuando esto ocurrió, ¿dio aviso
                                                                                                                                                                   ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS
                                                                                                                                                                      DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO
                                                                                                                                                                                                                                                               o denunció este hecho …




                                                                                                                                                                               0
                                                                                                                                                                                                                                                                       CIRCULE LAS OPCIONES INDICADAS
                                                                                                                                                                                                       Sí ........... 1        ¿Quién o quiénes?
                                                                                                                                                                                                       No .......... 2       NO ANOTE NOMBRES PROPIOS,
                                                                                                                                                                                                                              SINO SUSTANTIVOS DEL TIPO:
                                                                                                                                                                                                                            VECINO, TÍO, DESCONOCIDO, ETC.
                                                                                                                                                                                                                                                               a familiares? ................................... 1
                                                                                                                                           1) ¿La acariciaron o manosearon
                                                                                                                                              sin su consentimiento? ....................................
                                                                                                                                                                                                                                                               en el ministerio público? ............... 2
                                                                                                                                           2) ¿La obligaron o forzaron a
                                                                                                                                                                                                                                                               a la policía? ..................................... 3
                                                                                                                                              tener relaciones sexuales? .............................
                                                                                                                                                                                                                                                               Otro                                               4
                                                                                                                                           3) ¿La obligaron a realizar
                                                                                                                                                                                                                                                                                   ESPECIFIQUE
                                                                                                                                              actos sexuales por dinero? .............................

                                                                                                                                           4) ¿Le hicieron sentir miedo de                                                                                     No dio aviso ni denunció ................ 5
                                                                                                                                              sufrir un ataque o abuso sexual? ....................

                                                                                                                                           5) ¿Le han dicho piropos groseros u ofensivos
                                                                                                                                              sobre su cuerpo o de carácter sexual? ..........




                                                                                                                                       4          Módulo para mujeres divorciadas, separadas y viudas
                                                                                                                                      178
                                                                            IV. VIDA EN PAREJA

Ahora le voy a hacer unas preguntas sobre su último matrimonio, unión o relación, y sobre su ex esposo o ex pareja.


4.1 ¿Usted está …                                                   4.2 ¿Con su ex esposo o                         4.3 ¿Hace cuánto               4.4 ¿Cuánto tiempo
                                                                    ex pareja, estaba o está …                      tiempo se separó,              estuvo casada o
                 CIRCULE UN SOLO CÓDIGO                                                                             divorció o enviudó             unida con su ex
                                                                           CIRCULE UN SOLO CÓDIGO                   de su ex esposo o              esposo o ex pareja?
                                                                                                                    ex pareja?




                                                                                                                                                                                   INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
separada definitivamente? ........... 1                              casada sólo por lo civil? .. 1

separada temporalmente? ........... 2                                casada por lo civil y por
                                                                     la iglesia? .......................... 2
                                                                                                                              AÑOS                           AÑOS
divorciada? ..................................... 3
                                                                     casada sólo por




                                                  $
                                                                                                                       SI LA RESPUESTA ES             SI LA RESPUESTA ES
viuda? .............................................. 4              la iglesia? .......................... 3       MENOS DE UN AÑO, ANOTE 00      MENOS DE UN AÑO, ANOTE 00


                                                                     en unión libre? .................. 4




                                                 5
4.5 ¿Usted habla alguna                             4.6 Su ex esposo o ex pareja                      4.7 En total, ¿cuántas hijas              4.8 ¿Qué edad tenía
lengua indígena?                                    ¿habla o hablaba alguna                           e hijos nacidos vivos ha                  cuando tuvo a su




                                                7
                                                    lengua indígena?                                  tenido?                                   primer hija o hijo?
         CIRCULE UN SOLO CÓDIGO
                                                             CIRCULE UN SOLO CÓDIGO




                                               6
                                                                                                                ANOTE CON NÚMERO
 Sí ....... 1                  No ..... 2            Sí ....... 1                 No ..... 2
                                                                                                                                                           AÑOS
                                                                                                                 SI LA RESPUESTA ES




                                              (
  ¿cuál?                                                  ¿cuál?                                                NINGUNO, ANOTE 00 Y
                                                                                                                      PASE A 4.10


                ESPECIFIQUE                                         ESPECIFIQUE




                                             8
4.9 ¿Cuántas de sus                       4.10 ¿Cúantas hija(s) e                         4.11 ¿Cuántos años tenía cuando                   4.12 ¿Cuántos años tenía
hijas e hijos son de su                   hijo(s) tiene su ex esposo o                    inició el noviazgo o relación con                 cuando se casó o empezó
ex esposo o ex pareja?                    ex pareja con otras                             su ex esposo o ex pareja?                         a vivir con él?




                                            0
                                          mujeres?


      ANOTE CON NÚMERO                             ANOTE CON NÚMERO                                              AÑOS                                     AÑOS


        SI LA RESPUESTA ES                         SI LA RESPUESTA ES                                   SI LA ENTREVISTADA                          SI LA ENTREVISTADA
        NINGUNO, ANOTE 00                       NINGUNO, ANOTE 00 Y SI ES                             NO RECUERDA, ANOTE 98                       NO RECUERDA, ANOTE 98
                                                    NO SABE ANOTE 98



4.13 Cuando se casaron o                                      4.14 Antes de separarse o                                 4.15 Contando su             4.16 ¿Cuántos
empezaron a vivir juntos,                                     enviudar, ¿vivían …                                       anterior unión               años tenía cuando
¿se fueron a vivir …                                                                                                    o matrimonio,                se casó o unió por
                                                                          CIRCULE UN SOLO CÓDIGO
                                                                                                                        ¿cuántas veces               primera vez?
            CIRCULE UN SOLO CÓDIGO                                                                                      ha estado casada
                                                                                                                        o unida?
 solos como pareja, con o                                     solos como pareja, con
 sin hijos? ....................................... 1         o sin hijos? .................................... 1

 con sus padres u otros                                       con sus padres u otros                                      ANOTE CON NÚMERO                    AÑOS
 familiares de usted? .................... 2                  familiares de usted? .................... 2
                                                                                                                                                       SI LA ENTREVISTADA
 con los padres u otros familiares                            con los padres u otros familiares                                                           NO RECUERDA
                                                                                                                                                             ANOTE 98
 de su ex esposo o                                            de su ex esposo o                                           SI LA
                                                                                                                                      PASE A LA
 ex pareja? ..................................... 3           ex pareja? ..................................... 3        RESPUESTA
                                                                                                                                      SECCIÓN V
                                                                                                                          ES 01

 Otro                                               4         Otro                                              4
                      ESPECIFIQUE                                                 ESPECIFIQUE



                                                                                                Módulo para mujeres divorciadas, separadas y viudas                            5
                                                                                                                                                                            179
                                                                                                                                                                                                                        V. FAMILIA DE ORIGEN

                                                                                                                                           Ahora le voy a hacer algunas preguntas de cuando usted era niña, digamos hasta los 13 años.


                                                                                                                                           5.1 ¿Cuándo usted era niña,                         5.2 ¿Las personas adultas que la cuidaban y se                                       5.3 ¿Recuerda si entre las personas
                                                                                                                                           vivió la mayor parte del                            encargaban de usted, eran …                                                          con las que vivía había golpes …
                                                                                                                                           tiempo en …
                                                                                                                                                                                                                       CIRCULE UN SOLO CÓDIGO                                                       CIRCULE UN SOLO CÓDIGO
                                                                                                                                                    CIRCULE UN SOLO CÓDIGO




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                                               su papá y su mamá o alguno de los dos? ......... 1
                                                                                                                                                                                               sus abuelos y/o tíos u otros familiares? ........... 2                                de vez en cuando? ....................... 1
                                                                                                                                           un rancho, pueblo
                                                                                                                                           o comunidad? .................... 1                 otros adultos no familiares? .............................. 3                         seguido? ...................................... 2
                                                                                                                                                                                               Otro ____________________________________ 4                                           No había golpes ........................... 3
                                                                                                                                           una ciudad? ....................... 2




                                                                                                                                                                                          $
                                                                                                                                                                                                                                ESPECIFIQUE



                                                                                                                                           5.4 ¿Las personas con las                       5.5 A usted, ¿las personas                           5.6 ¿Quién le pegaba                         5.7 ¿Recuerda si las personas
                                                                                                                                           que vivía se insultaban o                       con las que vivía le                                 con mayor frecuencia?                        con las que vivía la insultaban




                                                                                                                                                                                         5
                                                                                                                                           se ofendían …                                   pegaban …                                                                                         o la ofendían …
                                                                                                                                                                                                                                                    CIRCULE UN SOLO CÓDIGO
                                                                                                                                                 CIRCULE UN SOLO CÓDIGO                            CIRCULE UN SOLO CÓDIGO                                                                               CIRCULE UN SOLO CÓDIGO




                                                                                                                                                                                        7
                                                                                                                                                                                                                                                Su papá ..................... 1
                                                                                                                                              de vez en                                    de vez en                                                                                         de vez en
                                                                                                                                                                                                                                                Su mamá ................... 2
                                                                                                                                              cuando? ................. 1                  cuando? ............... 1                                                                         cuando? ................ 1
                                                                                                                                                                                                                                                Su madrastra




                                                                                                                                                                                       6
                                                                                                                                              seguido? ................ 2                                                                       o padrastro ................ 3               seguido? .............. 2
                                                                                                                                                                                           seguido? ............. 2
                                                                                                                                              No había insultos                                                                      PASE       Sus abuelos .............. 4                 No la insultaban                       PASE
                                                                                                                                              ni ofensas .............. 3                  No le pegaban .... 3                        A                                                     ni la ofendían ........ 3                A




                                                                                                                                                                                      (
                                                                                                                                                                                                                                      5.7       Otro                                5                                                5.9
                                                                                                                                                                                                                                                             ESPECIFIQUE



                                                                                                                                           5.8 ¿Quién la insultaba con mayor                                  5.9 Cuando su ex esposo o ex pareja                                5.10 ¿Sabe si cuando su ex esposo o




                                                                                                                                                                                     8
                                                                                                                                           frecuencia?                                                        era niño, ¿le pegaban o insultaban en                              ex pareja era niño, a la mamá de él
                                                                                                                                                                                                              su casa …                                                          le pegaba su marido?
                                                                                                                                                         CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                                            CIRCULE UN SOLO CÓDIGO                                                 CIRCULE UN SOLO CÓDIGO




                                                                                                                                                                                    0
                                                                                                                                           Su papá ........................................... 1
                                                                                                                                           Su mamá ......................................... 2                de vez en cuando? ......................... 1                      Sí le pegaba .................................... 1
                                                                                                                                           Su madrastra o padrastro .............. 3                          seguido? ......................................... 2               No le pegaba ................................... 2
                                                                                                                                           Sus abuelos .................................... 4                 No le pegaban ni lo insultaban ...... 3                            No sabe ........................................... 3
                                                                                                                                           Otro                                                  5            No sabe ........................................... 4
                                                                                                                                                                 ESPECIFIQUE



                                                                                                                                           5.11 Durante el último año (octubre de 2005 a la fecha), sin considerar a su
                                                                                                                                           ex esposo o ex pareja, ¿alguna persona de su familia la ha …                                                                         Sí ........... 1          ¿Quién o quiénes?
                                                                                                                                                                                                                                                                                No .......... 2       NO ANOTE NOMBRES PROPIOS, SINO
                                                                                                                                                                         ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS                                                                        SUSTANTIVOS DEL TIPO: PADRE,
                                                                                                                                                                            DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO                                                                                HERMANO, SUEGRA, ETC.


                                                                                                                                           1) insultado u ofendido? .............................................................................................................
                                                                                                                                           2) amenazado con golpearla o correrla de su casa? .............................................................
                                                                                                                                           3) golpeado o agredido físicamente? .......................................................................................
                                                                                                                                           4) humillado o menospreciado? ................................................................................................
                                                                                                                                           5) ignorado, no la toman en cuenta, no le brindan atención? ................................................
                                                                                                                                           6) encerrado? .............................................................................................................................
                                                                                                                                           7) le ha quitado su dinero u obligado a entregar su dinero? ..................................................



                                                                                                                                       6           Módulo para mujeres divorciadas, separadas y viudas
                                                                                                                                      180
                                                                      V. FAMILIA DE ORIGEN

5.12. ¿Alguna vez sus familiares u otras personas …                                                                   Sí ................ 1       ¿Quién o quiénes?
                                                                                                                      No ............... 2
                                                                                                                                              NO ANOTE NOMBRES PROPIOS, SINO
                             ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS                                  No aplica .... 3          SUSTANTIVOS DEL TIPO PADRE,
                                DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO
                                                                                                                                                   HERMANO, VECINO, ETC.

1) le han quitado o robado bienes o propiedades? .................................................................

2) le han quitado o robado documentos que la acrediten como propietaria
   o posesionaria de algún bien? ..............................................................................................




                                                                                                                                                                                       INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
3) la han obligado a poner a nombre de otra persona las cosas
   o propiedades que usted compró o heredó? ......................................................................


5.13 ¿Ha habido herencias en                      5.14 En su familia ¿a quién se acostumbra heredar?                                    5.15 ¿Siente que por ser mujer




                                               $
su familia?                                                                                                                             la herencia fue desigual y
                                                                           CIRCULE UN SOLO CÓDIGO                                       favoreció a los hombres?
       CIRCULE UN SOLO CÓDIGO
                                                                                                                                                CIRCULE UN SOLO CÓDIGO




                                              5
     Sí ....... 1                                               Mujeres ...................................... 1
                                                                                                                                                Sí ......................... 1




                                             7
     No ..... 2              PASE A LA                          Hombres ................................... 2
                            SECCIÓN VI                                                                                                          No ....................... 2

                                                                Ambos ....................................... 3
                                                                                                                                                No aplica ............ 3




                                           (6
                                          8
                                         0

                                                                                            Módulo para mujeres divorciadas, separadas y viudas                                  7
                                                                                                                                                                                 181
                                                                                                                                                                                                                VI. TENSIONES Y CONFLICTOS

                                                                                                                                           En la vida de las parejas es común que haya situaciones                                       Ahora veamos las cosas al revés.
                                                                                                                                           que provocan enojo, dígame ...

                                                                                                                                           6.1 ¿Su ex esposo o ex pareja se molestaba con usted                                          6.2 ¿Usted se molestaba con su ex esposo o ex pareja
                                                                                                                                           porque …                                                                                      porque …

                                                                                                                                                CIRCULE LAS OPCIONES EN LAS QUE OBTENGA UNA RESPUESTA AFIRMATIVA                              CIRCULE LAS OPCIONES EN LAS QUE OBTENGA UNA RESPUESTA AFIRMATIVA




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                           usted trabajaba o estudiaba? .........................................                01      él le dedicaba demasiado tiempo al trabajo
                                                                                                                                                                                                                                         o por su horario? .............................................................        01
                                                                                                                                           usted no trabajaba? .........................................................         02
                                                                                                                                                                                                                                         él no trabajaba? ...............................................................       02
                                                                                                                                           usted ganaba más dinero que él? ..................................                    03

                                                                                                                                           usted le dedicaba mucho tiempo a su trabajo                                                   él no ganaba lo suficiente? .............................................              03




                                                                                                                                                                                           $
                                                                                                                                           o por su horario? .............................................................       04
                                                                                                                                                                                                                                         a usted no le gustaba cómo trataba o educaba
                                                                                                                                           a él no le gustaba cómo trataba o educaba                                                     a sus hijos? ......................................................................    04
                                                                                                                                           a sus hijos? ......................................................................   05




                                                                                                                                                                                          5
                                                                                                                                                                                                                                         él era celoso? ...................................................................     05
                                                                                                                                           usted era celosa? ............................................................        06
                                                                                                                                                                                                                                         él no respetaba sus sentimientos o sus opiniones? ...                                  06
                                                                                                                                           usted usaba anticonceptivos? .......................................                  07




                                                                                                                                                                                         7
                                                                                                                                                                                                                                         él visitaba demasiado a su familia o amistades? .........                              07
                                                                                                                                           él decía que usted no le dedicaba suficiente tiempo
                                                                                                                                           o atención? .......................................................................   08      él era muy posesivo o absorbente? ...............................                      08




                                                                                                                                                                                        6
                                                                                                                                           decía que usted era muy posesiva o absorbente? ......                                 09      él no deseaba tener relaciones sexuales? ...................                           09
                                                                                                                                           visitaba o la visitaban amistades o familiares? ............                          10      él no le daba su lugar? ....................................................           10




                                                                                                                                                                                       (
                                                                                                                                           a él no le gustaba su manera de vestir o usted                                                los parientes de él intervenían o querían opinar
                                                                                                                                           no quería vestirse como él prefería? .............................                    11      sobre la forma de educar a sus hijos? ..........................                       11
                                                                                                                                           él creía que usted no cumplía como madre                                                      usted creía o sabía que él la engañaba? .......................                        12




                                                                                                                                                                                      8
                                                                                                                                           o esposa? .........................................................................   12
                                                                                                                                                                                                                                         él no colaboraba en los quehaceres? ...........................                        13
                                                                                                                                           algún pariente de usted intervenía o quería opinar
                                                                                                                                           sobre la forma de educar a sus hijos? ........................... 13                          él estaba enfermo y usted lo tenía que cuidar? ............                            14




                                                                                                                                                                                     0
                                                                                                                                           quedaban en algo y usted no cumplía? .........................                        14      él no cumplía con lo acordado? .....................................                   15

                                                                                                                                           usted no le obedecía? .....................................................           15      él decía que era la única autoridad de la casa
                                                                                                                                                                                                                                         y que sólo su opinión valía? ............................................              16
                                                                                                                                           usted estaba enferma y él la tenía que cuidar? ............                           16
                                                                                                                                                                                                                                         él no cumplía como esposo o como padre? .................                              17
                                                                                                                                           usted tomaba decisiones en asuntos que él
                                                                                                                                           consideraba su responsabilidad? .................................                     17      él no cuidaba o usaba bien el dinero? ...........................                      18

                                                                                                                                           usted opinaba diferente o lo desmentía                                                        él traía amigos a la casa? ...............................................             19
                                                                                                                                           en ciertas situaciones? ...................................................           18
                                                                                                                                                                                                                                         él no la obedecía? ............................................................        20
                                                                                                                                           él le decía que usted siempre lloraba por todo? ........... 19
                                                                                                                                                                                                                                         él le quitaba su dinero o le pedía cuentas sobre
                                                                                                                                           él creía que usted lo engañaba? ....................................                  20      su dinero? .........................................................................   21

                                                                                                                                           usted le decía o le recordaba sus obligaciones? .........                             21      él le recordaba a usted sus obligaciones? ...................                          22

                                                                                                                                           usted salía de su casa sin avisarle                                                           él tomaba o se drogaba? ................................................               23
                                                                                                                                           o pedir permiso? ..............................................................       22
                                                                                                                                                                                                                                         él llegaba tarde o no llegaba a casa? ............................                     24
                                                                                                                                           usted tomaba alcohol o se drogaba? ............................                       23
                                                                                                                                                                                                                                         aunque él tenía dinero no daba gasto o no
                                                                                                                                           usted no deseaba tener relaciones sexuales? ............                              24      daba lo suficiente? ..........................................................         25

                                                                                                                                           él se molestaba por todo o sin razón aparente? ..........                             25      usted se molestaba por todo o sin razón aparente? ...                                  26

                                                                                                                                           Otra situación ....................................................................   26      Otra situación ....................................................................    27

                                                                                                                                           No se molestaba por nada ............................. 27                        PASE A 6.2
                                                                                                                                                                                                                                         No se molestaba por nada ............................ 28                         PASE A 6.3



                                                                                                                                       8           Módulo para mujeres divorciadas, separadas y viudas
                                                                                                                                      182
 APLIQUE ESTA PREGUNTA SÓLO SI EN 6.1 HUBO AL MENOS                                      APLIQUE ESTA PREGUNTA SÓLO SI EN 6.2 HUBO AL MENOS
              UNA RESPUESTA AFIRMATIVA                                                                UNA RESPUESTA AFIRMATIVA

6.1.1 De todo lo que me dijo, ¿qué le molestaba más                                     6.2.1 De lo que me dijo, ¿qué le molestaba más a usted?
a su ex esposo o ex pareja?



                       ANOTE ELCÓDIGO CORRESPONDIENTE                                                         ANOTE ELCÓDIGO CORRESPONDIENTE


Todas le molestaban por igual ......................................... 28              Todas le molestaban por igual ......................................... 29




                                                                                                                                                                                      INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
No pudo decidir .................................................................. 29   No pudo decidir .................................................................. 30


                                                                 VI. TENSIONES Y CONFLICTOS




                                                $
LEA UNA POR UNA LAS SITUACIONES AQUÍ DESCRITAS, PRIMERO REFERIDAS AL EX ESPOSO O EX PAREJA (6.3) Y DESPUÉS RESPECTO
A LA MUJER ENTREVISTADA (6.4). LEA DESPACIO Y CON CUIDADO PARA EVITAR CONFUSIONES.




                                               5
                                                                                        6.3 Cuando su ex esposo                         6.4 Cuando usted se enojaba
                                                                                        o ex pareja se enojaba                          con su ex esposo
                                                                                        con usted …                                     o ex pareja …




                                              7
EN CADA CASO ANOTE EL CÓDIGO EN LA CASILLA CORRESPONDIENTE

                                                                                                                         Sí ................. 1
                                                                                                                         No ................ 2




                                             6
 1) ¿le dejaba de hablar?




                                            (
 2) ¿discutían?

 3) ¿le gritaba, la(o) ofendía o la(o) insultaba?




                                           8
 4) ¿golpeaba o aventaba cosas?

 5) ¿la(o) amenazaba con golpearla(o) o abandonarla(o)?

 6) ¿la(o) golpeaba o agredía físicamente?




                                          0
 7) ¿generalmente no hacía ni decía nada, se salía, se dormía?

 8) ¿hablaban o platicaban?

 9) ¿generalmente no se enojaba por nada?

10) Otro
                                                                                                     ESPECIFIQUE                                    ESPECIFIQUE



6.5 Comparando el inicio de su relación o vida en pareja con el momento
de su separación o fallecimiento de su esposo o pareja,                                                      aumentaron? .......................................... 1
¿usted diría que los conflictos o problemas entre ustedes …
                                                                                                             disminuyeron? ........................................ 2

                                       CIRCULE UN SOLO CÓDIGO
                                                                                                             se resolvieron? ...................................... 3

                                                                                                             se mantuvieron igual? ........................... 4




                                                                                        Módulo para mujeres divorciadas, separadas y viudas                                     9
                                                                                                                                                                                183
                                                                                                                                                                                                        VII. ÚLTIMA RELACIÓN

                                                                                                                                        Ahora le voy a preguntar si usted vivió o experimentó situaciones o problemas difíciles con su ex esposo o ex pareja a lo
                                                                                                                                        largo de su vida juntos y en especial después de que se separaron.

                                                                                                                                                                                                             7.1 ¿Desde que             7.2 El que          7.3 ¿Durante           7.4 Después
                                                                                                                                                                                                             inició la relación         la(le) haya         cuántos años           de que se
                                                                                                                                            LEA PRIMERO LA PREGUNTA 7.1 Y APLÍQUELA VERTICALMENTE A TODAS    con su ex esposo           (SITUACIÓN)         ocurrió esto?          separó, ¿esto
                                                                                                                                               LAS SITUACIONES, DE LA 01 A LA 30, ANOTANDO EN CADA UNA LA    o ex pareja,               ¿le parece ...                             ocurrió ...
                                                                                                                                            RESPUESTA INDICADA; DESPUÉS APLIQUE LA PREGUNTA 7.5 QUE ESTÁ
                                                                                                                                                                                                             cuántas veces ...




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                            AL FINAL DEL CONJUNTO DE SITUACIONES. CONTINÚE ENTONCES CON
                                                                                                                                              LAS PREGUNTAS 7.2, 7.3 Y 7.4 DE MANERA HORIZONTAL, PARA CADA
                                                                                                                                               UNA DE LAS SITUACIONES QUE EN 7.1 ANOTÓ LOS CÓDIGOS 1 Ó 2                                                      UN AÑO Y MENOS
                                                                                                                                                                                                              Una vez ............. 1   grave? ........ 1                          una vez? ..... 1
                                                                                                                                                                                                                                                            DE UN AÑO, ANOTE 01.
                                                                                                                                                                                                              Varias veces ..... 2      sin impor-             NO RECUERDA,        varias
                                                                                                                                                                                                                                        tancia? ....... 2         ANOTE 98         veces? ........ 2
                                                                                                                                                                                                              Ninguna vez ...... 3
                                                                                                                                                                                                                                                                                   Ninguna vez . 3
                                                                                                                                                                     SITUACIÓN




                                                                                                                                                                                  $
                                                                                                                                        1) la empujó o le jaló el pelo?

                                                                                                                                        2) la amarró?




                                                                                                                                                                                 5
                                                                                                                                        3) la pateó?

                                                                                                                                        4) le aventó algún objeto?




                                                                                                                                                                                7
                                                                                                                                        5) la golpeó con las manos o con algún objeto?

                                                                                                                                        6) trató de ahorcarla o asfixiarla?




                                                                                                                                                                               6
                                                                                                                                        7) la agredió con cuchillo o navaja?




                                                                                                                                                                              (
                                                                                                                                        8) le disparó con un arma?

                                                                                                                                        9) la avergonzó o menospreció (le decía que
                                                                                                                                           estaba fea o la comparaba con otras mujeres)?




                                                                                                                                                                             8
                                                                                                                                       10) la ignoró, no la tomó en cuenta o no
                                                                                                                                           le brindaba cariño?

                                                                                                                                       11) le dijo que usted lo engañaba?




                                                                                                                                                                            0
                                                                                                                                       12) le hizo sentir miedo?

                                                                                                                                       13) la amenazó con irse, con correrla, con dañarla,
                                                                                                                                           o con quitarle a sus hijos?

                                                                                                                                       14) la encerró, le prohibió salir o que la visitaran?

                                                                                                                                       15) hizó que sus hijos o parientes se pusieran
                                                                                                                                           en contra suya?

                                                                                                                                       16) la vigiló, espió o persiguió?

                                                                                                                                       17) llegó a amenazarla con algún arma (cuchillo,
                                                                                                                                           navaja, pistola o rifle)?

                                                                                                                                       18) amenazó con matarla, matarse él o matar
                                                                                                                                           a los niños?

                                                                                                                                       19) destruyó, tiró o escondió cosas de usted
                                                                                                                                           o del hogar?

                                                                                                                                       20) le dejó de hablar?

                                                                                                                                       21) se enojó mucho porque no estaba listo el
                                                                                                                                           quehacer; la comida no estaba como él quería
                                                                                                                                           o creía que usted no cumplía con sus
                                                                                                                                           obligaciones?

                                                                                                                                       10        Módulo para mujeres divorciadas, separadas y viudas
                                                                                                                                      184
                                                        VII. ÚLTIMA RELACIÓN

                                                             7.1 ¿Cuántas veces 7.2 ¿El que                    7.3 ¿Durante                7.4 Después
                                                             su ex esposo       la(le) haya                    cuántos años                de que se
                                                             o ex pareja ...    (SITUACIÓN) le                 ocurrió esto?               separó, ¿esto
                                                                                parece ...                                                 ocurrió ...


                                                              Una vez .............. 1   grave? ......... 1      UN AÑO Y MENOS             una vez? ...... 1
                                                                                                               DE UN AÑO, ANOTE 01.
                                                              Varias veces ...... 2      sin impor-               NO RECUERDA,              varias




                                                                                                                                                                        INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                         tancia? ........ 2          ANOTE 98               veces? ......... 2
                                                              No ocurrió ........... 3
                               SITUACIÓN                                                                                                    No ocurrió ...... 3

22) le reclamó cómo gastaba usted el dinero?

23) aunque tuviera dinero fue codo o tacaño
    con los gastos de la casa?




                                                $
24) no cumplió con dar el gasto o amenazó
    con no darlo?




                                               5
25) se gastó el dinero que se necesitaba para la
    casa?

26) se adueñó o le quitó dinero o bienes (cosas,




                                              7
    terrenos, etc.)?

27) le prohibió trabajar o estudiar?




                                             6
28) le exigió tener relaciones sexuales aunque usted
    no quisiera?

29) la obligó a hacer actos sexuales que a usted




                                            (
    no le parecían?

30) usó su fuerza física para obligarla a tener
    relaciones sexuales?




                                           8
 SI EN LA PREGUNTA 7.1 TODAS LAS RESPUESTAS SON “Ninguna vez ... 3”                      PASE A 7.6 (FILTRO)

7.5 De las agresiones anteriores, ¿cuáles son las tres que más le afectaron?




                                          0
 31) Todas le han afectado por igual
 32) Ninguna                                                                                                  ANOTE LAS SITUACIONES INDICADAS

 33) No pudo decidir


7.6 FILTRO

– PASE A LA PREGUNTA 7.7, SI EN LA PREGUNTA 7.1 SE ANOTARON CÓDIGOS 1 Ó 2 EN LAS SITUACIONES DE LA 01 A LA 08 Ó DE LA 28
  A LA 30.
– PASE A LA PREGUNTA 7.14, SI EN 7.1 ÚNICAMENTE SE ANOTARON CÓDIGOS 1 Ó 2 EN LAS SITUACIONES DE LA 09 A LA 27.
– PASE A LA SECCIÓN VIII, SI EN 7.1 SE ANOTARON ÚNICAMENTE CÓDIGOS 3 EN TODAS LAS SITUACIONES.


7.7 Cuando tuvo conflictos con su                     7.8 ¿Cuándo fue la última vez que               7.9 ¿Cómo la atendió la autoridad a la
ex esposo o ex pareja, ¿recurrió …                    recurrió a la autoridad?                        que acudió?

             CIRCULE LAS OPCIONES INDICADAS                                                                          CIRCULE UN SOLO CÓDIGO


                                                                                                      La atendieron bien, la orientaron
 al ministerio público? .......           1
                                                                                                      e informaron ..................................... 1
                                                              MES               AÑO
 a la policía preventiva? .....           2                                                           No hicieron nada, no le hicieron
                                                                                                      caso .................................................. 2
 a otra autoridad? ..............         3
                                                                                                      La trataron mal ................................. 3
                                              PASE
 Ninguna ..............................   4     A                                                     Otro                                                   4
                                               7.12                                                                          ESPECIFIQUE


                                                                           Módulo para mujeres divorciadas, separadas y viudas                                    11
                                                                                                                                                                  185
                                                                                                                                                                                                             VII. ÚLTIMA RELACIÓN

                                                                                                                                        7.10 ¿Cuando acudió ante la autoridad …                        7.11 ¿Considera que              7.12 ¿Usted no acudió a la autoridad …
                                                                                                                                                                                                       por haberlo denunciado,
                                                                                                                                                     CIRCULE LAS OPCIONES INDICADAS                    el trato de él hacia                                 CIRCULE LAS OPCIONES INDICADAS

                                                                                                                                                                                                       usted …
                                                                                                                                        denunció a su ex esposo                                                                         por miedo? ............................................................ 01
                                                                                                                                        o ex pareja? .........................................    1        CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                                                        porque su ex esposo o ex pareja
                                                                                                                                        detuvieron a su ex esposo o                                                                     la amenazó? ......................................................... 02




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                        ex pareja? ............................................   2
                                                                                                                                                                                                                                        por sus hijos? ....................................................... 03
                                                                                                                                                                                                       mejoró? .......... 1
                                                                                                                                        emitieron la orden para desalojarlo
                                                                                                                                                                                                                                        porque su familia la convenció
                                                                                                                                        de su casa? .........................................     3    mejoró por un                    de no hacerlo? ...................................................... 04
                                                                                                                                                                                                       tiempo? .......... 2     PASE
                                                                                                                                                                                                                                  A
                                                                                                                                        emitieron orden para impedirle                                                           7.13   por vergüenza? .................................................... 05




                                                                                                                                                                                      $
                                                                                                                                        que se acerque a usted? ...................               4    siguió igual? .. 3
                                                                                                                                                                                                                                        para que su familia no se enterara? .................. 06
                                                                                                                                        usted se fue de la casa? ....................             5    empeoró? ...... 4
                                                                                                                                                                                                                                        porque no sabía que podía denunciar




                                                                                                                                                                                     5
                                                                                                                                        él se fue de la casa? ...........................         6                                     la agresión? .......................................................... 07

                                                                                                                                        Usted retiró la demanda o no siguió                                                             porque se trató de algo sin importancia? ......... 08




                                                                                                                                                                                    7
                                                                                                                                        los trámites, ¿por qué? .......................           7
                                                                                                                                                                                                                                        porque pensaba que su ex esposo o ex pareja
                                                                                                                                                                                                                                        tenía derecho a reprenderla? ............................. 09




                                                                                                                                                                                   6
                                                                                                                                                                                                                                        Por desconfianza de las autoridades? .............. 10

                                                                                                                                                                                                                                        Otro ........................................................................ 11
                                                                                                                                                               ESPECIFIQUE




                                                                                                                                                                                  (
                                                                                                                                        7.13 ¿Debido a las agresiones de su ex                               7.14 Mientras              7.15 ¿Usted cree que el maltrato que recibió de
                                                                                                                                        esposo o ex pareja …                                                 estuvieron juntos,         su ex esposo o ex pareja, inició o empeoró,




                                                                                                                                                                                 8
                                                                                                                                                                                                             ¿esta manera de            debido a …
                                                                                                                                                        CIRCULE LAS OPCIONES INDICADAS                       reaccionar de su
                                                                                                                                                                                                             ex esposo o ex                                 CIRCULE LAS OPCIONES INDICADAS

                                                                                                                                                                                                             pareja ante los
                                                                                                                                        usted tuvo que operarse? .......................... 01               problemas …                problemas económicos? .................................... 01




                                                                                                                                                                                0
                                                                                                                                        usted tuvo moretones o hinchazón? ......... 02                       CIRCULE UN SOLO CÓDIGO     la pérdida de empleo? ......................................... 02

                                                                                                                                        usted tuvo cortadas, quemaduras                                                                 que él tenía otra relación amorosa? .................. 03
                                                                                                                                        o pérdida de dientes? ................................. 03
                                                                                                                                                                                                                                        que usted tenía otra relación amorosa? ........... 04
                                                                                                                                                                                                              mejoró? ........... 1
                                                                                                                                        usted tuvo hemorragias o sangrado? ...... 04
                                                                                                                                                                                                                                        que usted comenzó a trabajar? ......................... 05
                                                                                                                                        usted tuvo fracturas? ................................. 05            empeoró? ....... 2
                                                                                                                                                                                                                                        que recibe apoyo de Oportunidades? ................ 06
                                                                                                                                        usted tuvo un aborto o parto prematuro?                       06      siguió igual? ... 3
                                                                                                                                                                                                                                        que llegó a vivir con ustedes alguna persona?                               07
                                                                                                                                        usted tuvo ardor o sangrado vaginal? ...... 07
                                                                                                                                                                                                                                        que usted no se embarazó? ............................... 08
                                                                                                                                        usted tuvo desmayos? ............................... 08
                                                                                                                                                                                                                                        que usted se embarazó? .................................... 09
                                                                                                                                        no puede mover alguna parte
                                                                                                                                        de su cuerpo? ............................................. 09                                  el nacimiento de un hijo? .................................... 10

                                                                                                                                        resultó lesionado un familiar? ................... 10                                           que él tomaba? ..................................................... 11

                                                                                                                                        falleció algún miembro del hogar? ............ 11                                               No sabe por qué lo hacía ..................................... 12

                                                                                                                                        No le pasó nada .......................................... 12                                   Por ninguna razón ................................................ 13

                                                                                                                                        Otro                                                          13                                Otro                                                                        14
                                                                                                                                                                   ESPECIFIQUE                                                                                           ESPECIFIQUE




                                                                                                                                       12       Módulo para mujeres divorciadas, separadas y viudas
                                                                                                                                      186
                                                                             VII. ÚLTIMA RELACIÓN

7.16 Cuando tuvo problemas con su                                                 7.17 ¿Debido a los problemas                          7.18 ¿Los problemas con su
ex esposo o ex pareja, ¿platicó o pidió                                           con su ex esposo o ex pareja,                         ex esposo o ex pareja le
ayuda a …                                                                         usted …                                               provocaron …

                CIRCULE LAS OPCIONES INDICADAS                                           CIRCULE LAS OPCIONES INDICADAS                       CIRCULE LAS OPCIONES INDICADAS



familiares? ....................................................... 1            dejó de comer? ...................... 1                pérdida o aumento
                                                                                                                                        de apetito? ...............................         1




                                                                                                                                                                                                      INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
amigas? ........................................................... 2            dejó de salir? .......................... 2
                                                                                                                                        problemas nerviosos? ...........                    2
un sicólogo, trabajador social? ..................... 3                          dejó de ir al médico? ............. 3
                                                                                                                                        angustia o miedo? ..................                3
un sacerdote o instancias religiosas? ......... 4                                dejó de trabajar
                                                                                 o estudiar? .............................. 4




                                                     $
                                                                                                                                        tristeza, aflicción
al DIF? ............................................................... 5                                                               o depresión? ............................           4
                                                                                 perdió dinero
una organización no gubernamental (ONG)?                                6        o propiedades? ...................... 5                insomnio? ................................          5




                                                    5
algún refugio para mujeres maltratadas? ... 7                                    No pasó nada ......................... 6               No le pasó nada ......................              6

No platicaba ni pedía ayuda ............................ 8                       Otro .......................................... 7




                                                   7
                                                                                                                                        Otro ...........................................    7

Otro ................................................................... 9




                                                  6
7.19 ¿Recibió atención                           7.20 ¿A dónde fue?                                           7.21 Durante el tiempo que                      7.22 ¿Intentó
médica por los problemas                                                                                      vivió con su ex esposo o a raíz                 hacerlo?
con su ex esposo o ex                                   CIRCULE LAS OPCIONES INDICADAS                        de esta relación, ¿alguna vez




                                                 (
pareja?                                                                                                       pensó en quitarse la vida?                        CIRCULE UN SOLO CÓDIGO

                                                   Médico particular ................            1
       CIRCULE UN SOLO CÓDIGO                                                                                       CIRCULE UN SOLO CÓDIGO




                                                8
                                                   Cruz Roja ............................        2

    Sí .... 1                                      IMSS ....................................     3               Sí ....... 1                                       Sí ....... 1




                                               0
    No .. 2              PASE A 7.21
                                                   ISSSTE ...............................        4               No ..... 2          PASE A 7.23                    No ..... 2

                                                   Salubridad ..........................         5

                                                   Otro .....................................    6


7.23 ¿Quién tomó la decisión                        7.24 ¿Su ex pareja o ex esposo …                              7.25 ¿Cuánto tiempo              7.26 Cuando se separaron
de separarse?                                                                                                     le llevó separarse,              o divorciaron …
                                                            CIRCULE LAS OPCIONES INDICADAS                        desde que lo pensó
          CIRCULE UN SOLO CÓDIGO                                                                                  hasta que lo logró?                     CIRCULE UN SOLO CÓDIGO
                                                    aceptó o estuvo de acuerdo
                                                    con su decisión? ........................             1
Usted ................... 1
                                                                                                                                                   ¿usted se fue
                                                    se negó? .....................................        2                                        de la casa? ....... 1
Su ex pareja ........ 2                PASE
                                                                                                                     ANOTE CON NÚMERO
                                         A
                                        7.26
                                                    la amenazó con quitarle                                                                        ¿él se fue
Ambos ................. 3                           a sus hijos? ................................         3          SI LA RESPUESTA ES
                                                                                                                  MENOS DE UN AÑO, ANOTE 00        de la casa? ....... 2
                                                                                                                                                                                           PASE
Él se fue a                                                                                                                                                                                  A
                                                    la amenazó con quitarle                                                                        ¿no vivían                               7.28
Estados Unidos .. 4                                 la casa o sus pertenencias? ....                      4
                                       PASE                                                                                                        juntos? .............. 3
                                       A LA
Enviudó ................ 5           SECCIÓN
                                                    la sacó o corrió de la casa? .....                    5
                                        VIII

Otro ...................... 6                       Otro ..............................................   6




                                                                                                      Módulo para mujeres divorciadas, separadas y viudas                                       13
                                                                                                                                                                                                187
                                                                                                                                                                                                                   VII. ÚLTIMA RELACIÓN

                                                                                                                                        7.27 Usted ¿se fue ...                                         7.28 ¿Qué sucedió con las pertenencias                            7.29 ¿Su(s) hijo(s) e hija(s) ...
                                                                                                                                                                                                       comunes?
                                                                                                                                                        CIRCULE UN SOLO CÓDIGO                                                                                                          CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                                        CIRCULE UN SOLO CÓDIGO


                                                                                                                                        con sus padres? .............................. 1               Llegaron a un arreglo ........................... 1               se fueron con usted? .......................... 1
                                                                                                                                        con otros parientes? ....................... 2                 Dividieron las pertenencias ................. 2                   se fueron con su ex esposo
                                                                                                                                        con amigas? ..................................... 3            Le quitó sus pertenencias .................... 3                  o ex pareja? .......................................... 2




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                        a un refugio? ..................................... 4          No han llegado a ningún arreglo                                   ¿Está en litigio la custodia? ................ 3
                                                                                                                                                                                                       o acuerdo .............................................. 4        No tiene hijos o ya están grandes ....... 4
                                                                                                                                        a otra casa o departamento sola
                                                                                                                                        o con sus hija(s)/hijo(s)? ................. 5                 No tenían bienes comunes .................. 5                     Otro                                                          5
                                                                                                                                                                                                                                                                                                  ESPECIFIQUE
                                                                                                                                        Otro lugar ........................................... 6       Otro ........................................................ 6




                                                                                                                                                                                         $
                                                                                                                                        7.30 Para la manutención de sus hijas e hijos,                              7.31 ¿Su ex esposo o ex pareja ha                            7.32 Desde que se separaron,
                                                                                                                                        ¿su ex esposo o ex pareja y usted …                                         cumplido con el acuerdo económico                            ¿su ex esposo o ex pareja …




                                                                                                                                                                                        5
                                                                                                                                                                                                                    establecido ...
                                                                                                                                                              CIRCULE UN SOLO CÓDIGO                                                                                                       CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                                                  CIRCULE UN SOLO CÓDIGO
                                                                                                                                        llegaron a un arreglo voluntario? . 1




                                                                                                                                                                                       7
                                                                                                                                        llegaron a un acuerdo legal? ........ 2                                     siempre o casi siempre? ............ 1                       ha entrado a su casa sin su
                                                                                                                                                                                                                                                                                 consentimiento, por la fuerza? .. 1
                                                                                                                                        No llegaron a ningún acuerdo ....... 3                                      pocas veces? ............................... 2




                                                                                                                                                                                      6
                                                                                                                                        Sus hijos ya eran grandes                                    PASE           nunca? .......................................... 3          ha intentado entrar a su casa
                                                                                                                                                                                                        A
                                                                                                                                        o no tenían ...................................... 4          7.32
                                                                                                                                                                                                                                                                                 sin su consentimiento? .............. 2




                                                                                                                                                                                     (
                                                                                                                                        Otro .................................................. 5


                                                                                                                                                                                                       VIII. DISPONIBILIDAD DE RECURSOS




                                                                                                                                                                                    8
                                                                                                                                        8.1 ¿Algún(os) miembro(s) de este hogar                                                                                              8.2 ¿A nombre de quién están?
                                                                                                                                        es (son) propietario(s) de …                                                                                                         ¿A quién le pertenecen?
                                                                                                                                                                                                                                                                                  Sólo la entrevistada ..................... 1




                                                                                                                                                                                   0
                                                                                                                                        ANOTE EN CADA CASILLA EL CÓDIGO INDICADO                                                        Sí ............... 1                      Sólo el ex esposo o ex pareja .... 2
                                                                                                                                                                                                                                        No .............. 2                       Ambos .......................................... 3
                                                                                                                                                                                                                                                                                  Otra(s) persona(s) ...................... 4

                                                                                                                                        1) terreno(s) o tierras de cultivo?

                                                                                                                                        2) automóvil(es) o camioneta(s)?

                                                                                                                                        3) ahorros?

                                                                                                                                        4) la vivienda que habitan?

                                                                                                                                                                                     IX. OPINIÓN SOBRE LOS ROLES MASCULINOS Y FEMENINOS

                                                                                                                                        9.1. Le voy a leer algunas frases, dígame SÍ cuando esté de acuerdo y NO cuando esté en desacuerdo.                                                                      Sí ........... 1
                                                                                                                                                                                                                                                                                                                 No .......... 2
                                                                                                                                                                                                    ANOTE EN CADA CASILLA EL CÓDIGO INDICADO


                                                                                                                                          1) ¿Una buena esposa debe obedecer a su esposo en todo lo que él ordene? ...........................................................
                                                                                                                                          2) ¿Una mujer puede escoger sus amistades aunque a su esposo no le guste? ........................................................
                                                                                                                                          3) ¿El hombre debe responsabilizarse de todos los gastos de la familia? ...................................................................
                                                                                                                                          4) ¿Una mujer tiene la misma capacidad que un hombre para ganar dinero? .............................................................
                                                                                                                                          5) ¿Es obligación de la mujer tener relaciones sexuales con su esposo aunque ella no quiera? .............................
                                                                                                                                          6) ¿Cuando la mujer no cumple con sus obligaciones, el marido tiene el derecho de pegarle? ................................

                                                                                                                                       14        Módulo para mujeres divorciadas, separadas y viudas
                                                                                                                                      188
                                          IX. OPINIÓN SOBRE LOS ROLES MASCULINOS Y FEMENINOS

9.2. ¿Usted está de acuerdo en que ...                           Sí ........... 1     9.3 ¿Usted se considera …                                                 9.4. ¿Usted ha oído
                                                                 No .......... 2                                                                                hablar de la igualdad
ANOTE EN CADA CASILLA EL CÓDIGO INDICADO
                                                                                                    ANOTE EN CADA CASILLA                  Sí ............ 1    entre mujeres y
                                                                                                     EL CÓDIGO INDICADO
                                                                                                                                           No ........... 2     hombres?
1) las mujeres y los hombres tengan los mismos
   derechos para tomar sus decisiones? ............
                                                                                                                                                                  CIRCULE UN SOLO CÓDIGO
2) las mujeres y los hombres tengan                                                    1) valiosa? ........................................
   la misma libertad? ..................................................
3) las mujeres tengan el derecho a defenderse                                          2) atractiva? .....................................




                                                                                                                                                                                                      INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
   y denunciar cualquier maltrato o agresión? .......                                                                                                                    Sí ........ 1
                                                                                       3) con derechos? .............................
4) las mujeres tengan la posibilidad de decidir
   sobre su propia vida? ............................................                  4) que expresa sus opiniones? ......                                              No ...... 2
5) las mujeres tengan derecho a vivir una
   vida libre de violencia? ..........................................




                                                  $
                                                                           X. RECURSOS SOCIALES

10.1 Cuando necesita dinero, sin                                 10.2 ¿Acostumbra usted ...




                                                 5
contar a su ex esposo o ex pareja,
¿recurre a sus ...                                                                                          CIRCULE LAS OPCIONES INDICADAS


                                                                 salir con amigas a divertirse? ............................................................................             1




                                                7
          CIRCULE LAS OPCIONES INDICADAS

                                                                 platicar con vecinas? ..........................................................................................        2
 amigas? .......................................... 1            reunirse con familiares? .....................................................................................          3




                                               6
 vecinas? ......................................... 2            asistir a reuniones religiosas? ...........................................................................             4
 familiares? ...................................... 3            asistir a reuniones de colonos o de organizaciones? .....................................                               5




                                              (
 No pide dinero ................................ 4               practicar deportes en equipo? ...........................................................................               6
 Otro _________________________ 5                                Otro                                                                                                                    7
                       ESPECIFIQUE                                                                                       ESPECIFIQUE




                                             8
VERIFIQUE LA RESPUESTA EN LA PREGUNTA 2.4 DE LA SECCIÓN II DEL CUESTIONARIO GENERAL Y SI LA MUJER ELEGIDA TIENE 60
AÑOS O MÁS APLIQUE LA SECCIÓN XI, EN CASO CONTRARIO PASE A LA SECCIÓN XII.


                                                                  XI. MUJERES DE 60 AÑOS O MÁS




                                            0
11.1 ¿Usted depende                                              11.2 ¿Usted a veces ayuda                                           11.3 ¿Mantiene económicamente a
económicamente de su(s) …                                        económicamente, le da dinero                                        su(s) …
                                                                 o le paga alguna cosa a su(s) …
          CIRCULE LAS OPCIONES INDICADAS                                                                                                         CIRCULE LAS OPCIONES INDICADAS
                                                                            CIRCULE LAS OPCIONES INDICADAS
 ex esposo o ex pareja? ................. 1
 hija(s) o hijo(s)? ............................. 2              hija(s) o hijo(s)? ............................. 1                  hija(s) o hijo(s)? ............................ 1

 nieta(s) o nieto(s)? ......................... 3                nieta(s) o nieto(s)? ......................... 2                    nieta(s) o nieto(s)? ........................ 2

 No depende de nadie ..................... 4                     No apoya a nadie ............................ 3                     No mantiene a nadie ..................... 3

 Otro                                                  5         Otro .................................................. 4           Otro ................................................. 4
                       ESPECIFIQUE



11.4 ¿Usted cuida a sus nietos …                                 11.5 ¿Es responsable de sus nietos porque sus                                         11.6 ¿Tiene alguna
                                                                 padres …                                                                              enfermedad o impedimento
                CIRCULE UN SOLO CÓDIGO                                                                                                                 que no le permiten
                                                                                         CIRCULE UN SOLO CÓDIGO
                                                                                                                                                       desplazarse sola?
 todos los días? ................... 1                            trabajan y viven en Estados Unidos? .............. 1
                                                                                                                                                               CIRCULE UN SOLO CÓDIGO
 algún día de la semana? ... 2                                    trabajan y viven en otro lugar del país? .......... 2
 de vez en cuando? ............. 3                  PASE          trabajan todo el día? ......................................... 3                               Sí .......... 1
                                                      A
 No los cuida ........................ 4             11.6
                                                                  murieron? .......................................................... 4
                                                                                                                                                                  No ....... 2
 No tiene nietos .................... 5                           Otro ..................................................................... 5

                                                                                                   Módulo para mujeres divorciadas, separadas y viudas                                          15
                                                                                                                                                                                                189
                                                                                                                                                                                              XI. MUJERES DE 60 AÑOS O MÁS

                                                                                                                                                                                                                                                          Sí .................. 1
                                                                                                                                                ANOTE LA RESPUESTA INDICADA EN CADA UNA DE LAS
                                                                                                                                                                  CASILLAS                                                                                No ................. 2
                                                                                                                                                                                                                                                          No aplica ...... 3

                                                                                                                                         11.7 Dígame si usted pasa o ha pasado por alguna                                       Hija(s)            Hijo(s)               Nieta(s) o             Otro
                                                                                                                                         de las siguientes situaciones con sus familiares                                                                                 nieto(s)
                                                                                                                                         cercanos o con quienes vive:




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                             1) ¿Le dejan de hablar o no le hablan?

                                                                                                                                             2) ¿La dejan sola, la abandonan?

                                                                                                                                             3) ¿Le gritan, la insultan, la ofenden?




                                                                                                                                                                                  $
                                                                                                                                             4) ¿No le dan dinero?

                                                                                                                                             5) ¿La han amenazado con correrla o sacarla de su casa?




                                                                                                                                                                                 5
                                                                                                                                             6) ¿La han lastimado o golpeado?

                                                                                                                                             7) ¿Le han quitado su dinero o alguna pertenencia?




                                                                                                                                                                                7
                                                                                                                                             8) ¿Le han dicho o le hacen sentir que es un estorbo?




                                                                                                                                                                               6
                                                                                                                                             9) ¿No la atienden cuando se enferma o no le compran
                                                                                                                                                sus medicamentos?

                                                                                                                                         10) ¿Le piden que haga quehaceres que no puede hacer




                                                                                                                                                                              (
                                                                                                                                             o que le cuestan trabajo?

                                                                                                                                         11) ¿No la apoyan o ayudan cuando lo necesita?




                                                                                                                                                                             8
                                                                                                                                                                                                      XII. ENTREVISTADORA

                                                                                                                                         12.1 ¿Dónde se levantó la entrevista?               12.2 ¿La entrevista a la mujer elegida                  12.3 Durante la entrevista, ¿la mujer




                                                                                                                                                                            0
                                                                                                                                                                                             se …                                                    elegida …
                                                                                                                                                     CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                          CIRCULE UN SOLO CÓDIGO                                    CIRCULE UN SOLO CÓDIGO


                                                                                                                                         Dentro de la vivienda ........................ 1    realizó en el primer intento? ........... 1             estaba sola? ..................................... 1

                                                                                                                                         Fuera de la vivienda .......................... 2   tuvo que regresar según                                 estaba presente su ex esposo? .... 2
                                                                                                                                                                                             indicaciones? ................................... 2
                                                                                                                                         En otro lugar                                  3                                                            estaban sus hijos? .......................... 3
                                                                                                                                                                  ESPECIFIQUE                Otro __________________________ 3
                                                                                                                                                                                                                 ESPECIFIQUE
                                                                                                                                                                                                                                                     estaban otros familiares
                                                                                                                                                                                                                                                     o personas? ..................................... 4

                                                                                                                                             VERIFIQUE LA PREGUNTA 2.11 DE LA SECCIÓN II DEL CUESTIONARIO GENERAL: SI HAY MUJER SOLTERA ELEGIDA APLIQUE EL
                                                                                                                                                                                    MÓDULO PARA MUJERES SOLTERAS.




                                                                                                                                        16      Módulo para mujeres divorciadas, separadas y viudas
                                                                                                                                      190
