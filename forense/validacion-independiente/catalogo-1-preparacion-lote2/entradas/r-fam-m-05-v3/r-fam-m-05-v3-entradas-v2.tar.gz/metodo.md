# Método: extracción fiel de especificación humana

`codificacion-R-v1_2.tsv`, sucesora registral de v1.1 que conserva el estimando y explicita reservas: payload `enigh2016_nc_csv`,

codificación `y=1 si remesas > 0; y=0 si remesas == 0 -- UMBRAL NUMERICO, no conjunto de codigos: remesas es monto continuo en pesos con 1313 valores distintos en 2016`, ponderador `factor`, estrato

`est_dis` y UPM `upm`. Ninguno de esos campos se elige en la corrida.

Este sucesor técnico no añade una medición: hereda el conteo único de la cadena desde `CALC-R-FAM-M-05-v2`, cuyo objeto firmado es la medición R de `FAM-M-05`.
