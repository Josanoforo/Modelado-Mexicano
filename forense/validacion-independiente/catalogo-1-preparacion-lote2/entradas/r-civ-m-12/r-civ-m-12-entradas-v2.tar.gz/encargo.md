# Reconstruccion independiente

Sesion nueva sin historial. Lee solo estas entradas y los insumos enumerados. Implementa cada llave de estimandos.tsv desde metodo.md y documentos humanos, con bibliotecas genericas. Si falta metodo, tolerancia o acceso, informa el faltante sin adivinar. Congela codigo propio y numeros antes de pedir revelacion. Conserva hash de manifiesto.json.
