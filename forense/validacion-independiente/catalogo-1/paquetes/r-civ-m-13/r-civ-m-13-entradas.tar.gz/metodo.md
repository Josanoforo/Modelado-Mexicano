# Método: extracción fiel de especificación humana

## Qué mide

**Dos estimandos sobre la misma lectura del mismo archivo**, cada uno con su escala declarada:

1. **PRIMARIO — el árbitro `R`.** Proporción ponderada de delitos con razón principal de
   no-denuncia en `{01, 02, 06}` (miedo al agresor · miedo a extorsión · desconfianza en la
   autoridad), sobre el universo de **todos** los delitos con `BP1_23 ∈ {01..09}`, ponderador
   `FAC_DEL`, diseño `EST_DIS`/`UPM_DIS`. La codificación, el universo, el ponderador y el
   diseño se copian **verbatim** de `forense/prereg-duelo-v2/codificacion-R-v1_0.tsv`; la
   variable y la escala, de `espec-R-ciega-v1_2.tsv`. **Ninguno lo elige el ejecutor.**
2. **SECUNDARIO HOMOLOGADO — el punto de serie.** El mismo desenlace bajo el universo `U1` y la
   codificación `C1` de `prereg-caja-ENVIPE-DENUNCIA` (delitos **personales** `BPCOD 05..15`,
   `BP1_20 = 2`, denominador `{01..08}`), para que esta ola pueda ponerse junto al punto de la
   ola 2025 sin cambiar dos cosas a la vez. Se emite también `C2` (la partición GEN1) y el delta.

**`U_R` y `U1` no se comparan entre sí** (`A-bis.4`): están en la misma corrida porque salen de
la misma lectura, no porque sean comparables.

## Identidad del insumo

| campo | valor |
|---|---|
| `id` de manifiesto | **`envipe2024_csv`** — resuelto por `tests/payload_resolver.py`, nunca por heurística |
| miembro | `tmod_vic_envipe2024/conjunto_de_datos/conjunto_de_datos_tmod_vic_envipe2024.csv` |
| `Identifier` (metadato) | `MEX-INEGI.EGS3.02-ENVIPE-2024` |
| `Temporal` (metadato) | `2023-01-01-2023-12-31, 2024-03-01-2024-04-30 y 2024-03-01-2024-12-31` → **delitos de 2023** |
| catálogo `bp1_23` | leído en **UTF-8** (la codificación se prueba por archivo, no por ZIP) |

**Nota de esta ola:** el catalogo y el descriptor declaran el codigo b (blanco).
**Redacción del reactivo en esta ola:** lenguaje de genero: 'Por miedo al (a la) agresor(a)', 'que lo (la) extorsionaran' — ninguna de esas diferencias mueve un código.

## Diseño

`EST_DIS` y `UPM_DIS` se agrupan como **cadenas opacas** (nunca `int()`, nunca `zfill()`). El
descriptor de esta ola declara `EST_DIS Caracter(3), 001..607 SEGUN DESCRIPTOR` y `UPM_DIS Caracter(7), 0000001..9999999 SEGUN DESCRIPTOR`; el perfil **real**
se emite en `RESULT-R-CIV-M-13-PERFIL-DISENO`, porque el descriptor ya mintió sobre esto en la
ola 2025. `EE` e `IC95` por conglomerado último con `tests/svystat.py:prop_ultimate_cluster`,
**importado y no reimplementado**. Un estrato con una sola UPM entra al punto, aporta varianza
cero, y su conteo va en `N-ESTRATOS-UPM-UNICA`; si es `> 0`, el IC es **límite inferior** de la
anchura verdadera.

