| conducta | texto (A.15) | regla |
|---|---|---|
| ALCOHOL-12M | al4 «En los últimos 12 meses, ¿tomó alguna bebida que contenga alcohol?» | 1 → 1; 2 → 0; al1 = 2 (nunca) → 0 |
| ALCOHOL-30D | al9 «En los últimos 30 días…» | 1 → 1; 2 → 0; al1 = 2 o al4 = 2 → 0 |
| ALCOHOL-EXCESIVO-12M | al11 «mayor número de copas en un solo día (12 meses)» | hombres 5+ copas (códigos 1–4), mujeres 4+ (1–5) → 1; resto → 0; no bebió 12 m → 0; 9 fuera |
| FUMA-ACTUAL | tb02 «¿Actualmente fuma tabaco todos los días, algunos días o no fuma?» | 1, 2 → 1; 3 → 0; sin dato y tb05 = 2 (nunca) → 0 |
| CIGARRO-ELECTRONICO-ALGUNA-VEZ | tb50 «¿Alguna vez… usó un cigarro electrónico?» | 1 / 2 |
| DROGA-ILEGAL-ALGUNA-VEZ | di1a–di1i «¿ha tomado, usado, probado…?» (9 sustancias) | alguna = 1 → 1; todas = 2 → 0 |
| MARIGUANA-ALGUNA-VEZ | di1a | 1 / 2 |
| DROGA-MEDICA-SIN-RECETA-ALGUNA-VEZ | dm1a–dm1d | alguna = 1 → 1; todas = 2 → 0 |
| OPIACEOS-SIN-RECETA-ALGUNA-VEZ | dm1a «Opiáceos…» (sin tramadol en el texto 2016) | 1 / 2 |
| CONSULTO-PROFESIONAL-POR-CONSUMO | tp1 «¿Alguna vez… ha consultado a algún profesional de la salud por su uso de alcohol o drogas…?» | 1 / 2 (universo = a quien el cuestionario se lo preguntó; N se reporta) |
