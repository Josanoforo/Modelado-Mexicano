# Método: extracción fiel de especificación humana

## Qué mide

**Dos estimandos sobre la misma lectura del mismo archivo:**

**`U_R` y `U1` no se comparan entre sí** (`A-bis.4`).

## Identidad del insumo

| campo | valor |
|---|---|
| `id` de manifiesto | **`envipe_2013_bd_envipe13_dbf`** |
| miembro del ZIP | `tmod_vic.dbf` — literal, nunca por plantilla |
| filas (cabecera DBF) | 47,117 |
| descriptor citado | `FD_ENVIPE13.xlsx, hoja TMod_Vic` — `BP1_23` fila 292, `BPCOD` fila 30, diseño filas 626 (FAC_DEL), 632 (EST), 633 (UPM) |

## Vínculo de columnas (rol → nombre físico en ESTA ola)

| rol | nombre físico | tipo en la cabecera del `.dbf` |
|---|---|---|
| `BP1_23` | `BP1_23` | Caracter(2) |
| `BP1_20` | `BP1_20` | Caracter(1) |
| `BPCOD` | `BPCOD` | Caracter(2) |
| `FAC_DEL` | `FAC_DEL` | Caracter(6) |
| `ESTRATO` | **`EST`** | Caracter(3) |
| `UPM` | **`UPM`** | Caracter(5) |
