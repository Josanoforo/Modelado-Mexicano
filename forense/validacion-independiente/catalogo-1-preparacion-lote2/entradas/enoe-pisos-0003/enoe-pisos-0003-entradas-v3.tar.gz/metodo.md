# Método: extracción fiel de especificación humana


Unidad **persona de 15–98 años**, aun en los paquetes antiguos con mínimo
original menor; `R_DEF=00`, `C_RES∈{1,3}`, ponderador positivo, `EST_D` y
`UPM` presentes. ENOE clásica usa `FAC`/`EST_D`; ENOEN y post-2023 usan
`FAC_TRI`/`EST_D_TRI`. El instrumento documenta SDEM como capa de
preclasificación del cuestionario de ocupación y empleo; los códigos no son
rasgos psicológicos. Los blancos no son valores observados; donde el propio
precódigo define pertenencia por código 1, el resto de ocupados válidos es 0.

| Conducta | Reactivo o precódigo | Denominador | Punto y unidad |
| --- | --- | --- | --- |
| empleo_informal | `EMP_PPAL=1` informal; 2 formal | `CLASE2=1`, `EMP_PPAL∈{1,2}` | proporción |
| sector_informal | `TUE_PPAL=1` sector informal; 2 fuera, blanco formal | todos los ocupados `CLASE2=1` | proporción |
| subocupacion | `SUB_O=1` sí subocupado | todos los ocupados | proporción |
| busca_otro_trabajo | `BUSQUEDA=1` busca adicional; 2 no | ocupados con 1/2 | proporción |
| pluriempleo | sección VII; `T_TRA=2` dos trabajos; 1 uno | ocupados con 1/2 | proporción |
| sin_contrato_escrito | COE `P3i` contrato por escrito; derivada `TIP_CON=5` sin; 1–4 con; 6 no especificado | `REMUNE2C∈{1,2}` y `TIP_CON∈{1,…,5}`, ocupado | proporción |
| jornada_mas_50_horas | COE `P5b` horas semana pasada; `HRSOCUP>50` | ocupado con `HRSOCUP∈[1,168]` | proporción |
| desocupacion | `CLASE2=2` | PEA `CLASE1=1` | proporción |
| desaliento_desistio | `PNEA_EST=1` disponible que desistió | PNEA clasificada 1–6 | proporción |
| desaliento_sin_posibilidades | `PNEA_EST=2` no busca por considerar que no hay posibilidades | PNEA clasificada 1–6 | proporción |
| no_participacion_obligaciones | `PNEA_EST=4` otras obligaciones | PNEA clasificada 1–6 | proporción |
| horas_ocupado | `HRSOCUP∈[1,168]` | ocupados con horas válidas | media semanal |
| ingreso_ocupado_nominal | COE `P6b`/`INGOCUP∈[1,999998]` | ocupados con ingreso mensual positivo válido | media nominal, pesos/mes |

`PNEA_EST=4` **no se rotula cuidados**: el código no distingue el cuidado de
otras obligaciones. Cuidado específico queda `NO-ESTIMABLE-CON-SDEM` en el
cierre; requeriría COE P2G2, texto/códigos y saltos por era. Ningún silencio
se cuenta como desaliento. `TUE_PPAL` no se usa como sinónimo de empleo
informal. No se usa el descriptor «trabajo riesgoso» para aversión al riesgo.

`HRSOCUP` es la clasificación oficial de horas de trabajo de la semana,
incluidas las categorías válidas para varios trabajos según su precódigo;
ocupados ausentes sin 1–168 horas salen del denominador de jornada y media.
No se imputa cero. `INGOCUP` es ingreso mensual nominal; cero, blanco, `999999`
y fuera de [1,999998] no se imputan. **No se deflacta**: no hay deflactor
oficial con id y hash en este contrato. Su media es descripción de cada ola,
sin comparación de poder de compra entre trimestres ni calibración de ingreso
real. Media no se cambia por mediana tras ver el resultado.

## Ejes, soporte y diseño

Se estiman cortes **univariados**: nacional; sexo `SEX` 1/2; edad 15–29,
30–44, 45–59, 60+; escolaridad oficial `NIV_INS` 1 primaria incompleta,
2 primaria completa, 3 secundaria, 4 medio superior y superior; tamaño de
localidad `T_LOC` 1/2/3/4; entidad `ENT` 01–32. No hay cruces ni resultados
municipales. El rótulo de escolaridad 4 preserva la categoría oficial y no
separa superior de media superior. Una categoría faltante solo sale de su eje.

Punto `Σw·y/Σw`; IC95 percentil con **200 réplicas** de UPM con reemplazo
dentro de estrato, semilla `PCG64(42+i_ola)`. Un plan por ola compartido en
todas sus celdas, y UPM sin miembros de un dominio se conservan con subtotal
cero. Se conserva `n`, `n_efectivo_kish=(Σw)²/Σw²`, número de UPM y calidad
por CV de réplicas: ALTA `<15%`, MODERADA `15–<30%`, BAJA `≥30%` o punto 0.
Se suprime punto e IC cuando `n<100`, `n_efectivo_kish<100`, menos de 2 UPM
en el dominio o menos de 95% réplicas válidas. `n_efectivo_kish` es diagnóstico
de pesos, no reemplaza el diseño: UPM y CV se reportan por separado.

## Serie y límites fijados antes del dato

Las 43 olas conservan periodicidad trimestral con huecos reales: tres cortes
documentales 2005/2008/2012/2014; tramo continuo 2016T1–2020T1; hueco
2020T2 (ETOE, no ENOE); ENOEN 2020T3–2022T4; post-2023. La misma columna
no autoriza comparar como serie homogénea a través del cambio de modo.
No se interpola. Ingreso nominal no se contrasta temporalmente. La tabla de
puntos e IC de diseño es el piso transversal de cada ola elegible.

Transición formal/informal **NO IDENTIFICADA CON ESTOS INSUMOS**: el panel
rotatorio de cinco visitas existe, pero los pesos publicados son transversales;
no hay ponderador longitudinal por persona ni attrition acreditada para el
enlace de hogares/personas. No se empareja por edad/sexo ni se restan
prevalencias para simular entradas/salidas.

Persistencia temporal se evaluará solo dentro de eras y con olas trimestrales
adyacentes, origen móvil, sin ola destino en el ajuste. La comparación de
puntos de prevalencia se describe como retrospectiva. **No se emite IC
predictivo calibrado** sin réplica conjunta que preserve el solapamiento del
panel entre trimestres; los IC del CALC son de diseño **dentro** de cada ola.
El estado de calibración de esta versión es
`SIN-COVARIANZA-LONGITUDINAL-PARA-CALIBRAR`. No hay prueba de cambio entre

ENOEN/post-2023 llaman `t_loc_tri` a la clasificación trimestral de localidad.
por `cve_ent`; ninguna otra ola pierde una columna obligatoria. V1.2 mapea
`cve_ent` a la **misma entidad de dos dígitos** donde `ent` no existe.
