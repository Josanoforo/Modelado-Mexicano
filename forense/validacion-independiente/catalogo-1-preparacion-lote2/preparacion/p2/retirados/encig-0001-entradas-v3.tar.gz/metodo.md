### 3.1 · Regla general

- Sumas ponderadas en **orden fijo de fila**. `p = Σ(w·d)/Σ(w)`.
- **Cero NUNCA sustituye falta de dato.** Blanco, `9`/`99` y no-numérico se
  **cuentan aparte** y salen del denominador; no se imputan.
- Escala de toda proporción: `[0,1]`. Dirección declarada por `RESULT`.
- Si falta una columna declarada → `NO-ESTIMABLE-COLUMNA-AUSENTE:<col>`; si
  existe y no tiene ningún valor válido → `NO-ESTIMABLE-COLUMNA-VACIA:<col>`;
  si un universo queda vacío → `NO-ESTIMABLE-UNIVERSO-VACIO`.
- **`NO-APLICA` es un valor** y se escribe como tal.

### 3.2 · Familia A · unidad **PERSONA**, ponderador `FAC_P18`

- `U_A` = filas de `encig2025_01_sec1_A_3_4_5_8_9_10.csv` con
  `P8_3_1 ∈ {1,2}` **y** `FAC_P18` finito `> 0`.
- `d(SOL1) = 1` si `P8_3_1 = 1`, `0` si `P8_3_1 = 2`.
- `d(SOLANY) = 1` si **alguno** de `P8_3_1, P8_3_2, P8_3_3` `= 1`; `0` si los
  tres están en `{2}`. Las filas con algún `9`/blanco en `P8_3_2`/`P8_3_3` pero
  `P8_3_1 ∈ {1,2}` **permanecen en `U_A`** y se cuentan aparte
  (`A-N-SOLANY-PARCIAL`): un `9` en un inciso no borra un `1` en otro, pero sí
  impide afirmar el `0`. Regla: si algún inciso `= 1` → `d = 1`; si ninguno
  `= 1` y **alguno** es `9`/blanco → la fila **sale** de `U_SOLANY` (contada);
  si los tres son `2` → `d = 0`.
- Residuo del reactivo, **contado**: `P8_3_1 ∈ {9}` (`A-N-P831-NSNR`) y
  `P8_3_1` blanco/no numérico (`A-N-P831-BLANCO`).
- **Dirección:** más alto = más solicitud de soborno declarada.

### 3.3 · Familia B · unidad **EVENTO DE TRÁMITE**, ponderador `FAC_TRA`

- Join `sec_7` (canal, `FAC_TRA`, diseño) **×** `sec_8` (`P8_4`) por `ID_TRA`.
- `U_B` = filas emparejadas con `P8_4 ∈ {0,1}` **y** `FAC_TRA` finito `> 0`.
- `d(B) = 1` si `P8_4 = 1`, `0` si `P8_4 = 0`. Blanco → fuera, contado.
- **Canales:** `PRE` = `P7_3 = 1`; `DIG` = `P7_3 ∈ {3,4,5}`.
  **Residuo de canal, contado y pesado:** `P7_3 ∈ {2,6,7,8,9,blanco}`
  (`B-N-RESIDUO-CANAL`, `B-P-RESIDUO-CANAL`).
- **Cobertura del join, contada:** `B-N-SEC7-FILAS`, `B-N-SEC8-FILAS`,
  `B-N-EMPAREJADAS`, `B-N-SEC7-SIN-PAREJA`, y `B-COBERTURA` =
  `B-N-EMPAREJADAS / B-N-SEC7-FILAS`. Si la cobertura es baja, el estimando
  **no** es `p(mordida | canal)` sobre el universo de trámites sino
  `p(este trámite fue el señalado | trámite de alguien que ya declaró en 8.3)`,
  y se rotula así en el veredicto, sin adornos.

### 3.5 · Guardias de existencia y de llave — **paran, no adivinan**

Se corren **antes** de estimar y su salida es `RESULT`:

- **G-1** columnas declaradas presentes en los tres miembros → si no,
  `NO-ESTIMABLE-COLUMNA-AUSENTE:<col>`.
- **G-2** `G-LLAVE-SEC7-DECLARADA-UNICA`: ¿es `(CVE_ENT,UPM,V_SEL,R_ELE,N_TRA)`
  — la llave que **declara el descriptor** — única en `sec_7`?
- **G-3** `G-LLAVE-SEC7-IDTRA-NTTIPO-UNICA`: ¿lo es `(ID_TRA,NT_TIPO)` — la que
 ?
- **G-4** `G-LLAVE-SEC8-IDTRA-UNICA`: ¿es `ID_TRA` única en `sec_8`? De ello
  depende que el join sea uno-a-muchos exacto.
- Las tres reportan `UNICA` o `NO-UNICA:<grupos>/<filas>`. **Ninguna corrige
  nada**: si la llave `(ID_TRA,NT_TIPO)` no es única, el join se declara
  `JOIN-NO-EXACTO` y las ramas de B salen `NO-ESTIMABLE-LLAVE-NO-UNICA`.
  No se elige otra llave sobre la marcha.

### 3.6 · Familia C · unidad **TRÁMITE tipo `01`**, ponderador `FAC_TRA`

- `U_C` = filas de `sec_7` con `N_TRA = 1` **y** `P7_3 ∈ {1,2,4,5,6}` **y**
  `FAC_TRA` finito `> 0`. **Sin deduplicar** (misma razón que §3.4).
- `d(C) = 1` si `P7_3 ∈ {4,5}` (adopta) · `0` si `P7_3 ∈ {1,2,6}` (no adopta).
- Residuo, contado y pesado: `P7_3 ∈ {3,7,8,9,blanco}` (`C-N-RESIDUO`,
  `C-P-RESIDUO`). `3` = teléfono y `7` = trámite no concluido son categorías
  sustantivas que el universo excluye.
- **Dirección:** más alto = más uso de canal digital/autoservicio.
- **Advertencia de rótulo, pre-declarada:** `d = 0` significa *«usó un canal
  físico»*, **no** *«rechazó un servicio digital»*. Se reporta como asociación
  descriptiva de canal. El propio `alcance` de la regla ya lo estampa: *«la
  condición sin coerción/sin riesgo fiscal la impone la construcción del
  universo, no el informante»*.
- `EST_DIS`/`UPM_DIS` se tratan como **llaves de texto opacas**: nunca se
  convierten a entero ni se re-rellenan a un ancho tomado del descriptor
  (lección de `ACTO GEN2-LOTE-ENVIPE-1` §3.4 — el descriptor iba desfasado y
  normalizarlas habría partido estratos en silencio).
- **Estrato con una sola UPM:** se re-muestrea a sí mismo (varianza cero). No
  se colapsa (decisión de diseño que esta spec no está autorizada a tomar) ni
  se descarta (sesgaría el punto). Si el conteo es `> 0`, `METODO-IC` sale
  `IC-CON-ESTRATOS-DE-UPM-UNICA` y **el IC se lee como límite inferior de la
  anchura verdadera**, nunca como IC exacto.
- Filas sin `EST_DIS` o sin `UPM_DIS` se cuentan (`*-N-SIN-DISENO`): afectan al
  IC, **no** al punto.
| **`SD`** (**PRIMARIA**) | **sin deduplicar**: cada fila de `sec_7` es un evento y entra una vez |
| **`CD`** | **deduplica `sec_7` por `ID_TRA`**, conservando la primera fila en orden de archivo |

| familia | unidad | tabla | desenlace | ponderador |
|---|---|---|---|---|
| **A** · mordida discrecional | **PERSONA** | `encig2025_01_sec1_A_3_4_5_8_9_10.csv` | reactivo 8.3 (`P8_3_1/2/3`) | `FAC_P18` |
| **B** · mordida por canal | **EVENTO DE TRÁMITE** | `sec_7` × `sec_8` por `ID_TRA` | `P8_4` × canal `P7_3` | `FAC_TRA` |
| **C** · adopción de gobierno digital | **TRÁMITE `N_TRA=01`** (luz) | `sec_7` | canal `P7_3` | `FAC_TRA` |
| **X** · pago efectivo (hallazgo) | trámite | `sec_8` | `P8_6` | `FAC_P18` |
