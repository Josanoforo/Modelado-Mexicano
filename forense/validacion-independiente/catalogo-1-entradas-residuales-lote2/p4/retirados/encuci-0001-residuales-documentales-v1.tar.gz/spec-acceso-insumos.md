# Insumos y separación de la sesión

Solo una sesión nueva sin historial recibirá estos documentos; este contenedor no autoriza ejecución ni apertura de datos por sí mismo. Una misión de recálculo debe autorizar las olas abiertas y firmar los contratos propuestos antes de iniciar. No abrir resultados, productores, dictámenes ni material exterior; retornar únicamente salida propia según esquema y sellarla antes de comparar.

Payload `encuci2020_bd_dbf`; archivo `BD_ENCUCI2020_dbf.zip`; SHA256 `0414fd59e2afcc36294530687c721e8e86bd04e76ad95bfce4b7b2e70853f283`.

