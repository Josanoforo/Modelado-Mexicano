# Método: extracción fiel de especificación humana

## 1 · Payload y medición original

| campo | valor |
|---|---|
| payload | `enif_2024_enif_2024_bd_csv`, `sha256=00e4b0b42775276b2da236a5bba8c64dc5a92c289908a4727dec93dc7684f039` |


| unidad | PERSONA elegida, 18 años y más |
| universo | `TMODULO.csv`, `EDAD_V` 18-98 |
| desenlace | `tiene_ahorros = 1` ⟺ alguna de `P5_1_1..P5_1_6` (informal) o `P5_6_1..P5_6_9` (formal) vale `'1'` — blanco por secuencia cuenta como no-ahorro por esa vía |
| ponderador | `FAC_PER` |
| diseño | `EST_DIS` × `UPM_DIS`, bootstrap de conglomerado, `n_boot=10000`, `seed=42` |
| numerador (con ahorro) | 8 699 |
