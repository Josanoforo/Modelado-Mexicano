# Insumos y separación de la sesión

Solo una sesión nueva sin historial recibirá estos documentos; este contenedor no autoriza ejecución ni apertura de datos por sí mismo. Una misión de recálculo debe autorizar las olas abiertas y firmar los contratos propuestos antes de iniciar. No abrir resultados, productores, dictámenes ni material exterior; retornar únicamente salida propia según esquema y sellarla antes de comparar.

Payload `enbiare2021_bd_csv_zip`; archivo `enbiare2021/enbiare_2021_base_de_datos_csv.zip`; SHA256 `afe9013a4cc26538dfe81da686f0d09e756a7d0e2fc407cd22f596fd53c0f354`.

