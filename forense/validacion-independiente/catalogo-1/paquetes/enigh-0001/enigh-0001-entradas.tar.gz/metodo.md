# Método: extracción fiel de especificación humana

## Qué mide

Un payload (`enigh2022_nc_csv`, `sha256 3b2b0bc9…`), un miembro
(`conjunto_de_datos_concentradohogar_enigh2022_ns/conjunto_de_datos/…_ns.csv`),
universo **hogares** (`folioviv+foliohog`), referencia **2022**:

| familia | unidad | desenlace | ponderador |
|---|---|---|---|
| **A** · recibe remesas | **HOGAR** | `remesas > 0` | `factor` |



## Diseño

Bootstrap de `upm` con reemplazo **dentro de** `est_dis`, 2 000 réplicas,
`numpy.PCG64`, semilla `20260915`, percentiles 2.5/97.5. `est_dis`/`upm` como
**llaves de texto opacas**. Estratos de UPM única → `IC-CON-ESTRATOS-DE-UPM-UNICA`
y el IC se lee como **límite inferior**. La semilla y las réplicas **difieren**
de las del ensayo `B` (42 / 10 000): por eso la réplica se juega **sobre el
punto**, nunca sobre los extremos del IC.

