# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2021-LABORAL-0001 · preregistro





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo; ninguna cifra GEN1 es input. Unidad mujer 15+ A1/A2/B1/B2/C1/C2 ENDIREH 2021. Ámbito laboral interpersonal de sección VIII, pregunta 8.9. Elegibilidad vida: `P8_1=1`, alguna vez trabajó por salario, pago o ganancia. `P8_1=2` no se trata como ausencia de violencia laboral. En alguno de sus trabajos, los 19 reactivos `P8_9_1`…`P8_9_19` preguntan hechos sufridos por personas que trabajaban con ella, con códigos 1 sí, 2 no, 9 no especificado, blanco/salto desconocido. Unión vida positiva si algún 1, negativa solo si todos 2, desconocida en otro caso. No se mezclan aquí los reactivos de discriminación laboral 8.3, que tienen ventana de cinco años y otro estimando.





Elegibilidad reciente: además `P8_4=1`, trabajó de octubre de 2020 a la entrevista; `P8_4=2` fuera del denominador, nunca ausencia de violencia. Pregunta 8.11 sobre los mismos 19 actos `P8_11_1`…`P8_11_19`: 1 muchas veces, 2 pocas veces, 3 una vez, 4 no ocurrió, 9 no especificado, blanco/salto desconocido. Solo se pregunta si 8.4=1 y el acto 8.9=1. Para acto 8.9=2 se codifica 8.11=4 por salto documentado; unión reciente 1 si algún 1–3, 0 solo si todos 4, desconocida si falta respuesta sin positivo. Si vida desconocida, reciente desconocida. No sumar actos ni confundir ventanas.





Módulo `TB_SEC_VIII.csv`, FD y cuestionario A 2021. Fuente `endireh2021_bd_csv_zip` SHA recalculado `e4f1e7b1898cc53b3126ed959a9089091afd2ffdd1439911f5419e6c99c6037e`; FD SHA `5c30a3f7f88123ca672f1042ec3b5c37cc1d7989f07fd23ecbf088cca6dda180`; cuestionario A SHA `d2de0f03b8d347b298f7355312953d772a94edf21443bded042dd2a2ec487ae1`. `FAC_MUJ`, `EST_DIS`, `UPM_DIS` del módulo, TSDem por `ID_PER`; factor positivo, edad 15–120.





Ejes univariados nacional, edad 15–29/30–44/45–59/60+, escolaridad `NIV` (00 ninguna; 01–03/05–06 básica; 04/07–08 media superior/técnica; 09–11 superior), localidad U/C/R, A1/A2/B1/B2/C1/C2, entidad 01–32. IC percentil 2.5/97.5 con 200 réplicas de todas las UPM dentro de estrato, incluidas las de aporte cero al dominio; semilla 20260923. Singleton autorremuestreado con varianza cero. Celda publicable solo si n conocido≥100, ≥5 UPM con casos, ancho IC≤0.20 y CV≤0.30 si p>0. Se suprime si falla, sin valor ni réplicas. Se conservan solo réplicas agregadas, no registros individuales, cruces ni municipio. No inferencia causal.
