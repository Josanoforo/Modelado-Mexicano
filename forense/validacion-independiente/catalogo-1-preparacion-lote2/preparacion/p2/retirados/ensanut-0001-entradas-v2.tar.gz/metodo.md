## Qué mide

| | |
|---|---|
| payload | `adultos_ensanut2024_w_stata_stata__v2026_09_01` (`0fa8f443…`) |
| archivo | `adultos_ensanut2024_w.dta` |
| desenlace | bloque `a0927` — 20 variables `a0927{a..e}{1..4}`: **letra = razón, dígito = vacuna** |
| `RAZON_LOGISTICA` | `a0927a?` (no había vacunas) ∪ `a0927c?` (no estaba quien aplica) |
| ponderador | `ponde_f` |
| diseño | `estrato` · `est_sel` · `upm` |


1. **La unidad de observación es la MENCIÓN, no la persona — y se dice.**
   aplicado a filas de mención, una persona con dos menciones entra con su
   peso **dos veces**. La primaria reproduce ese universo (es el de la cifra
