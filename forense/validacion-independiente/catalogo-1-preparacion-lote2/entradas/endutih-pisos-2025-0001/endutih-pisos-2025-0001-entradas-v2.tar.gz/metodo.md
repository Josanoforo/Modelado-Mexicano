# Método: extracción fiel de especificación humana

## Archivos, unidad, denominadores y preguntas

Por ola, el FD oficial registrado y el ZIP DBF registrado en el manifiesto son
los únicos inputs externos. Se unen `usuarios` y `usuarios2` por la llave
`UPM,VIV_SEL,HOGAR,NUM_REN` después de exigir unicidad y cobertura 1:1. La
unidad es la persona elegida. Se exige `EDAD>=6`, `FAC_PER>0` finito,
`EST_DIS` y `UPM_DIS` presentes. En 2023 la entidad es `ENT`; en 2024/2025,
`CVE_ENT`. `TLOC`: 1 ≥100 mil, 2 15–99,999, 3 2,500–14,999, 4 <2,500.

| Medida | Texto y referencia FD por cada ola | Universo de respuesta válida | Sí | No | Salto |
| --- | --- | --- | --- | --- | --- |
| internet | `P7_1`: «En los últimos tres meses, ¿ha utilizado internet en este hogar o fuera de él?»; hoja `tic_YYYY_usuarios` (2025 `ti25usu`) | persona 6+ | 1 | 2 | ninguno |
| celular | `P8_1`: «¿Dispone usted de celular?»; hoja `tic_YYYY_usuarios2` (2025 `ti25usu2`) | persona 6+ | 1 | 2 | ninguno |
| actividad_empleo | `P7_10_2`: buscó información sobre empleos/bolsas de trabajo en internet en los últimos tres meses | `P7_1=1` | 1 | 2 | `P7_1=2` |
| actividad_mensajes | `P7_12_3`: envió mensajes instantáneos por internet en los últimos tres meses | `P7_1=1` | 1 | 2 | `P7_1=2` |
| actividad_tramite | `P7_35_4`: realizó trámites del gobierno por internet en los últimos 12 meses | `P7_1=1` | 1 | 2 | `P7_1=2` |
| no_internet_acceso / costo / preferencia | `P7_2`: «¿Por qué no utiliza internet?» | `P7_1=2`, respuesta `P7_2` válida | 1 / 4 / 3 | otro 1–8 | `P7_1=1` |
| no_celular_costo / preferencia / cobertura | `P8_2`: «¿Por qué no dispone de un celular (común o Smartphone)?» | `P8_1=2`, respuesta `P8_2` válida | 1 / 2 / 3 | otro 1–8 | `P8_1=1` |

El FD 2023 escribe «Internet» y menciona Twitter como ejemplo de mensajería;
2024/2025 escriben «internet» y mencionan X. El ítem de trámites usa 12
meses en las tres olas, mientras `P7_1` usa tres meses. La combinación es
condicional sobre usuarios actuales y puede excluir usuarios de hace 4–12
meses. No se interpreta como coerción ni se compara como la misma unidad que
los trámites de ENCIG. `P7_2=1` habla de acceso personal; una razón de hogar
no se traslada a esta persona. La falta de recursos se describe como costo,
sin convertirla en preferencia. Cada razón es categoría de una sola pregunta
de respuesta excluyente; no se suman las tres elegidas como exhaustivas.

Todos los valores fuera de los códigos listados, incluido blanco, son `NR`;
el FD no documenta código explícito `NS` para estos ítems. `SALTO`, `NR`,
`NS`, `SI` y `NO` se cuentan por separado. El denominador de una proporción
es SI+NO dentro del universo indicado; se publica también el conteo de
estados y `n_tabla`. Ningún salto ni blanco entra como no evento.

## Ejes, precisión y salida

Ejes univariados por ola: total; sexo 1/2; edad 6–11, 12–17, 18–29, 30–59,
60+; `TLOC` 1–4; escolaridad `NIVEL` 00–02, 03–05, 06–11; entidad 01–32.
Edad 6–11 sólo existe aquí por diseño ENDUTIH; no se compara directamente
con una tasa MOCIBA 12+. Escolaridad 99 y otros códigos quedan fuera del eje
pero siguen en el total. La celda se suprime antes de publicar su punto si
`n<100` respuestas válidas, sin fusionar ejes ni buscar cortes favorables.
