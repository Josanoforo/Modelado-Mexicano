# Método: extracción fiel de especificación humana

## Qué mide

Un solo payload (`envipe2025_csv`, `sha256 8a7a99fd…`), un solo miembro
(`tmod_vic_envipe2025/conjunto_de_datos/conjunto_de_datos_tmod_vic_envipe2025.csv`),
unidad **delito**, restringido a `BPCOD = 01` (robo total de vehículo), ola **2025**:

| familia | estrato | desenlace | ponderador | releva |
|---|---|---|---|---|
| **CON** · con cobertura | `BP2_1 = "1"` | `BP1_20 = "1"` denuncia | `FAC_DEL` | **`RES-0039`** |
| **CON** · complemento **contado** | `BP2_1 = "1"` | `BP1_20 = "2"` no denuncia | `FAC_DEL` | **`RES-0040`** |
| **SIN** · sin cobertura | `BP2_1 = "2"` | `BP1_20 = "1"` denuncia | `FAC_DEL` | **`RES-0041`** |
| **SIN** · complemento **contado** | `BP2_1 = "2"` | `BP1_20 = "2"` no denuncia | `FAC_DEL` | **`RES-0042`** |

## Las decisiones que esta spec toma

1. **Es la opción A, y sólo la A.** La propuesta ofrecía A (estrecha descriptiva)
   y B (redefinición de motor). Mesa firmó **A**. Esta spec no redefine población,
   unidad, tratamiento de cobertura, desenlace ni uso en el motor. Si A no resulta
   medible, la consecuencia es `NO-ESTIMABLE`, **nunca** una migración a B.
2. **`EST_DIS`/`UPM_DIS` verificados, no supuestos.** El encargo pidió comprobarlo:
   ambos existen con **ese nombre exacto** en el archivo de víctimas de 2025 según
   `data/inventario-reactivos-v1_2.tsv`. No hizo falta guardia de renombre. Pero
   conviven con `ESTRATO` y `UPM`, que **no** son lo mismo: se resuelven por nombre
   literal, `A.15(c)`.
3. **El ponderador se fija por nombre literal.** `FAC_DEL`, nunca `FAC_DEL_AM`,
   que existe en el mismo archivo.
4. **Los complementos se cuentan.** `CON-P-NO-DENUNCIA` y `SIN-P-NO-DENUNCIA`
   salen de contar `BP1_20 = "2"` dentro del mismo estrato. **Prohibido `1 − p`**:
   derivarlo haría que la suma-uno se cumpliera por construcción y el control
   no comprobaría nada.

## Diseño

Bootstrap de `UPM_DIS` con reemplazo **dentro de** `EST_DIS`, 2 000 réplicas,
`numpy.PCG64`, semilla `20260915`, percentiles 2.5/97.5; EE = sd de las réplicas.
`EST_DIS`/`UPM_DIS` como **llaves de texto opacas**. Estratos de UPM única →
`IC-CON-ESTRATOS-DE-UPM-UNICA` y el IC se lee como **límite inferior**.

