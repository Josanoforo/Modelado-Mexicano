# Esquema de salida documental

Una fila por entrada_id del esquema-identidades.tsv. Campos: entrada_id, conducta, eje, segmento, unidad, estimacion, n_valido, peso_denominador, exclusiones_por_causa; IC95_inf, IC95_sup y metodo_IC solo bajo contrato de incertidumbre adjunto. No contiene valores de referencia. No ejecutar contratos propuestos sin firma de contenido.
