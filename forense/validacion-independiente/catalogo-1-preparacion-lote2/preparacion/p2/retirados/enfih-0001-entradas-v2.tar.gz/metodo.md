# Método: extracción fiel de especificación humana

## Qué mide

Un solo payload (`enfih2019_bd_csv_zip`, `sha256 be372533…`), una sola tabla
(`TCONCENTRADORA.csv`), universo **hogares** (llave `FOLIO+VIV_SEL+HOGAR`),
referencia **2019**:

## Diseño

Bootstrap de `UPM_DIS` con reemplazo **dentro de** `EDIS`, 2 000 réplicas,
`numpy.PCG64`, semilla `20260915`, percentiles 2.5/97.5. `EDIS`/`UPM_DIS` como
**llaves de texto opacas**. Estratos de UPM única → `IC-CON-ESTRATOS-DE-UPM-UNICA`
y el IC se lee como **límite inferior**.
