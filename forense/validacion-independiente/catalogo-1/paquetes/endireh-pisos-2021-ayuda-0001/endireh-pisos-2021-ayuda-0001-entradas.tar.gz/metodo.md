# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2021-AYUDA-0001 · preregistro





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo. No se usa GEN1 como fuente numérica. Unidad: mujer de 15+ con cuestionario A1/A2, pareja actual, en ENDIREH 2021. Los 38 reactivos 14.1 de `TB_SEC_XIV.csv` son `P14_1_1`…`P14_1_22`, `P14_1_23AB`, `P14_1_24AB`, `P14_1_25`…`P14_1_34`, `P14_1_35AB`…`P14_1_38AB`. La matriz literal de texto y códigos es la pregunta 14.1 del cuestionario A registrado, reproducida por mnemónico en FD 2021, páginas 454–462. Cubre actos físicos, sexuales, emocionales y económicos de la relación actual desde su inicio; no se suma la prevalencia de cada acto. Para cada reactivo 1=muchas veces, 2=pocas veces, 3=una vez, 4=no ocurrió, 9/no especificado y blanco/salto=desconocido. Unión positiva si algún 1–3, negativa solo si todos 4; lo demás desconocido y fuera del denominador de ayuda/denuncia.





Entre la unión positiva, 14.7.1 `P14_7_1` pregunta «¿Pidió apoyo, información o servicios en alguna dependencia pública o de gobierno, a un grupo o asociación o una institución privada?»; 14.7.2 `P14_7_2` pregunta si ella o alguien de su familia presentó queja o denunció ante una autoridad. Cada una: 1 sí, 2 no, 9/blanco desconocido. Son estimandos separados, no una sola variable. No se infiere denuncia de ayuda ni ayuda de denuncia. El hecho puede pertenecer a cualquiera de los 38 actos, no específicamente a violencia física.





Entre quienes respondieron sí a ayuda, las diez casillas múltiples 14.8 `P14_8_1`…`P14_8_10` registran: Instituto de las Mujeres, línea telefónica, organismo/asociación civil, CAVI, Centro de Justicia para las Mujeres, Defensoría Pública, clínica/centro de salud público, consultorio/hospital privado, DIF, otra institución. Cada una 1 sí, 2 no, 9/blanco desconocido. Son prevalencias condicionales **entre solicitantes de ayuda**, no entre todas las violentadas; pueden sumar más de 100%.





Solo si 14.7.1=2 y 14.7.2=2, 14.22 pregunta «¿Por qué razón no lo comentó o no buscó ayuda o denunció el hecho?» y permite respuestas múltiples. `P14_22_1`…`_15`: miedo de consecuencias, vergüenza, amenaza de pareja, no le creerían, hijos, ocultarlo a familia, persuasión de no hacerlo, lo consideró sin importancia, promesa de cambio, derecho a reprenderla, él no cambiará, desconocía cómo/dónde denunciar, desconfianza en autoridades, desconocía servicios, otra razón. Cada casilla 1 sí, 0 no declarado, 9/blanco desconocido. El 0 solo se usa en el universo con ambas respuestas 2; fuera de él es no preguntado. Cada motivo tiene su propio denominador de respuestas conocidas dentro de ese universo; motivos no exclusivos. Miedo, barreras de información e institucionales se mantienen separados de «sin importancia»; ninguna razón demuestra elección sin restricciones.





Factor `FAC_MUJ`, estrato `EST_DIS`, UPM `UPM_DIS` de `TB_SEC_XIV`. Se une `TB_SEC_XIV_2` y `TSDem` por `ID_PER`; edad válida 15–120. Remuestreo de todas las UPM A1/A2 dentro de estrato, incluyendo contribuciones cero al dominio, 500 réplicas, semilla 20260923, IC percentil 2.5/97.5. Estrato singleton autorremuestreado con varianza cero. Ayuda/denuncia: ejes univariados nacional, edad (15–29, 30–44, 45–59, 60+), escolaridad `NIV` (00 ninguna; 01–03/05–06 básica; 04/07–08 media superior/técnica; 09–11 superior), localidad U/C/R, A1/A2 y entidad 01–32. Instituciones y razones: nacional únicamente, por denominadores condicionales menores. Cada celda exige ≥100 mujeres con respuesta conocida, ≥5 UPM con casos, IC ancho≤0.20, CV≤0.30 cuando p>0. Celda que falla se suprime sin resultado ni réplicas. No hay cruces ni salida municipal. Las réplicas guardadas son proporciones agregadas, sin registros individuales ni identificadores.





Origen: ZIP CSV `endireh2021_bd_csv_zip`, SHA `e4f1e7b1898cc53b3126ed959a9089091afd2ffdd1439911f5419e6c99c6037e`; FD `endireh2021_fd_pdf`, SHA `5c30a3f7f88123ca672f1042ec3b5c37cc1d7989f07fd23ecbf088cca6dda180`; cuestionario A `endireh2021_cuestionario_a_pdf`, SHA `d2de0f03b8d347b298f7355312953d772a94edf21443bded042dd2a2ec487ae1`. Esta medición no estima subregistro total ni preferencias libres, solo respuestas declaradas bajo el filtro.
