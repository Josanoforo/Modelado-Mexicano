# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2011-MODULOS-0001 · ENDIREH 2011 por situación conyugal





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo, adopción NO. FD XLS y tres cuestionarios verifican que `TUnidas1/2/3` (A unida), `TDunida1/2/3` (B alguna vez unida) y `TSolter1/2` (C soltera) son módulos de mujeres distintas. Factor `FAC_PER`, estrato `EST_DIS`, UPM `UPM_DIS`; edad/escolaridad de `TSDem` por `CONTROL,VIV_SEL,HOGAR,R_SEL_M=N_REN`. No copiar códigos de 2006 o 2021.





Pareja: A/B preguntan 30 actos `AP6_1_1`–`_30`/`BP6_1_1`–`_30` desde inicio de relación y `AP6_3_*`/`BP6_3_*` de octubre de 2010 a entrevista. Grupos físicos 20–27, emocionales/control 1–13, económicos/patrimoniales 14–19, sexuales 28–30. C pregunta 21 actos `CP6_1_1`–`_21`/`CP6_3_*` a solteras `CP4_1=1/2` con relación actual/anterior; `CP4_1=3` sin relación queda fuera. C: físicos 12–18, emocionales/control 1–10, económico 11, sexuales 19–21. 1 muchas, 2 pocas, 3 una vez = sí; 4 no ocurrió = no; 8/9/blanco = desconocido. `6.3` se pregunta por acto positivo en `6.1`; si `6.1=4`, el salto aporta 4 al año. El texto y la composición difieren entre A/B y C.





Ayuda de pareja A/B: `AP6_5_1`–`_6`/`BP6_5_*` a DIF, Instituto de la Mujer, MP, presidencia municipal, policía u otra autoridad, entre mujeres con al menos un acto. C: `CP6_4_1`–`_6` institucional y `_7` dijo a familiares, separados. 1 sí/2 no, otros desconocidos. Resultado `pareja_denuncia_ultima_visita` A/B es únicamente el resultado codificado 01 «denunció» en `AP6_8_i_j`/`BP6_8_i_j` de la última visita entre solicitantes de ayuda con resultado válido, no una denuncia general en toda la población afectada. C no pregunta una denuncia institucional separada en este bloque: **excluida por diseño**. Razones múltiples de no acudir: A `AP6_11_1`–`_13` en TUnidas2; B `BP6_11_*` en TDunida3; C `CP6_7_*` en TSolter2. Solo entre afectadas sin ayuda institucional y con al menos una razón codificada; blanco de una casilla se toma como no marcada solo en ese conjunto. Son razones declaradas, no elección sin restricciones.





Ámbitos no de pareja: pregunta 2.6 de cada cuestionario, doce actos (manoseo, propuestas/represalias sexuales, violación/temor sexual, actos forzados, agresión física, amenazas, humillación, ignorar, piropos ofensivos) sin esposo/pareja. `AP2_6_i`/`BP2_6_i`/`CP2_6_i` 1 sí/2 no. Cada hecho positivo tiene hasta dos respuestas de 2.7 **agresor**, 2.8 **lugar**, y 2.9 desde octubre 2010 (1 sí/2 no). Se miden por separado: agresor familiar 01–06, laboral 07–08, escolar 09–11; lugar comunitario 01 calle/06 transporte/07 cine/08 centro comercial, escolar 02, laboral 03 oficina/04 fábrica. Son definiciones por agresor o lugar de 2011, no equivalentes automáticas a módulos de 2016/2021. Un hecho con código de agresor/lugar desconocido no se transforma en negativo del dominio. La unión por ámbito es positiva si algún hecho elegible coincide y negativa solo con 12 hechos conocidos sin coincidencia. `P2_10_i_j` códigos 01–09 solicitud a autoridad/institución, 10 familiares, 11 ninguna; `P2_12_i_j` código 1 denuncia en resultado de atención, entre quienes acudieron. Estas dos preguntas existen solo para los actos 1–9 de 2.6, de modo que ayuda/resultado usa ese subuniverso, mientras las prevalencias de ámbito usan los doce actos. Se informan como ayuda y resultado de última atención, no como denuncia exhaustiva. Despojo de bienes `AP3_7_1`–`_3`/`BP3_7_*`/`CP3_1_*` se informa aparte: pregunta «familiares u otras personas», sin asignar exclusivamente agresor familiar.





Discriminación laboral 2011 separada de 2.6: `AP/BP/CP2_1` alguna vez prueba de embarazo para entrar (1 sí/2 no, 3 nunca solicitó trabajo y 4 nunca trabajó fuera), `2_2` perjuicio por embarazarse (1 sí/2 no, 3 nunca se embarazó fuera). De octubre de 2010 a entrevista `2_5_1`–`_5` pago menor, menor ascenso, prestaciones, perjuicio por edad/estado civil y prueba de embarazo en el trabajo, solo entre `2_3_1=1` trabajó en ese intervalo. 1 sí/2 no; no aplica, 9 y blanco fuera. La unión no suma ítems.





Economía/decisiones al entrevistar: A `AP8_1` dinero libre 1 sí/2 no; `AP7_1_3` su dinero y `_6` gasto/economía: 1 solo ella o 3 ambos = participa, 2 solo él = no; 4 otras personas, 5 no aplica, 9/blanco fuera. B `BP7_1` dinero libre 1/2, sin las decisiones de pareja actual, excluidas por diseño. C `CP7_1_1`–`_7` pregunta si debe pedir permiso al novio/exnovio: 1 sí, 2 avisa/pide opinión y 3 no tiene que hacer nada = no pide permiso; 4 sale con él, 5 no realiza actividad, 9/blanco fuera. Estos ítems no son una escala psicológica ni se comparan como idénticos con A/B.





Cortes univariados nacional, edad 15–29/30–44/45–59/60+, escolaridad 00 ninguna, 01–03/05 básica, 04/06/07 media, 08/09 superior; localidad U/R, situación A/B/C y entidad 01–32. IC percentil 2.5–97.5 de 200 réplicas de todas las UPM dentro de estrato, incluidas UPM de contribución cero, semilla 20260923. Publicable n conocido ≥100, ≥5 UPM, ancho IC ≤0.20 y CV ≤0.30 si p>0; suprimidas sin punto ni réplicas. Razones e instituciones solo nacional. Réplicas agregadas sin identificadores.





Manifiesto `endireh_2011_bd_endireh_2011_csv`, SHA recalculado `8ece557b2ac1d78dc0bfdee1d8f9743b2da1e44184be340d22967d60b10d52e5`; FD XLS `b038c66d69bce990d9bd71cfc76dd19b5320532b3bba4efbb083b8b1ddc4755e`. Cuestionarios A/B/C SHA `de9e6614564df6e36b86de7e6f9274d191546793da4f121876232ababb53ed2f`, `a6dca2905108ba78bc82f88b535c5e5c54a519edc6228fe04781e6b781c68d52`, `2bcc0e7a90e487ec37f6f760da3b5dad406d168737fcf577572bfecb2ebe4d1e`. Import efectivo `numpy==2.3.5`; resto biblioteca estándar y medidor autocontenido.
