# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2021-FAMILIAR-0001 · preregistro





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo; GEN1 no es input numérico. Unidad: mujer de 15+ A1/A2/B1/B2/C1/C2 de ENDIREH 2021. Ámbito familiar de sección XI, no equivalente a violencia de pareja de sección XIV. La batería 11.1 contiene los veinte reactivos `P11_1_1`…`P11_1_20` de `TB_SEC_XI.csv`, con texto literal en el FD 2021 y cuestionario A. El texto de ventana es «Durante el último año, de octubre de 2020 a la fecha». No se etiqueta como vida ni se suma actos individuales. Cada reactivo: 1 muchas veces, 2 pocas veces, 3 una vez, 4 no ocurrió; 9/no especificado y blanco/salto desconocidos si aparecen. Unión=1 con cualquier 1–3; =0 solo si los 20 son 4; de otro modo desconocida. Denominador: solo respuesta conocida. No se interpreta silencio como no violencia.





Factor `FAC_MUJ`, estrato `EST_DIS`, UPM `UPM_DIS` del módulo XI; demografía TSDem por `ID_PER`, edad 15–120 y factor positivo. Ejes univariados nacional, edad 15–29/30–44/45–59/60+, escolaridad `NIV` (00 ninguna; 01–03/05–06 básica; 04/07–08 media superior/técnica; 09–11 superior), localidad U/C/R, condición A1/A2/B1/B2/C1/C2 y entidad 01–32. IC percentil 2.5/97.5 con 200 réplicas de UPM completas dentro de estrato, incluidas las sin casos del dominio, semilla 20260923. Singleton autorremuestreado aporta varianza cero. Cada celda requiere n conocido≥100, ≥5 UPM con casos, ancho IC≤0.20 y CV≤0.30 si p>0. Las que fallen se suprimen. Réplicas agregadas sin identificadores; no cruces ni municipio.





Fuente: `endireh2021_bd_csv_zip` SHA256 recalculado `e4f1e7b1898cc53b3126ed959a9089091afd2ffdd1439911f5419e6c99c6037e`; FD `endireh2021_fd_pdf` SHA `5c30a3f7f88123ca672f1042ec3b5c37cc1d7989f07fd23ecbf088cca6dda180`; cuestionario A SHA `d2de0f03b8d347b298f7355312953d772a94edf21443bded042dd2a2ec487ae1`. Misma codificación FD para B/C; esta medición no asigna agresor individual ni mecanismo causal.
