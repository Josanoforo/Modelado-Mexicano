## §4 · Regla del intervalo (congelada; no se ajusta con el resultado)

Por celda c del grupo de pooling g = (desenlace, eje) — 12 grupos, el pooling es **por eje
dentro de cada desenlace**, no por celda sola ni entre desenlaces:

- Δ_c = logit h2021(c) − logit h2018(c), con h los marginales armonizados de §2.
- τ²_g = media de Δ_c² sobre las celdas de g con Δ definido. **Sin centrar** (la
  persistencia predice Δ = 0: un cambio común a todo el eje es error de persistencia, no
  se descuenta) y **sin restar ruido muestral** (el error que se evalúa, R2024 − p2021,
  también trae el ruido de dos olas). Ambas decisiones hacen el intervalo más ancho, no
  más angosto.
- ee_m(c) = (logit IC-HI − logit IC-LO) / (2 · 1.959964), del IC95 sellado del piso 2021
  (`CALC-PISOS-ENIF2021-EJES-0003` o `-FORMALIDAD-0001`).
- **IC calibrado:** expit( logit p2021(c) ± 1.959964 · √(ee_m² + τ²_g) ) →
  `IC-CALIBRADO-INF` / `IC-CALIBRADO-SUP`; `tipo_incertidumbre = muestral +
  cambio-entre-olas`. Centro = el piso sellado (18+); τ² se estima en 18-70 y se aplica
  al piso 18+ (declarado: es el único universo común).
- **NO-CALIBRABLE:** una celda cuyo grupo no tiene ningún Δ definido (h en 0 o 1) o cuyo
  piso no tiene IC en (0, 1); queda fuera del denominador de la cobertura y se cuenta.

Descriptivos que **no** entran al intervalo: media de Δ por grupo, ruido medio
se²(2018) + se²(2021) en logit por grupo, y τ² «con 2015» (informal × 4 ejes).


Unidad = persona elegida 18+; ponderador `FAC_ELE`; diseño
`EST_DIS × UPM_DIS`.

- Ahorro informal: cualquiera de `P5_1_1..P5_1_6=1`; no, solo si todas =2.
- Ahorro formal: cualquiera de `P5_7_1..P5_7_9=1`; no, solo si cada tipo
  tiene `P5_4=2` o `P5_7=2`. Una cuenta declarada con respuesta formal
  ausente queda desconocida.
- D9 `ahorra_solo_informal`: uno si informal sí y formal no; cero si
  informal no o formal sí; lo demás desconocido.
- `informal_cualquiera`: indicador informal anterior.
- Cuenta formal se clasifica con `P5_4_1..P5_4_9`, nunca con tarjeta
  `P5_6`. Localidad: `TLOC 1/2` = 15 000 y más; `3/4` = menor.
- Edad válida 18–96 y escolaridad 00–09 homologada. Formalidad queda
  NO-CONSTRUIBLE: ENIF 2021 no tiene una contraparte comparable de P3_13.
- IC95: 10 000 remuestras de UPM dentro de estrato con PCG64(42), un único
  plan compartido por ambos desenlaces y todas las celdas.

- Ahorro informal: cualquiera de `P5_1_1..P5_1_6=1`; no si todas =2.
- Ahorro formal: sí si cualquier `P5_7_1..9=1`; no si, para cada tipo
  homólogo i, `P5_4_i=2` o `P5_7_i=2`. Los pares se comparan por posición.
- D9 = informal sí y formal no; cero si informal no o formal sí.
- `informal_cualquiera` conserva el indicador informal.
- Cuenta por `P5_4`, localidad por `TLOC`, edad 18–96 y educación 00–09.
  Formalidad sigue NO-CONSTRUIBLE por ausencia de contraparte de P3_13.
- FAC_ELE, EST_DIS × UPM_DIS, 10 000 remuestras PCG64(42), un solo plan de
  réplicas compartido por ambos desenlaces y todas las celdas.
