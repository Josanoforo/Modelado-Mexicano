# Método: extracción fiel de especificación humana

## Fuente, filtro y estimando congelados

**Unidad:** persona elegida, edad conocida 6–97 en el archivo; 98/99 edad no especificada fuera de base. **Denominador del estimando:** personas de **15+ usuarias de internet en los últimos tres meses** con respuesta 1 o 2 a `P7_10_2`. **Numerador:** respuesta 1. **Ventana:** tres meses. **Escala:** proporción 0–1. `FAC_PER` pondera; `EST_DIS` estratifica y `UPM_DIS` identifica conglomerado. No se imputa un blanco ni se infiere empleo efectivo.

En el estado del reactivo, 6–14 es `SALTO` aunque use internet; `P7_1=2` a edad 15+ también `SALTO`; edad 15+ con `P7_1=1` y `P7_10_2` vacío es `NR`; 1 es `SI` y 2 es `NO`. Se cuentan aparte blancos estructurales 6–14 y blancos elegibles 15+. La respuesta de uso de internet ausente es `NR`, nunca `NO`. El estado `NS` se conserva como categoría posible de salida, sin código explícito en FD. Las personas 98/99 no se convierten en 15+.

Dominios univariados originales: total, sexo 1/2, edad 6–11/12–17/18–29/30–59/60+, TLOC 1–4, NIVEL 00–02/03–05/06–11, entidad 01–32 (2023 `ENT`; 2024/2025 `CVE_ENT`). El dominio 6–11 se retiene como celda suprimida sin punto por filtro estructural; 12–17 sólo comprende respuestas elegibles de 15–17. Umbral mínimo `n=100` respuestas válidas por celda antes de publicar punto o IC.
