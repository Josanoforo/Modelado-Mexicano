# Método: extracción fiel de especificación humana

## 1 · Qué mide

Proporción ponderada de hogares con `concentradohogar.remesas > 0`, por ola de
ENIGH Nueva Serie, en **2016, 2018, 2020 y 2022** — una ola a la vez, jamás
agrupadas ni promediadas. Ponderador `factor`. Universo: el completo de
`concentradohogar` (`folioviv` + `foliohog`), sin filtro adicional.

- `OPERATIVO` — `disponible_desde` = el campo `Modified` de los metadatos de la
  versión que el corpus tiene de esa ola (2016: `2021-11-29` · 2018: `2021-11-29`
  · 2020: `2021-07-28` · 2022: `2023-07-26`).
- `PERSISTENCIA` — `disponible_desde` = `periodo_fin` de la ola (el valor más
  temprano que el selector admite): el contrafáctico «si cada ola hubiera estado
  disponible el día que cerró su levantamiento».

## 3 · Guardias que PARAN (no supuestos heredados)

## 4 · IC95

## 5 · Lectura pre-declarada
