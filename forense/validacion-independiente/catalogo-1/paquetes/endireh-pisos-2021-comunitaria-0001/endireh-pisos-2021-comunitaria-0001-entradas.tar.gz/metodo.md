# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2021-COMUNITARIA-0001 · preregistro





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo; ninguna cifra GEN1 se usa. Unidad: mujer de 15+ entrevistada con A1/A2/B1/B2/C1/C2 en ENDIREH 2021. Ámbito comunitario, sin atribuir los hechos a pareja u hogar. FD 2021 sección IX y cuestionario A pregunta 9.1: «¿Alguna vez…?» Los 16 reactivos `P9_1_1`…`P9_1_16` incluyen piropos ofensivos, vigilancia/seguimiento, ofensas, pellizcos/empujones, exhibición sexual, amenazas/ataques, manoseo, insinuaciones/mensajes y coerción sexual, según texto literal de FD; la batería exacta, sin seleccionar resultados, es el conjunto 1–16. El horizonte reciente usa sus pares `P9_3_1`…`P9_3_16`, pregunta 9.3 «De octubre de 2020 a la fecha». La referencia acaba en entrevista de 2021. Los perpetradores son del ámbito comunitario según el módulo, no necesariamente desconocidos.





9.1: 1 sí, 2 no; blanco/salto no observado. Unión vida=1 si algún 1, =0 solo si los 16 son 2, desconocida en otro caso. 9.3: 1 muchas veces, 2 pocas veces, 3 una vez, 4 no ocurrió, 9 no especificado, blanco/salto no observado. Para un acto con 9.1=2, 9.3=4 por salto documentado. Unión reciente=1 si algún 1–3, =0 si todos 4, desconocida si falta respuesta sin positivo. Si unión vida desconocida, reciente desconocida. Prevalencia de algún acto es unión, no suma. Las mujeres con respuesta desconocida quedan fuera del denominador de la ventana correspondiente.





Fuente `TB_SEC_IX.csv` del ZIP `endireh2021_bd_csv_zip`, SHA recalculado `e4f1e7b1898cc53b3126ed959a9089091afd2ffdd1439911f5419e6c99c6037e`; FD `endireh2021_fd_pdf` SHA `5c30a3f7f88123ca672f1042ec3b5c37cc1d7989f07fd23ecbf088cca6dda180`; cuestionario A SHA `d2de0f03b8d347b298f7355312953d772a94edf21443bded042dd2a2ec487ae1`. A/B/C comparten códigos en FD, con universos de situación conyugal diferenciados en corte. Demografía de `TSDem` por `ID_PER`, factor `FAC_MUJ`, estrato `EST_DIS`, conglomerado `UPM_DIS`; factor positivo y edad 15–120. Remuestreo de todas las UPM del marco de mujeres entrevistadas por estrato, con contribución cero en dominios: 200 réplicas, semilla 20260923, IC percentil 2.5/97.5. Singleton autorremuestreado con varianza cero.





Ejes univariados: nacional; edad 15–29/30–44/45–59/60+; escolaridad `NIV` (00 ninguna; 01–03/05–06 básica; 04/07–08 media superior/técnica; 09–11 superior); localidad U/C/R; condición A1/A2/B1/B2/C1/C2; entidad 01–32. Celda publicable solo con n conocido≥100, ≥5 UPM con casos, ancho IC≤0.20 y CV≤0.30 si p>0. Se suprime la que no pase, sin valor ni réplicas. Se conservan réplicas agregadas de proporción solo para celdas publicables. No cruces, municipio, identificadores individuales ni causalidad.
