## Universo y dominios

El marco es el universo completo del concentrado, con llave
`folioviv+foliohog`, y conserva todas sus filas para construir los remuestreos.
`est_dis` y `upm` son identidades de texto opacas. `factor` es el ponderador de
hogar, finito y estrictamente positivo.

Un valor ausente, no numérico, no finito o negativo de `remesas` no equivale a
cero: se cuenta y se excluye de los estimandos que requieren `remesas`. El
dominio receptor es `remesas>0` entre filas con ponderador y remesas válidos.
Se informan su n no ponderado, masa expandida y prevalencia sobre el universo
válido.

El dominio de participación añade `ing_cor>0`, finito y válido. Entre
receptores se cuentan por separado las exclusiones por `ing_cor` ausente/no
finito, igual a cero o negativo, con su masa `factor`. Ninguna se convierte en
cero. El cambio de denominador queda visible.

## Cinco estadísticos principales

Sobre receptores:

1. media ponderada de `remesas`;
2. mediana ponderada de `remesas`, definida como el menor valor observado cuya
   distribución ponderada acumulada alcanza al menos 0.5; ante empate se
   devuelve ese valor menor, sin interpolación.

Sobre el dominio de participación, idéntico para los tres cocientes:

3. participación media por hogar,
   `sum(factor*remesas/ing_cor)/sum(factor)`;
4. participación agregada o razón de masas,
   `sum(factor*remesas)/sum(factor*ing_cor)`;
5. proporción ponderada de hogares con `remesas/ing_cor>=0.5`.

La media de razones y la razón de sumas son estimandos distintos. El umbral
50% es descriptivo y predefinido; no es umbral de pobreza, riesgo o causalidad.

Como la documentación acredita la relación de componente, se verifica
`remesas <= ing_cor + 0.01` pesos en cada fila del dominio. Las excepciones se
cuentan y pesan, no se truncan ni se eliminan. Cualquier excepción deja los
tres cocientes calculados para diagnóstico pero marca el estado
`REPORTADO-CON-INCOMPATIBILIDAD-R-MAYOR-Y`; no se presentan como proporciones
acotadas hasta resolver la incompatibilidad.

## Incertidumbre

Los IC95 prioritarios corresponden a los estadísticos 3, 4 y 5. Se usa
bootstrap de `upm` con reemplazo dentro de `est_dis`, 2,000 réplicas,
`numpy.PCG64`, semilla `20260916`, percentiles 2.5 y 97.5. En cada réplica se
recalculan los tres cocientes completos. Los conglomerados se forman con el
marco completo: las filas fuera del dominio aportan contribuciones cero; no se
filtra primero a receptores.

Una UPM única se remuestrea a sí misma y aporta variación cero. Se informa su
conteo y el método se rotula con esa limitación, sin afirmar que el intervalo
sea una cota inferior garantizada. Si no hay diseño operativo se conservan los
puntos y los IC quedan nulos; no se fabrica un IC binomial.

