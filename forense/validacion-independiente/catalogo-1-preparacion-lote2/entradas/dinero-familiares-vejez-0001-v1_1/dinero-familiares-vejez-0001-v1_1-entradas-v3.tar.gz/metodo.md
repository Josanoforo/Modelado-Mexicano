# Método: extracción fiel de especificación humana

# ENIF 2024 · recibe dinero de familiares para la vejez — pre-registro congelado de `CALC-DINERO-FAMILIARES-VEJEZ-0001`

### `prereg-caja-ENIF-DINERO-FAMILIARES-VEJEZ` · **v1.0** · 15 de septiembre de 2026

> | | |

> |---|---|

> | **NOMBRE ESTABLE** | **`prereg-caja-ENIF-DINERO-FAMILIARES-VEJEZ`** — cítalo así, nunca por nombre de archivo |

**Acto:** `ACTO GEN2-SPECS-DEMANDA-2`, 15/sep/2026, entorno **NUBE**, sobre `origin/main = da9b47a361143d408cd9fd9c20d17b101c4fe381`.

---

## 0 · A.7 — resolución de identidad por hash, no por nombre

### 0.1 · El bloqueador, verbatim

```

ENIF2024	NO-LOCALIZADO -- se uso data/raw/enif_2024_bd_csv.zip (trae TMODULO.csv

con FILTRO_S9_1/P9_9_4/FAC_PER/EDAD_V); el id de manifiesto enif2024_csv

apunta a un ZIP distinto (data/raw/enif2024_csv.zip) sin estas columnas

confirmadas en este acto

```

`payload_manifiesto_id`. El bloqueo nace de **buscar por `id` de

manifiesto** (`enif2024_csv`, que resuelve a otro ZIP,

`data/raw/enif2024_csv.zip`) en vez de por el `sha256_payload` que la

propia regla ya trae.

### 0.2 · La resolución, con comando a la vista

```

    sha256_payload: "00e4b0b42775276b2da236a5bba8c64dc5a92c289908a4727dec93dc7684f039"   # familia.apoyo.recibe_dinero_familiares

$ grep -n "00e4b0b42775276b2da236a5bba8c64dc5a92c289908a4727dec93dc7684f039" data/manifiesto.yaml -B5

5543:- id: enif_2024_enif_2024_bd_csv

5544-  usado_para: sin uso asignado

...

5549-  archivo: enif_2024_bd_csv.zip

5550-  sha256: 00e4b0b42775276b2da236a5bba8c64dc5a92c289908a4727dec93dc7684f039

```

**Coincidencia exacta.** El `sha256_payload` que la regla declara **es** el

`sha256` de la entrada `enif_2024_enif_2024_bd_csv` del manifiesto —

`archivo: enif_2024_bd_csv.zip`, descargado el 5/ago/2026 vía `curl` desde

`inegi.org.mx`, `3 131 148` bytes. Es el **mismo payload** que

`data/raw/enif_2024_bd_csv.zip` (el ZIP que `demanda-corridas.tsv` dice que

"se usó"), identificado por contenido, no por el `id` textual que no

coincidía. Mismo patrón exacto que `NC-0188` (ENNViH) y que el hallazgo (4)

↔ `enif2024_csv` son ZIPs distintos; el correcto es el primero).

`FUERA-DE-PERÍMETRO` de este acto (`NC-0195`, `ACTO GEN2-SPECS-DEMANDA-1`,

(CAJA o mesa). Esta spec **no** espera esa corrección para congelar — la

identidad ya está resuelta por hash, con cita, y eso basta para dar a

---

## 1 · Payload y medición original

| campo | valor |

|---|---|

| payload | `enif_2024_enif_2024_bd_csv` (resuelto por hash, §0), `sha256=00e4b0b42775276b2da236a5bba8c64dc5a92c289908a4727dec93dc7684f039` |

| unidad | PERSONA |

| universo | `FILTRO_S9_1=2` (aplica módulo vejez) y `EDAD_V<71` |

| ponderador | `FAC_PER` |

| diseño | **sin campo de diseño UPM/estrato reproducible** dentro del perímetro del acto original (declarado en su propia cabecera) — IC95 por bootstrap ponderado simple, `n_boot=10000`, `seed=42`, sin conglomerado |

| n | 11 895 |

---

## 3 · Qué NO hace este acto

(`E.3`, y además `FUERA-DE-PERÍMETRO`, `NC-0195`). No cierra `NC-0195` —

la letra.

MAESTRA32-E18`, no aquí— es el que se reporta.**

- **Universo:** `FILTRO_S9_1=2` (aplica el módulo de vejez) y `EDAD_V<71`
- **Ponderador:** `FAC_PER` (columna confirmada en `TMODULO.csv`).
- **Desenlace:** `P9_9_4='1'` ("dinero de familiares", entre las opciones de con qué piensa cubrir su vejez).
- **Estimador de p:** proporción ponderada de `P9_9_4=1` sobre el universo, ponderando por `FAC_PER`.

| unidad | PERSONA |
| universo | `FILTRO_S9_1=2` (aplica módulo vejez) y `EDAD_V<71` |
| ponderador | `FAC_PER` |
| diseño | **sin campo de diseño UPM/estrato reproducible** dentro del perímetro del acto original (declarado en su propia cabecera) — IC95 por bootstrap ponderado simple, `n_boot=10000`, `seed=42`, sin conglomerado |
