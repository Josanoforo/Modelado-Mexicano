# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2016-RESTANTES-0001 · ENDIREH 2016 por módulo





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo, adopción NO, origen numérico solo del microdato ENDIREH 2016. Unidad mujer 15+; cuestionarios A1/A2 (pareja actual), B1/B2 (exesposo/expareja), C1 (novio/pareja actual o última), C2 sin pareja. Los denominadores nunca se suman entre módulos o grupos. El subcomponente físico A1/A2 ya sellado en `CALC-ENDIREH-PISOS-2016-PAREJA-FISICA-0002` no se recalcula aquí.





FD 2016 y sus códigos, independientes de 2021:





| Ámbito | Elegibilidad | Actos y ventana | Ayuda/denuncia |


|---|---|---|---|


| Escolar VI | `P6_1=1` asistió alguna vez; reciente además `P6_2=1` desde octubre 2015 | `P6_6_1`–`_17` vida, 1 sí/2 no; `P6_8_1`–`_17` desde octubre 2015, 1–3 veces/4 no | `P6_13_1`/`_2` entre afectadas de vida |


| Laboral VII | `P7_1=1` trabajó alguna vez; reciente además `P7_4=1` trabajó de octubre 2015 a entrevista | `P7_9_1`–`_18` vida, 1 sí/2 no; `P7_11_1`–`_18` desde octubre 2015, 1–3/4 | `P7_16_1`/`_2` entre afectadas de vida; excluye discriminación 7.3 y usa actos interpersonales 7.9 |


| Comunitario VIII | Todas las entrevistadas | `P8_1_1`–`_15` vida, 1 sí/2 no; `P8_3_1`–`_15` desde octubre 2015, 1–3/4 | `P8_8_1`/`_2` entre afectadas de vida |


| Familiar X | Todas; pareja excluida como agresor por texto de 10.1 | `P10_1_1`–`_18`, octubre 2015 a entrevista, 1–3/4; no hay estimando de vida | `P10_6_1`/`_2` entre afectadas del año |


| Pareja XIII | A1/A2/B1/B2/C1; C2 fuera por no tener relación | `P13_1_1`–`_36AB` desde inicio de relación (B incluye separación), 1–3/4; `P13_3_*` desde octubre 2015 1–3/4. A/B preguntan 23AB, 24AB, 33AB–36AB; C1 no. Actos 1–9 físicos solo B/C; 10–24 control emocional; 25–29 sexual; 30–31 digital; 32–36 económico/patrimonial; unión no física 10–36. | `P13_7_1`/`_2` entre afectadas por **cualquier** acto 1–36 |


| Dinero y decisiones IV/XIV | Solo A1/A2 con pareja actual | `P4_11`: dinero que puede usar como quiera, 1 sí/2 no. `P14_1AB_3` su dinero, `_6` gasto/economía, `_7` dinero sobrante: 1 solo ella, 2 solo él, 3 ambos pero él más, 4 ambos pero ella más, 5 ambos igual, 6 otras personas, 7 no aplica. Resultado de decisión con ella =1 para 1/4/5, =0 para 2/3; 6/7/blanco fuera. Estado al entrevistar, no acto de violencia. | No aplica |





Las uniones dan 1 si cualquier acto positivo; 0 solo si **todos** los reactivos elegibles son negativos; blanco/9/salto no cuenta como «no». Para frecuencia reciente, el salto documentado por acto de vida=2 aporta 4, siempre que la elegibilidad reciente se cumpla. Ayuda y denuncia son 1 sí/2 no, 9/blanco desconocido. Instituciones múltiples: `P6_14_1`–`_10`, `P7_17_1`–`_10`, `P8_9_1`–`_10`, `P10_7_1`–`_11`, `P13_8_1`–`_11`, entre ayuda=1. Razones múltiples entre ayuda=0 y denuncia=0: `P6_24_1`–`_11`, `P7_27_1`–`_11`, `P8_19_1`–`_11`, `P10_15_1`–`_11`, `P13_21_1`–`_15`; 1 declarada, 0 no declarada, 9/blanco desconocido. Se conservan por separado y solo nacional. Ninguna razón prueba elección libre ni identifica causalidad.





Archivos `TB_SEC_VI`, `VII`, `VIII`, `X`, `XIII`, `XIV`, `IV` y sus partes `_2` donde contienen ayuda o razones. En VII, `P7_11_18` está en `TB_SEC_VII_2.csv` y se une por `ID_MUJ`. Llave `ID_MUJ`; `TSDem` edad/`NIV`. `FAC_MUJ` positivo, `EST_DIS`/`UPM_DIS`; UPM sin casos en dominio mantienen aporte cero. Ejes univariados nacional, edad 15–29/30–44/45–59/60+, escolaridad ninguna/básica/media superior/superior, localidad U/C/R, instrumento y entidad 01–32. IC percentil 2.5–97.5 de 200 réplicas de UPM dentro de estrato, semilla 20260923. Publicable con n conocido ≥100, ≥5 UPM, ancho IC ≤0.20, CV ≤0.30 si p>0; suprimida sin punto/réplicas si falla. Réplicas agregadas sin identificadores.





Manifiesto `endireh_2016_bd_mujeres_endireh2016_sitioinegi_csv`; SHA recalculado `02c06ab73a53942ddb575e3e35d8c1dd775406277b74e0605735e3eced4e6f10`. FD incrustado SHA `d6b1805e4e0eae0d12df5acd834e4913e59e56dcc101d80d1036535e8c3f1cba`. Import efectivo `numpy==2.3.5`; demás biblioteca estándar, medidor autocontenido. No inferir cambio 2016→2021 sin cotejo literal de actos, población y ventana.
