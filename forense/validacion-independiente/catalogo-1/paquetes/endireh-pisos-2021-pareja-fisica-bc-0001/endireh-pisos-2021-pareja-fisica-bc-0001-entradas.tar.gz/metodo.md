# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2021-PAREJA-FISICA-BC-0001 · preregistro





**El primer resultado que produzca este procedimiento es el que se reporta.** GEN2 descriptivo retrospectivo; GEN1 no es origen numérico. Unidad mujer de 15+ ENDIREH 2021 con instrumento B1 (separada/divorciada), B2 (viuda) o C1 (soltera con novio/pareja o ex). C2 carece de relación y no entra al denominador. Los tres grupos se informan por separado: B pregunta por exesposo/expareja a lo largo de la relación y después de separarse; C1 pregunta por novio/pareja o exnovio/expareja a lo largo de la relación y, si terminó, después. No se presenta la suma de B/C como una población homogénea. La muestra nacional de este CALC es solo el marco conjunto B1/B2/C1 y se rotula así, no como prevalencia de todas las mujeres.





Sección XIV de `TB_SEC_XIV.csv`, preguntas 14.1 y 14.3. Nueve actos físicos, `P14_1_1`…`P14_1_9`: empujar/jalar cabello, abofetear, amarrar, patear, aventar objeto, golpear con puño/objeto, tratar de ahorcar/asfixiar, agredir con cuchillo/navaja y disparar arma de fuego. En B el texto se formula en pasado sobre ex; en C1 adapta pronombres a novio/pareja o ex. 14.1 tiene 1 muchas veces, 2 pocas veces, 3 una vez, 4 no ocurrió, 9 no especificado, blanco/salto desconocido. Unión vida positiva si al menos un 1–3; negativa solo si todos 4; otro caso desconocido. No sumar actos.





La pregunta 14.3 usa `P14_3_1`…`P14_3_9` y ventana literal «De octubre de 2020 a la fecha». Se formula solo para actos positivos de 14.1: 1 muchas veces, 2 pocas veces, 3 una vez, 4 no ocurrió, 9/blanco desconocido. Un 4 en 14.1 implica 4 estructural para el acto correspondiente en 14.3; un 9/blanco nunca implica no. Unión reciente positiva si algún 1–3, negativa solo si todos 4, desconocida si falta respuesta sin positivo o si 14.1 es desconocida. Ambas ventanas terminan en la entrevista de 2021, por lo que la reciente no se equipara a un año calendario fijo.





FD 2021 SHA256 `5c30a3f7f88123ca672f1042ec3b5c37cc1d7989f07fd23ecbf088cca6dda180`; cuestionario B oficial `https://www.inegi.org.mx/contenidos/programas/endireh/2021/doc/endireh2021_cuestionario_b.pdf`, SHA recalculado `beffe06a96a58d3b028539f419d28b5d9d325bbd0ee70f576e06e2608d63e689`; cuestionario C oficial `https://www.inegi.org.mx/contenidos/programas/endireh/2021/doc/endireh2021_cuestionario_c.pdf`, SHA recalculado `793a87dfa9757b135accd2ed27f75f7b9575e8de24003b63d93cb31d24f277be`. Se adquirieron estos dos faltantes documentales, sin incorporarlos al repo ni usarlos como fuente numérica. Microdato local `endireh2021_bd_csv_zip`, SHA recalculado `e4f1e7b1898cc53b3126ed959a9089091afd2ffdd1439911f5419e6c99c6037e`.



