como referencia en la nota).

| conducta | archivo | texto (A.15) | 1 | 0 | fuera (NaN) |
|---|---|---|---|---|---|
| DEPRESION-CESD7 | adultos 20+ | a0211–a0217 «Durante la última semana…» (CESD-7) | puntaje ≥ 9 (20–59) / ≥ 5 (60+) | debajo | algún ítem fuera de 1–4 |
| IDEACION-SUICIDA-ADULTOS | adultos 20+ | a1211 «¿Alguna vez ha pensado en suicidarse?» | 1 | 2 | 9 |
| DX-DIABETES | adultos 20+ | a0301 «¿Algún médico le ha dicho que tiene diabetes…?» | 1 | 2 (gestacional), 3 | otro |
| DX-HIPERTENSION | adultos 20+ | a0401 «¿…tiene la presión alta?» | 1 | 2 (embarazo), 3 | otro |
| FUMA-ACTUAL | adultos 20+ | a1301 «Actualmente, ¿fuma tabaco…» | 1, 2 | 3 | 9 |
| ALCOHOL-12M | adultos 20+ | a1308 «En los últimos 12 meses, ¿con qué frecuencia tomó al menos una copa…» | 1–4 | 5, 6 | 9 |
| ALCOHOL-EXCESIVO-30D | adultos 20+ | a1311 (hombres, 5+ copas) / a1312 (mujeres, 4+ copas) «En los últimos 30 días…» | 1 | 2; y a1308 ∈ {5, 6} (salto) | 9 |
| NECESIDAD-SALUD-3M | integrantes, todas las edades | h0401 «En los últimos 3 meses… alguna necesidad de salud» | 1 | 2 | — |
| BUSCO-ATENCION | integrantes con h0401 = 1 | h0404 «¿buscó atención por esa necesidad de salud?» | 1 | 2 | resto |
| FUE-ATENDIDO | integrantes con h0404 = 1 | h0406 «¿fue atendido por esa necesidad de salud…?» | 1 | 2 | resto |
| ATENCION-CONSULTORIO-FARMACIA | utilizadores | u0201 «¿En qué institución de salud se atendió?» | 12 «Consultorios pertenecientes a farmacias» | otra categoría 1–26 | fuera de 1–26 |
