# Método: extracción fiel de especificación humana

## Qué mide

Tres familias sobre un solo payload (`encig25_base_datos_csv`,
`sha256 47daf2f7…`), universo **82 áreas urbanas de 100 mil habitantes o más**,
población **18 años y más**, referencia **2025**:

| familia | unidad | tabla | desenlace | ponderador |
|---|---|---|---|---|
| **A** · mordida discrecional | **PERSONA** | `encig2025_01_sec1_A_3_4_5_8_9_10.csv` | reactivo 8.3 (`P8_3_1/2/3`) | `FAC_P18` |
| **B** · mordida por canal | **EVENTO DE TRÁMITE** | `sec_7` × `sec_8` por `ID_TRA` | `P8_4` × canal `P7_3` | `FAC_TRA` |
| **C** · adopción de gobierno digital | **TRÁMITE `N_TRA=01`** (luz) | `sec_7` | canal `P7_3` | `FAC_TRA` |
| **X** · pago efectivo (hallazgo) | trámite | `sec_8` | `P8_6` | `FAC_P18` |

## Las tres decisiones que esta spec toma y GEN1 no

1. **A · primaria `SOLANY`, no `SOL1`.** El reactivo 8.3 tiene **tres** incisos
   (servidor público directo · coyote · insinuación). GEN1 usó sólo el primero.
   `A-DELTA-SOLANY-SOL1` mide lo que vale la restricción. `E.1`: GEN1 no elige
   la codificación de GEN2.
2. **B · primaria `SD` (sin deduplicar), no `CD`.** El descriptor define
   `NT_TIPO` (*«Número de trámite / Último evento», 01-03*) para distinguir
   eventos repetidos del mismo tipo. La rama `CD` reproduce la corrida base y
   `B-N-EVENTOS-DESCARTADOS-POR-DEDUP` mide cuántos eventos borra.
3. **Ninguna llave se adopta por autoridad.** El descriptor declara la llave de
   `sec_7` como `(CVE_ENT,UPM,V_SEL,R_ELE,N_TRA)` y **omite `NT_TIPO`**;
   `MAESTRA35-L1` verificó `(ID_TRA,NT_TIPO)`. `G-2`/`G-3`/`G-4` **miden las
   tres** y, si la llave del join no es única, B sale
   `NO-ESTIMABLE-LLAVE-NO-UNICA`. No se elige otra sobre la marcha.

## El recorte que se mide antes de rotular

`P7_3` tiene **ocho** categorías sustantivas. El par presencial `{1}` /
digital `{3,4,5}` usa cuatro y deja fuera `2` (banco/tienda/farmacia) y `6`
(módulos móviles). `B-P-RESIDUO-CANAL` mide su peso. Igual que el hallazgo 3.2
del lote ENVIPE: **«presencial vs digital» es propiedad del recorte, no del
instrumento.**

## Diseño

Bootstrap de `UPM_DIS` con reemplazo **dentro de** `EST_DIS`, 2 000 réplicas,
`numpy.PCG64`, semilla `20260909`, percentiles 2.5/97.5. `EST_DIS`/`UPM_DIS`
como **llaves de texto opacas** (nunca a entero, nunca re-rellenadas). Estratos
de UPM única → `IC-CON-ESTRATOS-DE-UPM-UNICA` y el IC se lee como **límite
inferior** de la anchura verdadera.

