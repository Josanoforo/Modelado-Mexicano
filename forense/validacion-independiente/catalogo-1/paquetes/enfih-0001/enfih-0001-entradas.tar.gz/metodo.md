# Método: extracción fiel de especificación humana

## Qué mide

Un solo payload (`enfih2019_bd_csv_zip`, `sha256 be372533…`), una sola tabla
(`TCONCENTRADORA.csv`), universo **hogares** (llave `FOLIO+VIV_SEL+HOGAR`),
referencia **2019**:

| familia | unidad | archivo | desenlace | ponderador |
|---|---|---|---|---|
| **A** · tenencia de Afore | **HOGAR** | `TCONCENTRADORA.csv` | `C_AFORE` (0/1 crudo) | `FAC_HOG` **de ese archivo** |
| **B** · robustez de universo | hogar principal | `TCONCENTRADORA.csv` | `C_AFORE` \| `H_PPAL==1` | `FAC_HOG` |
| **C** · descriptivo NO sellado | hogar | `TCONCENTRADORA.csv` | `C_AFORE` por `CAT_POS` | `FAC_HOG` |

## Las tres decisiones que esta spec toma y GEN1 no

1. **El IC nace de diseño.** GEN1 selló `ic95` sin declarar un campo de
   diseño; `EDIS`/`UPM_DIS` están en `TCONCENTRADORA.csv` y esta corrida los
   usa. `A-DELTA-IC-VS-GEN1` mide cuánto cambia la anchura.
2. **`FAC_HOG` se fija por archivo, no por nombre.** La misma etiqueta existe
   en `THOGAR.csv`, que **no se abre**. `A.15(c)`.
3. **`CAT_POS` no es formalidad.** La condicional de `R1.2` no es construible
   en ENFIH (0 aciertos en 664 columnas); `CAT_POS` sale como descriptivo
   rotulado `C-*`, nunca como la condicional.

## Diseño

Bootstrap de `UPM_DIS` con reemplazo **dentro de** `EDIS`, 2 000 réplicas,
`numpy.PCG64`, semilla `20260915`, percentiles 2.5/97.5. `EDIS`/`UPM_DIS` como
**llaves de texto opacas**. Estratos de UPM única → `IC-CON-ESTRATOS-DE-UPM-UNICA`
y el IC se lee como **límite inferior**.

