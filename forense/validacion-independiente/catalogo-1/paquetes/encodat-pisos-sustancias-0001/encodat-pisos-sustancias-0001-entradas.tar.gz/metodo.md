# Método: extracción fiel de especificación humana

## 1 · Unidad, universo, diseño

Unidad: **persona** de 12 a 65 años (`ds3` ∈ [12, 65]) que respondió el cuestionario
individual; ponderador `ponde_ss`. El diseño vive en Hogar: estrato de varianza `est_var`,
UPM `code_upm`, estrato rural/urbano/metropolitano `estrato`. **Llave declarada:** los 20
primeros caracteres de `id_pers` (ancho 22) = `id_hogar` (ancho 20); el catálogo no la
documenta, la carátula del cuestionario sí nombra el folio del hogar. Sólo se usan
`id_hogar` únicos; los no pareados se cuentan (`G-JOIN-SIN-HOGAR`) y quedan fuera por
diseño inválido (`G-FILAS-DISENO-VALIDO`). Si la llave no parea, el conteo lo dice: no se
prueba otra llave después de abrir el dato.

## 2 · Conductas (por texto)

Tabla en `forense/analisis/salud-bienestar/lista-cerrada-P1.md` §2 (ENCODAT), parte de esta
spec. Saltos: quien nunca bebió (`al1` = 2) vale 0 en ALCOHOL-12M; quien no bebió en 12
meses (`al1` = 2 o `al4` = 2) vale 0 en ALCOHOL-30D y ALCOHOL-EXCESIVO-12M; FUMA-ACTUAL sin
dato y `tb05` = 2 (nunca fumó) vale 0. ALCOHOL-EXCESIVO-12M con `al11` (mayor número de
copas en un solo día, 12 meses): hombres 5+ (códigos 1–4), mujeres 4+ (1–5); `ds2` 1 =
hombre, 2 = mujer (sin etiqueta de valor en el `.dta`; el cuestionario lo marca así).
«Alguna vez» de drogas: 1 si algún ítem = 1; 0 si todos = 2; si no, fuera. La segunda
ronda (`di1a2`…, `dm1a2`…) no se usa (declarado).

## 3 · Ejes (uno a la vez)

TOTAL · SEXO · EDAD 12–17 / 18–34 / 35–65 · ESTRATO (1 RURAL, 2 URBANO, 3 METROPOLITANO) ·
ESCOLARIDAD (`ds9`, sólo 18+): HASTA-PRIMARIA {1, 2}, SECUNDARIA {3, 4}, MEDIA-SUPERIOR
{5, 6}, SUPERIOR {7, 8, 9}; 99 fuera.

## 4 · Estimación

Igual que la spec ENSANUT §4 (razón ponderada; bootstrap de UPM dentro de `est_var`,
certeza para UPM única, `PCG64(20260924)`, 2 000 réplicas, percentiles 2.5/97.5, contrato
conservador), con la receta común por sha256. Sin IC de persistencia.

