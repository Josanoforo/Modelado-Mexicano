| campo | valor |
|---|---|
| unidad | DELITO (no persona) |
| universo | delitos con `BP1_20 ∈ {1,2}` en `tmod_vic_envipe2025` |
| desenlace | `evade_norma = 1` ⟺ `BP1_20==2` Y `BP1_23 ∈ {04,05,06,08}` (conjunta, no condicional) |
| ponderador | `FAC_DEL` |
| diseño | `EST_DIS` × `UPM_DIS`, bootstrap de conglomerado, `n_boot=10000`, `seed=42` |
