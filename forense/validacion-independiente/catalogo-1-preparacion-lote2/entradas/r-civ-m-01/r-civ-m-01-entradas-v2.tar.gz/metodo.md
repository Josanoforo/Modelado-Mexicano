# Método: extracción fiel de especificación humana

## Qué mide

**Dos estimandos sobre la misma lectura del mismo archivo:**

**`U_R` y `U1` no se comparan entre sí** (`A-bis.4`).

## Identidad del insumo

| campo | valor |
|---|---|
| `id` de manifiesto | **`envipe_2012_base_de_datos_envipe_2012_dbf`** |
| miembro del ZIP | `Tmod_Vic.DBF` — literal, nunca por plantilla |
| filas (cabecera DBF) | 32,493 |
| descriptor citado | `FD_ENVIPE12.zip -> FD_ENVIPE_2012.xls, hoja TMod_Vic` — `BP1_23` fila 231, `BPCOD` fila 26, diseño filas 621 (FAC_DEL), 627 (EST), 628 (UPM) |

## Vínculo de columnas (rol → nombre físico en ESTA ola)

| rol | nombre físico | tipo en la cabecera del `.dbf` |
|---|---|---|
| `BP1_23` | `BP1_23` | Caracter(2) |
| `BP1_20` | `BP1_20` | Caracter(1) |
| `BPCOD` | `BPCOD` | Caracter(2) |
| `FAC_DEL` | `FAC_DEL` | Caracter(6) |
| `ESTRATO` | **`EST`** | Caracter(3) |
| `UPM` | **`UPM`** | Caracter(5) |
