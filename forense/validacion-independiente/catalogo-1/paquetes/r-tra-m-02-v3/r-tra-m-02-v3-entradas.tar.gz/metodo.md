# Método: extracción fiel de especificación humana

# `CALC-R-TRA-M-02-v3` — sucesor técnico de replay del árbitro R





 **Corrección adversarial PR #680:** sucede al sello `-v2` sin mutarlo. FP-370 conserva su alcance y no se extiende a este identificador técnico. **Celda:** `TRA-M-02`.





Hereda sin cambio los campos y resultados esperados congelados en `-v2`. Se crea después de la medición únicamente para completar la cadena de replay del estimando fijado en


`codificacion-R-v1_2.tsv`, sucesora registral de v1.1 que conserva el estimando y explicita reservas: payload `encuci2020_bd_dbf`,


codificación `y=1 si AP5_17=='1' o AP5_18=='1'; y=0 si AP5_17=='2' y AP5_18=='2' -- COMPUESTO OR de dos variables (_PATRON_COMPUESTO_OR); resto FUERA (cae en n_codigo_no_valido, no se reclasifica): 9 = No sabe/no responde, b = blanco (salto del cuestionario) y cualquier otra combinacion; codigos verificados en el FD (AP5_17 y AP5_18: 1 Si, 2 No, 9 No sabe/no responde, b blanco)`, ponderador `FAC_SEL`, estrato


`EST_DIS` y UPM `UPM_DIS`. Ninguno de esos campos se elige en la corrida.





Salida esperada por nombre, nunca por valor: punto, EE/IC o reserva, n, masa,


exclusiones, estratos y UPM. El medidor no abre L, corpus, M, TRIADA ni R legado.


Este sucesor técnico no añade una medición: hereda el conteo único de la cadena desde `CALC-R-TRA-M-02-v2`, cuyo objeto firmado es la medición R de `TRA-M-02`.
