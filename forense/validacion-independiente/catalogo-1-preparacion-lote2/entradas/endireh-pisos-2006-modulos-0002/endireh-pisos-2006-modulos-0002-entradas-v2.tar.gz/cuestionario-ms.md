                                               ENCUESTA NACIONAL SOBRE LA DINÁMICA
                                              DE LAS RELACIONES EN LOS HOGARES 2006
                                                                     MÓDULO PARA MUJERES SOLTERAS




                                                                                                                                                                                                  INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
1. DATOS DE IDENTIFICACIÓN                                                                      2. CONTROL DE VIVIENDA




                                                           $
 ENTIDAD FEDERATIVA                                                                               NÚMERO DE CONTROL ....................

 MUNICIPIO O DELEGACIÓN
                                                                                                  NÚMERO DE VIVIENDA SELECCIONADA ...............................




                                                          5
 LOCALIDAD
                                                                                                  TIPO DE INSTRUMENTO ...................................................................   C
 AGEB ............................................................




                                                         7
3. DIRECCIÓN DE LA VIVIENDA




                                                        6
                                                                         CALLE, AVENIDA, CALLEJÓN, CARRETERA, CAMINO



    NÚMERO                 NÚMERO                                                  COLONIA, FRACCIONAMIENTO, BARRIO, UNIDAD HABITACIONAL




                                                       (
    EXTERIOR               INTERIOR



4. CONTROL DE PAQUETE




                                                      8
 FOLIO DE PAQUETE .......................................................                        CONSECUTIVO DEL CUESTIONARIO EN EL PAQUETE .........


                                                                      O B S E R V A C I O N E S




                                                     0

CONFIDENCIALIDAD                                                                                             OBLIGATORIEDAD
 Conforme a las disposiciones del Artículo 38, párrafo primero, de la Ley de                                   De acuerdo con el Artículo 42, párrafo primero, de la Ley
 Información Estadística y Geográfica en vigor: “Los datos e informes que los                                  de Información Estadística y Geográfica en vigor: “Los
 particulares proporcionen para fines estadísticos o provengan de registros                                    informantes estarán obligados a proporcionar con veraci-
 administrativos o civiles, serán manejados, para efectos de esta Ley, bajo la                                 dad y oportunidad los datos e informes que les soliciten las
 observancia de los principios de confidencialidad y reserva y no podrán                                       autoridades competentes para fines estadísticos, censales
 comunicarse, en ningún caso, en forma nominativa o individualizada, ni harán                                  y geográficos, y a prestar el auxilio y cooperación que
 prueba ante autoridad administrativa o fiscal, ni en juicio o fuera de él”.                                   requieran las mismas”.


                                                                                                                                                                                            191
                                                                MUJERES SOLTERAS


1. Nombre de la mujer elegida



                                                ANOTE EL NÚMERO DEL RENGLÓN DE LA SECCIÓN II DEL CUESTIONARIO GENERAL


2. ¿Usted habla alguna lengua                    3. Le voy a leer algunas frases, dígame SÍ cuando esté de acuerdo y
indígena?                                        NO cuando esté en desacuerdo.




                                                                                                                                                                                                   INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                            Sí ........... 1
        CIRCULE UN SOLO CÓDIGO                                                ANOTE EN CADA CASILLA EL CÓDIGO INDICADO                                                      No .......... 2


                                                  1) ¿Una buena esposa debe obedecer a su esposo en todo lo que él ordene? ........

Sí ........ 1                 No ...... 2         2) ¿Una mujer puede escoger sus amistades aunque a su esposo no le guste? .....




                                               $
                                                  3) ¿El hombre debe responsabilizarse de todos los gastos de la familia? ................
 ¿Cuál?
                                                  4) ¿Una mujer tiene la misma capacidad que un hombre para ganar dinero? ..........




                                              5
                ESPECIFIQUE
                                                  5) ¿Es obligación de la mujer tener relaciones sexuales con su esposo
                                                     aunque ella no quiera? ................................................................................................




                                             7
                                                  6) ¿Cuando la mujer no cumple con sus obligaciones, el marido tiene
                                                     el derecho de pegarle? ................................................................................................




                                            6
4. ¿Usted está de acuerdo en que ...                                    Sí ........... 1       5. ¿Usted se considera …                                    6. ¿Usted ha oído
                                                                        No .......... 2                                                                    hablar de la igualdad
ANOTE EN CADA CASILLA EL CÓDIGO INDICADO                                                             ANOTE EN CADA CASILLA
                                                                                                      EL CÓDIGO INDICADO
                                                                                                                                                           entre mujeres y
                                                                                                                                                           hombres?




                                           (
1) las mujeres y los hombres tengan los mismos                                                                                      Sí ........... 1
   derechos para tomar sus decisiones? ..................                                                                           No .......... 2         CIRCULE UN SOLO CÓDIGO

2) las mujeres y los hombres tengan
   la misma libertad? ...................................................                      1) valiosa? .............................




                                          8
3) las mujeres tengan el derecho a defenderse y                                                2) atractiva? ..........................                              Sí ........ 1
   denunciar cualquier maltrato o agresión? ............
                                                                                               3) que tiene derechos? ........
4) las mujeres tengan la posibilidad de decidir                                                                                                                      No ...... 2




                                         0
   sobre su propia vida? ..............................................                        4) que puede expresar
5) las mujeres tengan derecho a vivir una vida                                                    sus opiniones? .................
   libre de violencia ? ...................................................

7. Muchas mujeres hemos padecido experiencias difíciles de las que no                                                         APLIQUE ESTA PREGUNTA SÓLO SI EN 7
hablamos por miedo o vergüenza. Dígame si a lo largo de su vida (en la calle,                                                   HUBO AL MENOS UNA RESPUESTA
                                                                                                                                          AFIRMATIVA
en fiestas, en un club, en su casa, etc.) usted ha experimentado alguna de las
siguientes situaciones y de parte de quién.                                                                                 8. Cuando esto ocurrió, ¿dio aviso o
                                                                                                                            denunció este hecho …
                         ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS
                            DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO
                                                                                                                                    CIRCULE LAS OPCIONES INDICADAS

                                                                Sí ........... 1           ¿Quién o quiénes?
                                                                No .......... 2      NO ANOTE NOMBRES PROPIOS,
                                                                                      SINO SUSTANTIVOS DEL TIPO:
                                                                                    VECINO, TÍO, DESCONOCIDO, ETC.
                                                                                                                            a familiares? ................................... 1
1) ¿La acariciaron o manosearon
                                                                                                                            en el ministerio público? ............... 2
   sin su consentimiento? ....................................
2) ¿La obligaron o forzaron a                                                                                               a la policía? ..................................... 3
   tener relaciones sexuales? .............................
                                                                                                                            Otro                                                      4
3) ¿La obligaron a realizar                                                                                                                            ESPECIFIQUE
   actos sexuales por dinero? .............................
4) ¿Le hicieron sentir miedo de                                                                                             No dio aviso ni denunció ................ 5
   sufrir un ataque o abuso sexual? ....................
5) ¿Le han dicho piropos groseros u ofensivos
   sobre su cuerpo o de carácter sexual? ..........

                                                                                                                                   Módulo para mujeres solteras                                3
                                                                                                                                                                                           193
                                                                                                                                                                                                                MUJERES SOLTERAS

                                                                                                                                           9. ¿Usted asiste o asistió alguna vez a la escuela?                                       Sí ........ 1

                                                                                                                                                                                                                                     No ...... 2            PASE A 12



                                                                                                                                           10. Durante su vida de estudiante, ¿algún compañero, maestro, personal o                                                             APLIQUE ESTA PREGUNTA SÓLO SI EN 10
                                                                                                                                                                                                                                                                                   HUBO AL MENOS UNA RESPUESTA
                                                                                                                                           autoridad escolar …
                                                                                                                                                                                                                                                                                            AFIRMATIVA
                                                                                                                                                                 ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                    DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO
                                                                                                                                                                                                                                                                                11. Cuando esto ocurrió, ¿avisó o
                                                                                                                                                                                                                                                                                denunció este hecho …
                                                                                                                                                                                                                 Sí ........... 1          ¿Quién o quiénes?
                                                                                                                                                                                                                 No .......... 2      NO ANOTE NOMBRES PROPIOS                              CIRCULE LAS OPCIONES INDICADAS


                                                                                                                                           1) la humilló o denigró? ...........................................
                                                                                                                                                                                                                                                                                  a familiares? .................................. 1




                                                                                                                                                                                         $
                                                                                                                                           2) la agredió físicamente? ......................................
                                                                                                                                                                                                                                                                                  en el ministerio público? .............. 2
                                                                                                                                           3) la ignoró o le hizo sentir menos por ser mujer?
                                                                                                                                                                                                                                                                                  a la policía? .................................... 3




                                                                                                                                                                                        5
                                                                                                                                           4) le propuso tener relaciones sexuales
                                                                                                                                              a cambio de calificaciones? ..............................
                                                                                                                                                                                                                                                                                  a las autoridades escolares? ...... 4
                                                                                                                                           5) la acarició o manoseó sin su consentimiento?




                                                                                                                                                                                       7
                                                                                                                                                                                                                                                                                  Otro                                                       5
                                                                                                                                           6) la obligó a tener relaciones sexuales? .............                                                                                                      ESPECIFIQUE

                                                                                                                                           7) le impuso castigos o represalias por haberse




                                                                                                                                                                                      6
                                                                                                                                              negado a sus pretensiones? ..............................                                                                           No dio aviso ni denunció ............... 6


                                                                                                                                           12. Durante el último año (octubre de 2005 a la fecha),                                             13. ¿Su lugar de trabajo es …




                                                                                                                                                                                     (
                                                                                                                                           ¿usted trabajó como …
                                                                                                                                                                                                                                                                               CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                         CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                                                                oficina de dependencia pública? .................................. 01




                                                                                                                                                                                    8
                                                                                                                                           empleada? .............................................................. 1                           oficina de empresa privada? ........................................ 02
                                                                                                                                           obrera? ................................................................... 2                        comercio? ...................................................................... 03
                                                                                                                                           jornalera? ............................................................... 3                         banco o servicios privados? ......................................... 04




                                                                                                                                                                                   0
                                                                                                                                           trabajadora por su cuenta? .................................. 4                                      escuela? ......................................................................... 05
                                                                                                                                           patrona? ................................................................. 5                         fábrica? ........................................................................... 06
                                                                                                                                           trabajadora sin pago en negocio                                                          PASE        taller, maquila? ............................................................... 07
                                                                                                                                           familiar? .................................................................. 6             A
                                                                                                                                                                                                                                     18         casa? ............................................................................... 08
                                                                                                                                           trabajadora sin pago en negocio
                                                                                                                                           no familiar? ............................................................. 7                         campo? ........................................................................... 09

                                                                                                                                           No trabajó ................................................................ 8                        Otro .................................................................................. 10


                                                                                                                                           14 ¿Cuánto                  15. Durante el último año (octubre de 2005 a la fecha), ¿usted vivió alguna de las                                                                   Sí .............. 1
                                                                                                                                           tiempo ha                   siguientes situaciones en su trabajo?                                                                                                                No ............. 2
                                                                                                                                           trabajado o                                                                                                                                                                      No aplica .. 3
                                                                                                                                           trabajó en ese                                                                   ANOTE LAS OPCIONES INDICADAS

                                                                                                                                           lugar?
                                                                                                                                                                       1) ¿Le pidieron la prueba de embarazo como requisito para entrar? ..................................................
                                                                                                                                                                       2) ¿La despidieron, no le renovaron contrato o le bajaron el salario por embarazarse? ...................
                                                                                                                                                                       3) ¿Le pagaron menos que a un hombre que hace lo mismo? ..............................................................
                                                                                                                                                  AÑOS

                                                                                                                                                                       4) ¿Tuvo menos oportunidad que un hombre para ascender? ..............................................................
                                                                                                                                           MENOS DE UN AÑO
                                                                                                                                              ANOTE 00                 5) ¿Recibió menos prestaciones que un hombre? .................................................................................
                                                                                                                                                                       6) ¿Debido a su edad o a su estado civil, la despidieron, le bajaron el salario
                                                                                                                                                                          o no la contrataron? ..............................................................................................................................

                                                                                                                                       4          Módulo para mujeres solteras
                                                                                                                                      194
                                                                    MUJERES SOLTERAS

16. Durante el último año (octubre de 2005 a la fecha) en su trabajo, ¿su jefe
inmediato, algún directivo o algún compañero, alguna vez …
                                                                                                                                      Sí ........... 1        ¿Quién o quiénes?
                               ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS                                                No .......... 2       NO ANOTE NOMBRES PROPIOS
                                  DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO


1) la humilló o denigró? ..................................................................................................................
2) la agredió físicamente? .............................................................................................................




                                                                                                                                                                                                 INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
3) la ignoró o hizo sentir menos por ser mujer? .........................................................................
4) le hizo insinuaciones o propuestas para tener relaciones sexuales
   a cambio de mejores condiciones en el trabajo? ...................................................................
5) la acarició o manoseó sin su consentimiento? ......................................................................




                                                 $
6) la obligó a tener relaciones sexuales? ....................................................................................
7) tomó represalias contra usted por haberse negado a sus pretensiones? .........................




                                                5
APLIQUE ESTA PREGUNTA                   18. Durante el último año (octubre de 2005 a la fecha),
SÓLO SI EN 15 Ó 16 HUBO                 ¿alguna persona de su familia la ha …                                                      Sí ........... 1           ¿Quién o quiénes?




                                               7
AL MENOS UNA RES-
                                                                                                                                   No .......... 2       NO ANOTE ANOTE NOMBRES PROPIOS,
PUESTA AFIRMATIVA                                   ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS                                              SINO SUSTANTIVOS DEL TIPO: PADRE,
                                                       DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO                                                         HERMANO, SUEGRA, ETC.

17. Debido a estos




                                              6
problemas, ¿hizo                        1) insultado u ofendido? ...................................................................
alguna denuncia o
puso alguna queja                       2) amenazado con golpearla o correrla de su casa? ...................




                                             (
administrativa?
                                        3) golpeado o agredido físicamente? .............................................
  CIRCULE UN SOLO CÓDIGO
                                        4) humillado o menospreciado? ......................................................




                                            8
                                        5) ignorado, no la toman en cuenta, no le brindan atención? ......
          Sí ........ 1
                                        6) encerrado? ...................................................................................
          No ...... 2                   7) le ha quitado su dinero u obligado a entregar su dinero? ........




                                           0
19. ¿Alguna vez sus familiares u otras personas …                                                                               Sí ................. 1        ¿Quién o quiénes?
                                                                                                                                No ................ 2
                               ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS                                                                     NO ANOTE NOMBRES PROPIOS, SINO
                                                                                                                                No aplica ..... 3           SUSTANTIVOS DEL TIPO: PADRE,
                                  DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO
                                                                                                                                                                HERMANO, VECINO, ETC.

1) le han quitado o robado bienes o propiedades? .....................................................................
2) le han quitado o robado documentos que la acrediten como propietaria
   o posesionaria de algún bien? ..................................................................................................
3) la han obligado a poner a nombre de otra persona las cosas
   o propiedades que usted compró o heredó? ..........................................................................


20. ¿Ha habido                      21. En su familia ¿a quién                          22. ¿Siente que por ser                   23. ¿Actualmente …
herencias en                        se acostumbra heredar?                              mujer la herencia fue
su familia?                                                                             desigual y favoreció a                                 CIRCULE UN SOLO CÓDIGO
                                          CIRCULE UN SOLO CÓDIGO                        los varones?
   CIRCULE UN SOLO                                                                                                                mantiene una relación
       CÓDIGO
                                                                                            CIRCULE UN SOLO CÓDIGO                sentimental o amorosa? ...... 1
                                        Mujeres ...................... 1
Sí ........ 1                                                                                                                     no tiene relación, pero
                                        Hombres ................... 2                                                             antes sí tuvo una? ................. 2
                      PASE                                                                Sí ......................... 1
No ...... 2             A               Ambos ....................... 3                                                           No ha tenido ninguna
                       23                                                                 No ....................... 2
                                                                                                                                  relación sentimental                                 PASE
                                                                                          No aplica ............ 3                o amorosa .............................. 3             A
                                                                                                                                                                                        29


                                                                                                                                        Módulo para mujeres solteras                         5
                                                                                                                                                                                         195
                                                                                                                                                                                                                  MUJERES SOLTERAS

                                                                                                                                           24. ¿Desde hace cuánto                        25. ¿Su (última) pareja, está (estaba) …                                    26. En total, ¿cuántas                        27. ¿Qué edad tenía
                                                                                                                                           mantiene esta relación                                                                                                    hijas e hijos nacidos                         cuando tuvo a su
                                                                                                                                           o cuánto tiempo duró                                             CIRCULE UN SOLO CÓDIGO                                   vivos ha tenido usted?                        primer hija o hijo?
                                                                                                                                           su relación anterior?
                                                                                                                                                                                          soltero? .................................................. 1
                                                                                                                                                                                          casado o unido? .................................... 2
                                                                                                                                                                                                                                                                            ANOTE CON NÚMERO                                  AÑOS
                                                                                                                                                                                          separado o divorciado? ........................ 3




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                             AÑOS
                                                                                                                                                                                          viudo? ..................................................... 4
                                                                                                                                                   MENOS DE UN AÑO                                                                                                    SI LA RESPUESTA                PASE
                                                                                                                                                                                          No sabe .................................................. 5                ES NINGUNO                       A
                                                                                                                                                        ANOTE 00
                                                                                                                                                                                                                                                                      ANOTE 00                        28
                                                                                                                                                                                          Otro ......................................................... 6




                                                                                                                                                                                           $
                                                                                                                                           28. Dígame si en su relación actual (anterior) su novio o pareja
                                                                                                                                           (ex novio o ex pareja), ¿la(le) ha …
                                                                                                                                                                                                                                                                                 Sí ........... 1           ¿Puso una denuncia o




                                                                                                                                                                                          5
                                                                                                                                                                 ANOTE EN CADA CASILLA EL CÓDIGO INDICADO.                                                                       No .......... 2            avisó a sus familiares?
                                                                                                                                                       SÓLO EN CASOS DE RESPUESTA AFIRMATIVA, PREGUNTE SI DENUNCIÓ


                                                                                                                                             1) empujado o le ha jalado el pelo? ....................................................................................                           ...........................




                                                                                                                                                                                         7
                                                                                                                                             2) pateado? ...........................................................................................................................            ...........................
                                                                                                                                             3) golpeado con las manos o con algún objeto? ...............................................................                                      ...........................




                                                                                                                                                                                        6
                                                                                                                                             4) tratado de ahorcar o asfixiar? ........................................................................................                         ...........................
                                                                                                                                             5) avergonzado, menospreciado o humillado? .................................................................                                       ...........................




                                                                                                                                                                                       (
                                                                                                                                             6) ignorado, no la toma en cuenta, no le brindan atención y cariño? .............................                                                  ...........................
                                                                                                                                             7) hecho sentir miedo? ........................................................................................................                    ...........................




                                                                                                                                                                                      8
                                                                                                                                             8) amenazado con matarla? ...............................................................................................                          ...........................
                                                                                                                                             9) amenazado con matarse? ..............................................................................................                           ...........................
                                                                                                                                           10) quitado su dinero o sus bienes? ....................................................................................                             ...........................




                                                                                                                                                                                     0
                                                                                                                                           11) acariciado o manoseado sin su consentimiento? .......................................................                                            ...........................
                                                                                                                                           12) presionado para tener relaciones sexuales? ...............................................................                                       ...........................
                                                                                                                                           13) obligado a tener relaciones sexuales? .........................................................................                                  ...........................
                                                                                                                                           14) pedido que cambie su manera de vestir o de comportarse? .....................................                                                    ...........................
                                                                                                                                           15) tratado de controlar o dominar sus movimientos, sus desiciones? ..........................                                                       ...........................
                                                                                                                                           16) vigilado o perseguido? ....................................................................................................                      ...........................


                                                                                                                                                                                                                             ENTREVISTADORA

                                                                                                                                           29. ¿Dónde se levantó la entrevista?                               30. ¿La entrevista a la mujer elegida                               31. Durante la entrevista, ¿la mujer
                                                                                                                                                                                                              se ...                                                              elegida …
                                                                                                                                                         CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                                              CIRCULE UN SOLO CÓDIGO                                                CIRCULE UN SOLO CÓDIGO



                                                                                                                                           Dentro de la vivienda ........................ 1                    realizó en el primer intento? ........... 1                        estaba sola? ..................................... 1

                                                                                                                                                                                                               tuvo que regresar según                                            estaban sus hijos? .......................... 2
                                                                                                                                           Fuera de la vivienda .......................... 2
                                                                                                                                                                                                               indicaciones? ................................... 2
                                                                                                                                                                                                                                                                                  estaban otros familiares
                                                                                                                                           En otro lugar                                           3                                                                              o personas? ..................................... 3
                                                                                                                                                                         ESPECIFIQUE
                                                                                                                                                                                                               Otro                                                     3
                                                                                                                                                                                                                                       ESPECIFIQUE




                                                                                                                                       6           Módulo para mujeres solteras
                                                                                                                                      196
