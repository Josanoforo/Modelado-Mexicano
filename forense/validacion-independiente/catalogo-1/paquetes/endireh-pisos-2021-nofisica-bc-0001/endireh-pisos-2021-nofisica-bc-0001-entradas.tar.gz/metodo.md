# Método: extracción fiel de especificación humana

# CALC-ENDIREH-PISOS-2021-NOFISICA-BC-0001 · pareja no física y ayuda B/C





El primer resultado que produzca este procedimiento es el que se reporta. GEN2 descriptivo retrospectivo; adopción NO; solo ENDIREH 2021 como origen numérico. Mujeres 15+ con relación A1/A2 actual, B1/B2 exesposo/expareja o C1 novio/pareja actual o última. C2 sin relación queda excluida por diseño. Las prevalencias de A/B/C son cortes del instrumento y no deben interpretarse como la misma relación ni sumarse.





Pregunta 14.1: desde inicio de la relación (B incluye después de separación), 1 muchas veces, 2 pocas veces, 3 una vez, 4 no ocurrió. Pregunta 14.3: de octubre de 2020 a entrevista, mismos 1–4; solo preguntada para acto positivo en 14.1, por lo que `14.1=4` aporta `14.3=4`. Otros blancos/9/saltos son desconocidos. Unión positiva si algún 1–3 y negativa solo si todos los actos elegibles son 4. Cada ventana usa denominador conocido propio.





Actos 10–24: humillación, ignorar, acusación de infidelidad, miedo, amenazas, encierro, vigilancia, mensajes de control, amenazas con arma/de muerte, destrucción, silencio, revisión de correo/celular, manipulación de hijos/familia y reclamos domésticos; se rotulan `emocional_control`. 25–29: coerción y violencia sexual. 30–31: agresión digital. 32–38: prohibición de trabajo/estudio, dinero, bienes y gasto doméstico, `economica_patrimonial`. `no_fisica_alguna` une 10–38. A/B usan 23AB, 24AB y 35AB–38AB; **C no pregunta esos seis actos** y su unión usa 10–22 y 25–34. Las categorías son descriptivas; ninguna prevalencia se suma a otra.





Ayuda/denuncia solo B1/B2/C1 con **algún** acto 1–38 de 14.1: `P14_7_1` pidió apoyo/información/servicios de institución o asociación, y `P14_7_2` ella o familia presentó queja/denuncia; 1 sí, 2 no. Se miden separadas. `P14_8_1`–`_10` son instituciones múltiples entre ayuda=1. `P14_22_1`–`_15` son razones múltiples entre ayuda=0 y denuncia=0; en microdato 1 marcado y 0 no marcado. No se interpreta «no quiso» como libertad sin restricciones ni se estima subregistro total.





Unidad mujer; `TB_SEC_XIV.csv`, razones en `TB_SEC_XIV_2.csv` por `ID_PER`; edad y escolaridad `TSDem.csv` por `ID_PER`. `FAC_MUJ` sin normalizar, `EST_DIS`, `UPM_DIS`. Ejes univariados: nacional, edad 15–29/30–44/45–59/60+, escolaridad ninguna/básica/media superior/superior, localidad U/C/R, instrumento A1/A2/B1/B2/C1, entidad 01–32. IC percentil 2.5–97.5 de 200 réplicas UPM dentro de estrato con UPM de contribución cero, semilla 20260923. Publicable: n conocido ≥100, ≥5 UPM con casos, ancho IC ≤0.20, CV ≤0.30 si p>0. Suprimidas sin valor ni réplicas. Instituciones y razones solo nacional. Réplicas agregadas por celda, sin microdatos o identificadores públicos.





Manifiesto `endireh2021_bd_csv_zip`; SHA recalculado `e4f1e7b1898cc53b3126ed959a9089091afd2ffdd1439911f5419e6c99c6037e`. FD SHA `5c30a3f7f88123ca672f1042ec3b5c37cc1d7989f07fd23ecbf088cca6dda180`; A/B/C cuestionarios SHA `d2de0f03b8d347b298f7355312953d772a94edf21443bded042dd2a2ec487ae1`, `beffe06a96a58d3b028539f419d28b5d9d325bbd0ee70f576e06e2608d63e689`, `793a87dfa9757b135accd2ed27f75f7b9575e8de24003b63d93cb31d24f277be`. Import efectivo `numpy==2.3.5`; resto biblioteca estándar y medidor autocontenido.
