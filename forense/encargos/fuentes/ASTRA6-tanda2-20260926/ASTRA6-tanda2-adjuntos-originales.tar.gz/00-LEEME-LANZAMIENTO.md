# ASTRA6 · Tanda2 · lanzamiento

Seis encargos nuevos que **continúan lo fusionado** en #1166 y #1170–#1174 y atienden #1178. Corte consultado: `4541b9f7e884b280e08014bf1f384fe0d1b7cd82`. Cada encargo contiene misión, adenda, firma existente y cláusula de autonomía con sus hashes. No vuelvas a lanzar la tanda1 ni dupliques su firma.

| Sesión | Encargo | Entrega | Entorno |
|---|---|---|---|
| 01 | `ASTRA6-C1-VALIDACION-LOTE1-1` | Primeros recálculos independientes y comparación de nueve paquetes | CAJA; orquestador NO CIEGO y validadores NUEVOS aislados |
| 02 | `ASTRA6-C1-PAQUETES-2` | Completar la preparación restante sin reconstruir métodos desde el productor | CAJA para acceso y proyección autorizada; preparación NO CIEGA |
| 03 | `ASTRA6-C2-CIERRE-MATERIAL-1` | Hacer verificables los contratos y emisiones C2 fusionados | CAJA para replay histórico autorizado; sin R futura |
| 04 | `ASTRA6-C3-CONSUMO-FAMILIA-2` | Corregir los dictámenes sustantivos de consumo y familia | NUBE/CLI con web, sin microdato |
| 05 | `ASTRA6-C3-TRABAJO-MOVILIDAD-1` | Trabajo, movilidad social y clase media | NUBE/CLI con acceso a literatura primaria; sin microdato |
| 06 | `ASTRA6-C3-GENERO-VIOLENCIA-SALUD-1` | Género, violencia ambiental y salud mental | NUBE/CLI con acceso a literatura primaria; sin microdato |

## Cómo repartir

Extrae el ZIP y adjunta UN archivo 01–06 a cada sesión Codex responsable. Mensaje: «Ejecuta íntegro el encargo adjunto como continuación de lo fusionado. Verifica main y los sucesores ya existentes, trabaja en tu worktree y entrega PR con recibo solicitado a Claude. No fusiones ni abras reservas».

Las seis sesiones responsables pueden comenzar en paralelo; tienen raíces y objetos distintos. Prioridad de atención:04 corrige error publicado y01 produce primera evidencia independiente, sin bloquear05–06. Sesión03 resuelve pendientes reales C2, no repite la primera tanda. Sesión02 no modifica entradas de01.

**C1 tiene una separación adicional imprescindible:**01 es ORQUESTADOR NO CIEGO. Lanza hasta nueve sesiones nuevas aisladas a partir de los paquetes mínimos ya preparados; no comparte con ellas este archivo, los encargos, los adjuntos, el historial ni el clon. No basta abrir otra conversación con acceso al repo. Si el entorno no permite aislamiento efectivo, no etiquetar el recálculo como ciego. Primero un paquete completo hasta comparar, después los restantes; no simular ejecución con una prueba del lanzador.

Las ramas de01 y02 no editan el universo original ni los scripts compartidos; entregan tablas sucesoras por identidad en raíces separadas.05 y06 producen tres reports por rama y solo índice local, evitando colisiones del índice global. Cada pieza puede dividirse conforme a AGENTS de CLI manteniendo el perímetro; no heredar contexto conocido a validadores ciegos.

## Qué pedir a Claude

Continuar el recibo pendiente de #1166 y #1171 bajo #1178 (N=1/N=2). Después recibir correcciones 04 y03 sobre sus HEAD reales; no repetir el DEVOLVER mecánico ENVIPE superado por 500c0953. Mesa decide firmas/adopción y fusión. La sesión Codex que escribe el recibo-para-claude solo lo solicita.

## Verificación del paquete

`sha256sum -c SHA256SUMS.txt` después de extraer. Cada encargo es autosuficiente para dirección; los adjuntos embebidos se extraen conservando bytes según instrucciones. Todos están prohibidos como entrada del validador ciego.

Ver `07-REVISION-PR-Y-DECISION.md` para evidencia, límites de esta revisión y trabajo posterior comprometido. No se lanzaron sesiones ni se ejecutaron replays desde este chat.
