B. CUESTIONARIO




                                               ENCUESTA NACIONAL SOBRE LA DINÁMICA
                                              DE LAS RELACIONES EN LOS HOGARES 2006
                                                              CUESTIONARIO GENERAL Y SECCIONES




                                                                                                                                                                                                                INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                PARA LA MUJER CASADA O UNIDA
1. DATOS DE IDENTIFICACIÓN                                                                        2. CONTROL DE VIVIENDA

 ENTIDAD FEDERATIVA                                                                                 NÚMERO DE CONTROL ....................




                                                           $
 MUNICIPIO O DELEGACIÓN
                                                                                                    NÚMERO DE VIVIENDA SELECCIONADA ...............................
 LOCALIDAD
                                                                                                                                                                                                 A




                                                          5
                                                                                                    TIPO DE INSTRUMENTO ...................................................................
 AGEB ............................................................

3. DIRECCIÓN DE LA VIVIENDA                                                                                                                                   4. CUESTIONARIOS




                                                         7
                                                                                                                                                                CUESTIONARIO
                                                        CALLE, AVENIDA, CALLEJÓN, CARRETERA, CAMINO




                                                        6
                                                                                                                                                                DE              UTILIZADO(S)
    NÚMERO                 NÚMERO                                    COLONIA, FRACCIONAMIENTO, BARRIO, UNIDAD HABITACIONAL
                                                                                                                                                                EN LA VIVIENDA
    EXTERIOR               INTERIOR




                                                       (
5. RESULTADO DE LA VISITA A LA VIVIENDA Y SUPERVISIÓN
                   FECHA                                       HORA                   RESULTADO                CÓDIGOS DE RESULTADO
 VISITA                                                                               DE LA VISITA            DE LA VISITA A LA VIVIENDA                             TIPO DE MUJER ELEGIDA
                DÍA          MES                 INICIO                 TÉRMINO




                                                      8
                                                                                                                                                                    Mujer unida y mujer
                                                                                                       01 Entrevista(s) completa(s).
   1a                                               :                      :                                                                                        soltera.......................... A
                                                                                                       02 Entrevista completa de la mujer unida
                                                                                                          o alguna vez unida (divorciada,                           Sólo mujer unida .......... B




                                                     0
                                                                                                          separada o viuda) e incompleta
   2a                                                                                                     o pendiente de la mujer soltera .                         Mujer alguna vez
                                                    :                      :                           03 Entrevista incompleta o pendiente                         unida (divorciada,
                                                                                                          de la mujer unida o alguna vez unida                      separada o viuda) y
                                                                                                          (divorciada, separada o viuda) y                          mujer soltera ................ C
   3a                                                                                                     completa de la mujer soltera.
                                                    :                      :
                                                                                                       04 Entrevista(s) incompleta(s) y/o                           Sólo mujer alguna vez
                                                                                                          pendiente(s) de la(s) mujer(es)                           unida (divorciada,
                                                                                                          elegida(s).                                               separada o viuda) .... D
   4a                                               :                      :                           05 Entrevista incompleta sin ningún
                                                                                                          tipo de mujer elegible o sin definir si                   Sólo mujer soltera ...... E
                                                                                                          la hay.
   5a                                                                                                                                                               Sin ningún tipo de
                                                    :                      :                                                                                        mujer elegible ............. F

                                                                               RESULTADO DE LA SUPERVISIÓN


                                             NOMBRE Y PUESTO                                                     DÍA               MES                    RESULTADO             MUJER INFORMANTE



6. RESPONSABLES                                                                                   7. CONTROL DE PAQUETE

 ENTREVISTADORA:

                                                                                                   FOLIO DE PAQUETE .......................................................

 SUPERVISORA DE ENTREVISTADORAS:
                                                                                                   CONSECUTIVO DEL CUESTIONARIO
                                                                                                   EN EL PAQUETE .......................................................................

 VALIDADOR(A):


                                                                                                                                                                                                          151
                                   I. CARACTERÍSTICAS DE LA VIVIENDA E IDENTIFICACIÓN DE HOGARES

1.1 ¿De qué material es la mayor                                      1.2 ¿Cuántos cuartos se usan para                          1.3 ¿Cuántos focos tienen en esta
parte del piso de esta vivienda?                                      dormir sin contar pasillos?                                vivienda?

              CIRCULE UN SOLO CÓDIGO




Tierra .........................................    1                                ANOTE CON NÚMERO




                                                                                                                                                                                           INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
Cemento o firme .......................             2                  ¿Cuántos cuartos tiene en total esta
                                                                                                                                              ANOTE CON NÚMERO
                                                                          vivienda contando la cocina?
                                                                         (no cuente pasillos ni baños)
Madera, mosaico                                                                                                                      SI LA RESPUESTA ES NINGUNO, ANOTE 00
u otro material ...........................         3




                                                   $
                                                                                     ANOTE CON NÚMERO




1.4 ¿En esta vivienda tienen ...                                                1.5 ¿En esta vivienda tienen agua                    1.6 ¿Esta vivienda tiene drenaje o




                                                  5
                                                                                de ...                                               desagüe conectado a ...
           ANOTE EN CADA CASO EL CÓDIGO INDICADO
                                                                                             CIRCULE UN SOLO CÓDIGO                           CIRCULE UN SOLO CÓDIGO




                                                 7
                                           Sí .....................   1
                                                                                     la red pública dentro
                                           No ....................    2
                                                                                     de la vivienda? ..................      1          la red pública? ..................       1




                                                6
  1) radio? ...............................................                          la red pública fuera de
                                                                                     la vivienda, pero dentro                           una fosa séptica? ............           2
  2) televisión? ........................................




                                               (
                                                                                     del terreno? ......................     2
  3) videocasetera o DVD? ....................
                                                                                     una llave pública                                  una tubería que va
                                                                                     (o hidrante)? .....................     3          a dar a una barranca
  4) computadora? .................................




                                              8
                                                                                                                                        o grieta? ............................   3
  5) línea telefónica? ..............................                                otra vivienda? ...................      4

  6) teléfono celular? .............................                                                                                    una tubería que
                                                                                     una pipa? ..........................    5




                                             0
                                                                                                                                        va a dar a un río,
  7) refrigerador? ...................................                                                                                  lago o mar? .......................      4
                                                                                     un pozo? ............................   6
  8) lavadora? .........................................
                                                                                     un río, arroyo,                                    ¿No tiene drenaje? ...........           5
  9) automóvil o camioneta propios? ...                                              lago u otro? .......................    7
10) cisterna o aljibe? ............................

11) calentador de agua (boiler)? ..........



1.7 ¿Cuántas personas viven                                           1.8 ¿Todas las personas que viven en                       1.9 Entonces, ¿cuántos hogares o
normalmente en esta vivienda,                                         esta vivienda comparten un mismo                           grupos de personas tienen gasto
contando a los niños chiquitos, a los                                 gasto para comer?                                          separado para comer, contando el de
ancianos y a los discapacitados?                                                                                                 usted?
Cuente también a los trabajadores                                                 CIRCULE UN SOLO CÓDIGO
domésticos que duermen aquí.

                                                                                                             PASE A LA
                                                                           Sí ..................   1         SECCIÓN II


                 ANOTE CON NÚMERO                                          No ................     2                                          ANOTE CON NÚMERO




                                                                                                                                               Cuestionario general                  3
                                                                                                                                                                                     153
                                                                                                                                                                                                    II. DATOS SOCIODEMOGRÁFICOS Y ELEGIBILIDAD

                                                                                                                                                                 Número de renglón del(la) informante                                                                                       PARA PERSONAS DE
                                                                                                                                                                                                                                                                                              5 AÑOS O MÁS
                                                                                                                                                                                             PARA TODOS LOS RESIDENTES DE LA VIVIENDA

                                                                                                                                                                                                                 2.2 PARENTESCO
                                                                                                                                                                         2.1 LISTA DE RESIDENTES                                                 2.3 SEXO           2.4 EDAD            2.5 NIVEL DE INSTRUCCIÓN
                                                                                                                                                                                                                CON EL(LA) JEFE(A)


                                                                                                                                                                   Dígame el nombre de todos los              ¿Qué parentesco                  (NOMBRE) es        ¿Cuántos          ¿Hasta qué año o grado
                                                                                                                                                                   residentes de esta vivienda                tiene (NOMBRE)                   hombre             años              aprobó (NOMBRE) en la




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                   empezando por la jefa o el jefe            con la(el)                                          cumplidos         escuela?
                                                                                                                                                                   del hogar. Incluya a los niños             JEFA(E)?                         (NOMBRE) es        tiene
                                                                                                                                                                   chiquitos, a los ancianos y a                                               mujer              (NOMBRE)?                    ANOTE NIVEL Y GRADO

                                                                                                                                                                   los discapacitados.                        Jefa(e) ................... 1
                                                                                                                                                                                                                                                                                                                             Nivel
                                                                                                                                                                                                              Esposo(a) o                                                           Ninguno .................................. 0 0




                                                                                                                                                                                                   $
                                                                                                                                                                                                                                                Hombre .. 1         ANOTE CON
                                                                                                                                                                                                              compañero(a) ........ 2




                                                                                                                                            Número de renglón
                                                                                                                                                                     SI EN LA PREGUNTA 1.9 SE REGISTRÓ MÁS                                                          NÚMERO LA
                                                                                                                                                                         DE UN HOGAR MENCIONE QUE LOS                                                               RESPUESTA       Preescolar .............................. 0 1
                                                                                                                                                                       NOMBRES SE LOS PROPORCIONE POR                                           Mujer ...... 2
                                                                                                                                                                     HOGAR, COMENZANDO CADA GRUPO DE          Hija(o) .................... 3                                        Primaria ................................... 0 2
                                                                                                                                                                    NOMBRES POR EL DE LA JEFA O EL JEFE, DE                                                          PARA LOS
                                                                                                                                                                                                                                                                  MENORES DE UN     Secundaria ............................. 0 3




                                                                                                                                                                                                  5
                                                                                                                                                                        ACUERDO CON EL SIGUIENTE ORDEN        Nieta(o) .................. 4                       AÑO ESCRIBA 000
                                                                                                                                                                                                                                                                                    Carrera técnica con
                                                                                                                                                                                                                                                                                    secundaria terminada ........... 0 4
                                                                                                                                                                   Dígamelos en el siguiente orden:                                                                                 Preparatoria o bachillerato .... 0 5




                                                                                                                                                                                                 7
                                                                                                                                                                                                                SI LA RESPUESTA ES
                                                                                                                                                                                                                   ALGUNA DE LAS                                                    Carrera técnica con
                                                                                                                                                                                                               ANTERIORES, ANOTE EL
                                                                                                                                                                   Jefa o jefe.                                CÓDIGO EN LA CASILLA
                                                                                                                                                                                                                                                                                    preparatoria terminada .......... 0 6
                                                                                                                                                                                                                CORRESPONDIENTE                                                     Normal .................................... 0 7
                                                                                                                                                                   Cónyuge de la jefa o jefe.




                                                                                                                                                                                                6
                                                                                                                                                                   Hijas o hijos solteros.
                                                                                                                                                                                                              EN CUALQUIER OTRO CASO,                                               Profesional ............................. 0 8
                                                                                                                                                                                                               ESCRIBA LA RESPUESTA
                                                                                                                                                                                                                                                                                    Maestría .................................. 0 9
                                                                                                                                                                   Personas casadas y sus hijos.
                                                                                                                                                                                                                                                                                    Doctorado ............................... 1 0
                                                                                                                                                                   Otros parientes, amigos




                                                                                                                                                                                               (
                                                                                                                                                                   o trabajadores domésticos
                                                                                                                                                                   que viven aquí.




                                                                                                                                                                                              8
                                                                                                                                                                                                                  RECUERDE QUE DE ESTA
                                                                                                                                                                                                                                                              ANOTE EL CÓDIGO QUE
                                                                                                                                                                       NOMBRE Y APELLIDO                        PREGUNTA Y HASTA LA 2.10 EL
                                                                                                                                                                                                                                                             CORRESPONDA EN CADA                   NIVEL            GRADO
                                                                                                                                                                                                              REGISTRO LO HARÁ POR PERSONA,
                                                                                                                                                                                                                                                              UNA DE LAS CASILLAS
                                                                                                                                                                                                               HASTA TERMINAR CON LA LISTA




                                                                                                                                                                                             0
                                                                                                                                            01



                                                                                                                                            02



                                                                                                                                            03



                                                                                                                                            04



                                                                                                                                            05



                                                                                                                                            06



                                                                                                                                            07



                                                                                                                                            08



                                                                                                                                            09



                                                                                                                                            10


                                                                                                                                       4                        Cuestionario general
                                                                                                                                      154
                                                         II. DATOS SOCIODEMOGRÁFICOS Y ELEGIBILIDAD
                                                                                                                                                                    SÓLO PARA
                                                          PARA PERSONAS DE 12 AÑOS CUMPLIDOS O MÁS                                                                  MUJERES DE
                                                                                                                                                                  15 AÑOS O MÁS

                               2.6 CONDICIÓN                              2.7 VERIFICACIÓN                       2.8 POSICIÓN EN                2.9 ESTADO         2.10 FECHA DE
                               DE ACTIVIDAD                                 DE ACTIVIDAD                          LA OCUPACIÓN                  CONYUGAL            NACIMIENTO


                    ¿La semana pasada                         ¿Aunque ya me dijo que                        ¿En su trabajo o                  ¿Actualmente        ¿En qué día y
                    (NOMBRE) ...                              (NOMBRE) no trabajó, dígame                   negocio de la                     (NOMBRE)            mes nació




                                                                                                                                                                                         INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                              si la semana pasada ...                       semana pasada                     está ...            (NOMBRE)?
                                                                                                            (NOMBRE) fue ...
                    trabajó? .................... 1           vendió o hizo
                                                       PASE
                                                         A    algún producto                                empleado? ............... 1       casado(a) o
                    tenía trabajo, pero                 2.8   para su venta? ................. 1                                              unido(a)? ..... 1
                    no trabajó? ............... 2                                                           obrero? .................... 2




                                                             $
                                                              prestó algún servicio                                                           separado(a),




Número de renglón
                    buscó trabajo? ........ 3                 a cambio de un pago                           jornalero o peón? .. 3
                                                                                                                                              divorciado(a),
                    ¿Es estudiante? ..... 4                   (cortar el cabello,                           trabajador por su                 o viudo(a)? .. 2
                                                              dar clases, lavar                             cuenta (no contrata
                    ¿Se dedica a los




                                                            5
                                                              ropa ajena)? ..................... 2          trabajadores)? ........ 4         soltero(a)? .. 3
                    quehaceres del
                    hogar? ....................... 5          ayudó en las tierras o                        patrón o empleador
                                                              en el negocio de un                           (contrata
                    ¿Está jubilado(a)




                                                           7
                                                              familiar u otra persona? 3                    trabajadores)? ........ 5
                    o pensionado(a)? ... 6
                                                                                                                                                                     ANOTE CON
                                                              estaba esperando                              trabajador sin pago                                      NÚMERO LA
                    ¿Tiene alguna                             continuar con su                              en un negocio                                            RESPUESTA
                    limitación física                         trabajo o negocio? .......... 4




                                                          6
                                                                                                            familiar? ................... 6
                    o mental que le                    PASE                                          PASE
                    impide trabajar? ..... 7             A    entonces, ¿no trabajó? . 5               A
                                                                                                            trabajador sin
                                                        2.9                                           2.9
                                                                                                            pago en
                    no trabajó? ............... 8
                                                                                                            un negocio no




                                                         (
                                                                                                            familiar? ................... 7




                                                        8
                                                                                   ANOTE EL CÓDIGO QUE CORRESPONDA
                                                                                                                                                                    DÍA     MES
                                                                                     EN CADA UNA DE LAS PREGUNTAS




                                                       0
  01



  02



  03



  04



  05



  06



  07



  08



  09



  10


                                                                                                                                                   Cuestionario general            5
                                                                                                                                                                                   155
                                                                                                                                                                                                                II. DATOS SOCIODEMOGRÁFICOS Y ELEGIBILIDAD

                                                                                                                                                                             PARA MUJERES                                     PARA MUJERES                              PARA MUJERES DE                               PARA TODOS LOS
                                                                                                                                                                            DE 15 AÑOS O MÁS,                               DE 15 AÑOS O MÁS,                     15 AÑOS O MÁS, SEPARADAS,                         MIEMBROS DEL HOGAR
                                                                                                                                                                                SOLTERAS                                    CASADAS O UNIDAS                         DIVORCIADAS O VIUDAS                           DE LA MUJER ELEGIDA


                                                                                                                                                                                                                                                                          2.13 ELEGIBILIDAD B                       2.14 PARENTESCO CON LA
                                                                                                                                                                                                                                                                                                                         MUJER ELEGIDA
                                                                                                                                                                      2.11 SELECCIÓN DE LA MUJER                            2.12 ELEGIBILIDAD A
                                                                                                                                                                                                                                                                          APLICAR SÓLO SI EN 2.12                    APLICAR SÓLO SI EN 2.12 Ó 2.13
                                                                                                                                                                                SOLTERA                                                                                  NO HUBO MUJER ELEGIBLE                         HUBO MUJER ELEGIDA




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                   Mujer de 15 años o más,                           Mujer de 15 años o más,                      Mujer de 15 años o más,                          ¿Qué parentesco tiene
                                                                                                                                                                   soltera ..................................... 1   casada o unida ......................... 1   separada, divorciada                             (NOMBRE) con (NOMBRE
                                                                                                                                                                                                                                                                  o viuda .................................... 1   DE LA MUJER ELEGIDA)?

                                                                                                                                                                       SI HAY MÁS DE UNA, ELIJA A LA DEL               SI HAY MÁS DE UNA, ELIJA A LA DEL            SI HAY MÁS DE UNA, ELIJA A LA DEL
                                                                                                                                                                          CUMPLEAÑOS MÁS CERCANO                          CUMPLEAÑOS MÁS CERCANO                       CUMPLEAÑOS MÁS CERCANO                      Mujer elegida ................... 1
                                                                                                                                                                                                                                                                     Y ANOTE EL CÓDIGO UNO EN EL




                                                                                                                                                                                                         $
                                                                                                                                                                    ANOTE EL CÓDIGO UNO EN EL RENGLÓN                ANOTE EL CÓDIGO UNO EN EL RENGLÓN                   RENGLÓN DE LA MUJER
                                                                                                                                                                                                                                                                                                                   Esposo o compañero ..... 2




                                                                                                                                            Número de renglón
                                                                                                                                                                        DE LA MUJER SELECCIONADA                         DE LA MUJER SELECCIONADA                            SELECCIONADA

                                                                                                                                                                       APLICAR A LA MUJER SOLTERA                    APLIQUE LA PREGUNTA 2.14 Y DESPUÉS           APLIQUE LA PREGUNTA 2.14 Y DESPUÉS               Hijo (a) ............................ 3
                                                                                                                                                                      SELECCIONADA EL MÓDULO PARA                    CONTINUE EN LA SECCIÓN III DE ESTE               PASE AL MÓDULO DE MUJERES
                                                                                                                                                                   MUJERES SOLTERAS, SÓLO DESPUÉS DE                   CUESTIONARIO (SECCIONES PARA                DIVORCIADAS, SEPARADAS Y VIUDAS                 Nieto (a) .......................... 4




                                                                                                                                                                                                        5
                                                                                                                                                                   HABER TERMINADO LA ENTREVISTA DE LA                  MUJERES CASADAS O UNIDAS)
                                                                                                                                                                    MUJER SELECCIONADA EN 2.12 Ó EN 2.13                                                                                                           Suegro (a) ...................... 5




                                                                                                                                                                                                       7
                                                                                                                                                                   No hay mujer soltera                              No existe mujer elegible con                 No existe mujer elegible con
                                                                                                                                                                   de 15 años o más .................. 2             esas características ................ 2      esas características .............. 2

                                                                                                                                                                              ANOTE EL CÓDIGO DOS                            ANOTE EL CÓDIGO DOS                  ANOTE EL CÓDIGO DOS EN EL PRIMER                   SI LA RESPUESTA ES ALGUNA




                                                                                                                                                                                                      6
                                                                                                                                                                              EN EL PRIMER RENGLÓN                           EN EL PRIMER RENGLÓN                            RENGLÓN                                 DE LAS ANTERIORES ANOTE
                                                                                                                                                                                                                                                                                                                       EL CÓDIGO EN LA CASILLA
                                                                                                                                                                                                                                                                    VERIFIQUE EN 2.11 SI HAY MUJER                        CORRESPONDIENTE
                                                                                                                                                                                                                                                                    SOLTERA ELEGIDA Y APLÍQUELE EL
                                                                                                                                                                                                                                                                   MÓDULO PARA MUJERES SOLTERAS.                      EN CUALQUIER OTRO CASO




                                                                                                                                                                                                     (
                                                                                                                                                                                                                                                                     DE NO HABER SOLTERA ELEGIDA                       ESCRIBA LA RESPUESTA
                                                                                                                                                                                                                                                                        TERMINE LA ENTREVISTA




                                                                                                                                                                                                    8
                                                                                                                                                                                                                                      ANOTE EL CÓDIGO QUE CORRESPONDA
                                                                                                                                                                                                                                        EN CADA UNA DE LAS PREGUNTAS




                                                                                                                                            01




                                                                                                                                                                                                   0
                                                                                                                                            02



                                                                                                                                            03



                                                                                                                                            04



                                                                                                                                            05



                                                                                                                                            06



                                                                                                                                            07



                                                                                                                                            08



                                                                                                                                            09



                                                                                                                                            10


                                                                                                                                       6                        Cuestionario general
                                                                                                                                      156
                                  SECCIONES PARA LA MUJER CASADA O UNIDA

                                                 III. ÁMBITOS LABORAL, ESCOLAR Y SOCIAL


3.1 Nombre de la mujer elegida




                                                                                                                                                                     INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                      ANOTE EL NÚMERO DEL RENGLÓN DE LA SECCIÓN II




3.2 ¿Usted trabaja?                                        3.3 ¿Cuánto gana o recibe usted por su trabajo?

                   CIRCULE UN SOLO CÓDIGO                                   ANOTE LA CANTIDAD RECIBIDA Y EL CÓDIGO DEL PERIODO INDICADO




                                               $
                                                                                                                                      Periodo
   Sí ........ 1                                           $               ,              ¿en qué periodo?                Semana .......................... 1




                                              5
                                                                  ANOTE CON NÚMERO
                                                                                                                          Quincena ........................ 2
   No ...... 2              PASE A 3.4                                                                                    Mes ................................. 3
                                                                                                                          No recibe ingresos ........ 4



3.4 ¿Su esposo o pareja trabaja?

                   CIRCULE UN SOLO CÓDIGO




                                            67             3.5 ¿Cuánto gana o recibe su esposo o pareja por su trabajo?

                                                                            ANOTE LA CANTIDAD RECIBIDA Y EL CÓDIGO DEL PERIODO INDICADO


                                                                                                                                      Periodo




                                           (
                                                           $               ,              ¿en qué periodo?                Semana .......................... 1
   Sí ....... 1                                                    ANOTE CON NÚMERO                                       Quincena ........................ 2
   No ...... 2                                                                                                            Mes ................................. 3




                                          8
                           PASE A 3.6
                                                                                                                          No recibe ingresos ........ 4
                                                                                                                          No sabe cuánto recibe .. 5




                                         0
3.6 ¿Usted recibe ingresos por apoyo                 3.7 ¿Desde hace cuánto tiempo recibe               3.8 ¿Usted recibe ingresos de
del Programa Oportunidades?                          apoyo del Programa Oportunidades?                  familiares o conocidos?

             CIRCULE UN SOLO CÓDIGO                                                                                  CIRCULE UN SOLO CÓDIGO



         Sí ........ 1                                                   AÑOS                                     Sí ........ 1
                                                      SI LA RESPUESTA ES MENOS DE UN AÑO, ANOTE 00
         No ...... 2            PASE A 3.8                                                                        No ...... 2            PASE A 3.11




3.9 ¿Qué familiares le ayudan con                    3.10 Los familiares o conocidos que la              3.11 ¿Usted recibe ingresos por
dinero?                                              ayudan, ¿viven o trabajan…                          jubilación o pensión?

        CIRCULE LAS OPCIONES INDICADAS                      CIRCULE LAS OPCIONES INDICADAS                           CIRCULE UN SOLO CÓDIGO



 Padre o madre ......................        1        en Estados Unidos? .............. 1
                                                                                                                            Sí ........ 1
 Hija(s)/hijo(s) ........................    2        en otro país distinto
                                                      a Estados Unidos? ................ 2
                                                                                                                            No ...... 2
 Hermano(s)/hermana(s) ......                3
                                                      en otro lugar del país? .......... 3
 Otros familiares ....................       4
                                                      en esta misma localidad? .... 4
 Personas conocidas ............             5


                                                                                                Secciones para la mujer casada o unida                          7
                                                                                                                                                               157
                                                                                                                                                                                                   III. ÁMBITOS LABORAL, ESCOLAR Y SOCIAL

                                                                                                                                       3.12 ¿Usted recibe ingresos por apoyo                               3.13 ¿Recibe otro tipo de ingresos?                                 SI AL MENOS HUBO UNA RESPUESTA
                                                                                                                                       de otro(s) programa(s) de gobierno?                                                                                                     AFIRMATIVA EN 3.6, 3.8, 3.11, 3.12 Ó 3.13
                                                                                                                                                                                                                             CIRCULE UN SOLO CÓDIGO                            SIEMPRE APLICAR 3.14. SI TODAS FUERON
                                                                                                                                                         CIRCULE UN SOLO CÓDIGO                                                                                                NEGATIVAS PASE A LA PREGUNTA 3.15

                                                                                                                                                                                                                                                                                3.14 En total, ¿cuánto recibe usted al
                                                                                                                                                               Sí ........ 1                               Sí ........ 1                                                        mes de estos otros ingresos?
                                                                                                                                                                                                                                              ESPECIFIQUE

                                                                                                                                                               No ...... 2                                 No ...... 2                                                                      $                   ,




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                                                                                                                                                    ANOTE CON NÚMERO


                                                                                                                                           3.15 Durante el último año (octubre de 2005 a la fecha),                                           3.16 ¿Su lugar de trabajo es …
                                                                                                                                           ¿usted trabajó como …
                                                                                                                                                                                                                                                                              CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                         CIRCULE UN SOLO CÓDIGO




                                                                                                                                                                                         $
                                                                                                                                                                                                                                               oficina de dependencia pública? ................................. 01
                                                                                                                                           empleada? ............................................................... 1                         oficina de empresa privada? ....................................... 02
                                                                                                                                           obrera? .................................................................... 2                      comercio? ..................................................................... 03




                                                                                                                                                                                        5
                                                                                                                                           jornalera? ................................................................ 3                       banco o servicios privados? ........................................ 04
                                                                                                                                           trabajadora por su cuenta? ................................... 4                                    escuela? ........................................................................ 05




                                                                                                                                                                                       7
                                                                                                                                           patrona? .................................................................. 5                       fábrica? .......................................................................... 06

                                                                                                                                           trabajadora sin pago en negocio familiar? .......... 6                                PASE          taller, maquila? .............................................................. 07
                                                                                                                                                                                                                                   A
                                                                                                                                           trabajadora sin pago en negocio
                                                                                                                                                                                                                                  3.21         casa? .............................................................................. 08




                                                                                                                                                                                      6
                                                                                                                                           no familiar? .............................................................. 7                       campo? .......................................................................... 09
                                                                                                                                           No trabajó ................................................................. 8                      Otro ................................................................................. 10




                                                                                                                                                                                     (
                                                                                                                                           3.17 ¿Cuánto                3.18 Durante el último año (octubre de 2005 a la fecha) ¿usted vivió alguna de las                                                                 Sí ................ 1
                                                                                                                                           tiempo ha                   siguientes situaciones en su trabajo?                                                                                                              No ............... 2
                                                                                                                                           trabajado o                                                                                                                                                                    No aplica .... 3




                                                                                                                                                                                    8
                                                                                                                                           trabajó en ese                                                                   ANOTE LAS OPCIONES INDICADAS

                                                                                                                                           lugar?
                                                                                                                                                                       1) ¿Le pidieron la prueba de embarazo como requisito para entrar? ..................................................
                                                                                                                                                                       2) ¿La despidieron, no le renovaron contrato o le bajaron el salario por embarazarse? ...................




                                                                                                                                                                                   0
                                                                                                                                                                       3) ¿Le pagaron menos que a un hombre que hace lo mismo? ..............................................................
                                                                                                                                                  AÑOS
                                                                                                                                                                       4) ¿Tuvo menos oportunidad para ascender que un hombre? ..............................................................
                                                                                                                                           MENOS DE UN AÑO             5) ¿Recibió menos prestaciones que un hombre? .................................................................................
                                                                                                                                              ANOTE 00
                                                                                                                                                                       6) ¿Debido a su edad o a su estado civil, la despidieron, le bajaron el salario
                                                                                                                                                                          o no la contrataron? ..............................................................................................................................

                                                                                                                                           3.19 Durante el último año (octubre de 2005 a la fecha) en                                                                                                   APLIQUE ESTA PREGUNTA
                                                                                                                                           su trabajo, ¿su jefe inmediato, algún directivo o algún                                       Sí ........... 1                                               SÓLO SI EN 3.18 Ó 3.19
                                                                                                                                                                                                                                                              ¿Quién o quiénes?
                                                                                                                                           compañero, alguna vez …                                                                                                                                      HUBO AL MENOS UNA RES-
                                                                                                                                                                                                                                         No .......... 2    NO ANOTE NOMBRES PROPIOS
                                                                                                                                                                                                                                                                                                        PUESTA AFIRMATIVA
                                                                                                                                                      ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS
                                                                                                                                                         DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO                                                                                                 3.20 Debido a estos
                                                                                                                                                                                                                                                                                                         problemas, ¿hizo
                                                                                                                                           1) la humilló o denigró? ...................................................................
                                                                                                                                                                                                                                                                                                         alguna denuncia o
                                                                                                                                           2) la agredió físicamente? ..............................................................                                                                     puso alguna queja
                                                                                                                                                                                                                                                                                                         administrativa?
                                                                                                                                           3) la ignoró o hizo sentir menos por ser mujer? ..........................
                                                                                                                                                                                                                                                                                                            CIRCULE UN SOLO CÓDIGO
                                                                                                                                           4) le hizo insinuaciones o propuestas para tener relaciones
                                                                                                                                              sexuales a cambio de mejores condiciones en el trabajo? ...
                                                                                                                                           5) la acarició o manoseó sin su consentimiento? .......................                                                                                                  Sí ........ 1
                                                                                                                                           6) la obligó a tener relaciones sexuales? .....................................
                                                                                                                                                                                                                                                                                                                    No ...... 2
                                                                                                                                           7) tomó represalias contra usted por haberse negado
                                                                                                                                              a sus pretensiones? ...................................................................

                                                                                                                                       8          Secciones para la mujer casada o unida
                                                                                                                                      158
                                                   III. ÁMBITOS LABORAL, ESCOLAR Y SOCIAL

3.21 ¿Usted asiste o asistió alguna vez a la escuela?                                 Sí ........ 1

                                                                                      No ...... 2             PASE A 3.24



3.22 Durante su vida de estudiante, ¿algún compañero, maestro, personal                                                        APLIQUE ESTA PREGUNTA SÓLO SI EN 3.22
o autoridad escolar …                                                                                                              HUBO AL MENOS UNA RESPUESTA
                                                                                                                                            AFIRMATIVA
                     ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS
                                                                                                                                3.23 Cuando esto ocurrió, ¿avisó o




                                                                                                                                                                                               INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                        DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO
                                                                                                                                denunció este hecho …
                                                                Sí ........... 1      ¿Quién o quiénes?
                                                                No .......... 2      NO ANOTE NOMBRES PROPIOS                               CIRCULE LAS OPCIONES INDICADAS


1) la humilló o denigró? ...........................................
                                                                                                                                  a familiares? .................................. 1




                                               $
2) la agredió físicamente? ......................................
                                                                                                                                  en el ministerio público? .............. 2
3) la ignoró o le hizo sentir menos por ser mujer?
                                                                                                                                  a la policía? .................................... 3




                                              5
4) le propuso tener relaciones sexuales
   a cambio de calificaciones? ..............................
                                                                                                                                  a las autoridades escolares? ...... 4
5) la acarició o manoseó sin su consentimiento?




                                             7
                                                                                                                                  Otro                                              5
6) la obligó a tener relaciones sexuales? .............                                                                                                    ESPECIFIQUE

7) le impuso castigos o represalias por haberse




                                            6
   negado a sus pretensiones? ..............................                                                                      No dio aviso ni denunció ............... 6


3.24 Dígame si a lo largo de su vida (en la calle, en fiestas, en un club, en su                                               APLIQUE ESTA PREGUNTA SÓLO SI EN 3.24




                                           (
casa, etc.), usted ha experimentado alguna de las siguientes situaciones y de                                                      HUBO AL MENOS UNA RESPUESTA
                                                                                                                                            AFIRMATIVA
parte de quién.
                                                                                                                               3.25 Cuando esto ocurrió, ¿dio aviso
                        ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS
                                                                                                                               o denunció este hecho …




                                          8
                           DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO

                                                                                                                                         CIRCULE LAS OPCIONES INDICADAS
                                                              Sí ........... 1        ¿Quién o quiénes?
                                                              No .......... 2       NO ANOTE NOMBRES PROPIOS,
                                                                                     SINO SUSTANTIVOS DEL TIPO:




                                         0
                                                                                   VECINO, TÍO, DESCONOCIDO, ETC.
1) ¿La acariciaron o manosearon                                                                                                 a familiares? ................................... 1
   sin su consentimiento? ....................................
                                                                                                                                en el ministerio público? ............... 2
2) ¿La obligaron o forzaron a
   tener relaciones sexuales? .............................                                                                     a la policía? ..................................... 3
3) ¿La obligaron a realizar
   actos sexuales por dinero? .............................                                                                     Otro                                                4
                                                                                                                                                          ESPECIFIQUE
4) ¿Le hicieron sentir miedo de
   sufrir un ataque o abuso sexual? ....................
                                                                                                                                No dio aviso ni denunció ................ 5
5) ¿Le han dicho piropos groseros u ofensivos
   sobre su cuerpo o de carácter sexual? ..........


                                                                       IV. VIDA EN PAREJA

4.1 ¿Actualmente usted ...                   4.2 ¿Su actual marido o                   4.3 ¿Por qué no vive aquí con usted?                                    4.4 ¿Desde hace
                                             pareja vive con usted?                                                                                            cuánto tiempo no
       CIRCULE UN SOLO CÓDIGO                                                                           CIRCULE UN SOLO CÓDIGO                                 vive aquí con usted?
                                                CIRCULE UN SOLO CÓDIGO
vive en unión libre? ............ 1                                                    Trabaja en Estados Unidos ................... 1
esta casada ...                                                                        Trabaja en otro lugar dentro del país .... 2
                                                                                                                                                                         AÑOS
sólo por lo civil? ................. 2        Sí ........ 1        PASE A 4.5
                                                                                       Están separados temporalmente ......... 3
                                                                                                                                                                    SI LA RESPUESTA
                                                                                                                                                                  ES MENOS DE UN AÑO,
sólo por la iglesia? ............ 3           No ...... 2                              Están separados definitivamente .......... 4                                     ANOTE 00

civil y religiosamente? ...... 4                                                       Otro ......................................................... 5

                                                                                                                     Secciones para la mujer casada o unida                              9
                                                                                                                                                                                         159
                                                                                                                                                                                                                          IV. VIDA EN PAREJA

                                                                                                                                        4.5 ¿Cuántos años tiene casada o                                4.6 ¿Usted habla alguna lengua indígena?                                    4.7 Su esposo o pareja actual
                                                                                                                                        unida con su actual pareja o esposo?                                                                                                        ¿habla alguna lengua indígena?
                                                                                                                                                                                                                           CIRCULE UN SOLO CÓDIGO

                                                                                                                                                                                                                                                                                                CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                          Sí ........ 1                                        No ...... 2
                                                                                                                                                                                                                                                                                     Sí ........ 1                          No ...... 2
                                                                                                                                                                 AÑOS
                                                                                                                                                                                                              ¿Cuál?
                                                                                                                                                        SI LA RESPUESTA                                                                                                                ¿Cuál?
                                                                                                                                                  ES MENOS DE UN AÑO, ANOTE 00




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                                                                                     ESPECIFIQUE                                                      ESPECIFIQUE



                                                                                                                                        4.8 En total, ¿cuántas                   4.9 ¿Qué edad tenía                    4.10 ¿Cuántas de sus                       4.11 ¿Cuántos hijos e             4.12 ¿Qué edad tenía
                                                                                                                                        hijas e hijos nacidos                    cuando tuvo a su                       hijas e hijos son de                       hijas tiene su esposo             cuando inició el noviazgo
                                                                                                                                        vivos ha tenido?                         primer hija o hijo?                    su esposo o pareja                         o pareja con otras                con su actual pareja o




                                                                                                                                                                                        $
                                                                                                                                                                                                                        actual?                                    mujeres?                          esposo?


                                                                                                                                              ANOTE CON NÚMERO
                                                                                                                                                                                                                            ANOTE CON NÚMERO                           ANOTE CON NÚMERO




                                                                                                                                                                                       5
                                                                                                                                                                                               AÑOS                                                                                                                  AÑOS
                                                                                                                                       SI RESPONDIÓ NINGUNO ANOTE 00
                                                                                                                                          Y PASE A LA PREGUNTA 4.11                                                                                                 SI LA RESPUESTA ES NINGUNO             SI LA RESPUESTA ES
                                                                                                                                                                                                                                                                   ANOTE 00 Y SI NO SABE ANOTE 98        NO RECUERDA, ANOTE 98




                                                                                                                                                                                      7
                                                                                                                                        4.13 ¿Qué edad tenía                     4.14 Cuando se casaron o empezaron a vivir                                            4.15 Contando su                  4.16 ¿Qué edad
                                                                                                                                        cuando se casó o                         juntos, ¿se fueron a vivir ...                                                        actual unión o                    tenía cuando se
                                                                                                                                        empezó a vivir con él?                                                                                                         matrimonio, ¿cuántas              casó o unió por




                                                                                                                                                                                     6
                                                                                                                                                                                                         CIRCULE UN SOLO CÓDIGO                                        veces ha estado                   primera vez?
                                                                                                                                                                                                                                                                       casada o unida?
                                                                                                                                                                                 solos como pareja, con o sin hijos? .................. 1




                                                                                                                                                                                    (
                                                                                                                                                      AÑOS                       con sus padres u otros familiares de usted? ... 2
                                                                                                                                                                                                                                                                            ANOTE CON NÚMERO                             AÑOS
                                                                                                                                                                                 con los padres u otros familiares
                                                                                                                                              SI LA RESPUESTA ES
                                                                                                                                            NO RECUERDA, ANOTE 98                de su esposo (pareja)? ....................................... 3




                                                                                                                                                                                   8
                                                                                                                                                                                                                                                                           SI RESPONDIÓ UNA VEZ,              SI LA RESPUESTA ES
                                                                                                                                                                                 Otro ........................................................................ 4            PASE A LA SECCIÓN V             NO RECUERDA, ANOTE 98



                                                                                                                                        4.17 ¿Dejó de vivir con su esposo o pareja anterior porque ...                                                                                    4.18 ¿Antes             4.19 ¿Después
                                                                                                                                                                                                                                                                                          de separarse            de separarse




                                                                                                                                                                                  0
                                                                                                                                                                     CIRCULE LAS OPCIONES INDICADAS                                                                                       hubo ...                ha habido ...
                                                                                                                                                                                                                                                ANOTE EN CADA CASILLA UN
                                                                                                                                        tenía otra pareja? ..................................           01                                      SOLO CÓDIGO

                                                                                                                                        era flojo? .................................................    02                                                                                             Sí .......... 1

                                                                                                                                        no daba para el gasto? ..........................               03                                                                                             No ......... 2
                                                                                                                                        ya no se querían? ..................................            04
                                                                                                                                        usted encontró otra pareja? .................                   05
                                                                                                                                                                                                                                               1) golpes u otras
                                                                                                                                        hubo problemas de salud? ...................                    06                                        agresiones físicas?
                                                                                                                                        interfirieron razones de trabajo? .........                     07
                                                                                                                                        era alcohólico? .......................................         08
                                                                                                                                        era adicto a drogas? .............................              09                                     2) gritos, insultos
                                                                                                                                        era grosero o agresivo? ........................                10                                        o amenazas?
                                                                                                                                        él o usted se fue a otro lugar? ..............                  11
                                                                                                                                        había violencia física? ...........................             12
                                                                                                                                        Falleció ....................................................   13                PASE A LA            3) agresiones a otros
                                                                                                                                                                                                                          SECCIÓN V
                                                                                                                                                                                                                                                  miembros del hogar?
                                                                                                                                        Otro                                                             14
                                                                                                                                                                  ESPECIFIQUE


                                                                                                                                        4.17.1 ¿Cuál fue la razón principal?

                                                                                                                                                                                                  ANOTE EL CÓDIGO DE LA OPCIÓN



                                                                                                                                       10       Secciones para la mujer casada o unida
                                                                                                                                      160
                                                                             V. FAMILIA DE ORIGEN


Ahora le voy a hacer algunas preguntas de cuando usted era niña, digamos hasta los 13 años.


5.1 Cuando usted era niña,                       5.2 ¿Las personas adultas que la cuidaban y se                                       5.3 ¿Recuerda si entre las personas
¿vivió la mayor parte del                        encargaban de usted, eran ...                                                        con las que vivía había golpes …
tiempo en ...
                                                                         CIRCULE UN SOLO CÓDIGO                                                        CIRCULE UN SOLO CÓDIGO




                                                                                                                                                                                                       INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
      CIRCULE UN SOLO CÓDIGO
                                                  su papá y su mamá o alguno de los dos? ........ 1                                   de vez en cuando? ............................. 1
  un rancho, pueblo                               sus abuelos y/o tíos u otros familiares? .......... 2                               seguido? ............................................ 2
  o comunidad? ............. 1
                                                  otros adultos no familiares? ............................. 3                        No había golpes ................................. 3
  una ciudad? ................ 2
                                                  Otro                                                                    4




                                                   $
                                                                                  ESPECIFIQUE



5.4 ¿Las personas con                        5.5 A usted, ¿las                            5.6 ¿Quién le pegaba con mayor                             5.7 ¿Recuerda si las personas




                                                  5
las que vivía se insultaban                  personas con las que                         frecuencia?                                                con las que vivía la insultaban
o se ofendían …                              vivía le pegaban …                                                                                      o la ofendían …
                                                                                                     CIRCULE UN SOLO CÓDIGO




                                                 7
     CIRCULE UN SOLO CÓDIGO                       CIRCULE UN SOLO CÓDIGO                                                                                     CIRCULE UN SOLO CÓDIGO

                                                                                          Su papá .................................... 1
                                                                                                                                                      de vez en
 de vez en                                   de vez en                                    Su mamá .................................. 2                cuando? ............. 1




                                                6
 cuando? .................... 1              cuando? ......... 1
                                                                                          Su madrastra o padrastro ....... 3                          seguido? ............ 2
 seguido? .................. 2               seguido? ....... 2
                                                                                          Sus abuelos ............................. 4                 No la insultaban                  PASE




                                               (
 No había insultos                           No le                            PASE                                                                    ni la ofendían ...... 3             A
 ni ofensas ................ 3               pegaban ........ 3                 A         Otro                                            5                                              5.9
                                                                               5.7                            ESPECIFIQUE




                                              8
5.8 ¿Quién la insultaba con mayor                                  5.9 Cuando su pareja o esposo era                                  5.10 ¿Sabe si cuando su pareja o
frecuencia?                                                        niño, ¿le pegaban o insultaban en su                               esposo era niño, a la mamá de él le
                                                                   casa …                                                             pegaba su marido?
              CIRCULE UN SOLO CÓDIGO




                                             0
                                                                                  CIRCULE UN SOLO CÓDIGO                                              CIRCULE UN SOLO CÓDIGO

Su papá ............................................ 1
Su mamá .......................................... 2
                                                                   de vez en cuando? ......................... 1                              Sí le pegaba .......................... 1
Su madrastra o padrastro ............... 3
                                                                   seguido? ......................................... 2                       No le pegaba ......................... 2
Sus abuelos ..................................... 4
                                                                   No le pegaban, ni lo insultaban ..... 3                                    No sabe ................................. 3
Otro                                                  5
                                                                   No sabe ........................................... 4
                       ESPECIFIQUE


5.11 Durante el último año (octubre de 2005 a la fecha), sin considerar a su esposo                                                                            ¿Quién o quiénes?
o pareja, ¿alguna persona de su familia la ha …                                                                                                              NO ANOTE NOMBRES PROPIOS,
                                                                                                                                   Sí ................. 1     SINO SUSTANTIVOS DEL TIPO:
                                                                                                                                                            HERMANO, PADRE, SUEGRA, ETC.
                              ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS                                              No ................ 2
                                 DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO


1) insultado u ofendido? .............................................................................................................
2) amenazado con golpearla o correrla de su casa? .............................................................
3) golpeado o agredido físicamente? .......................................................................................
4) humillado o menospreciado? ................................................................................................
5) ignorado, no la toman en cuenta, no le brindan atención? ................................................
6) encerrado? .............................................................................................................................
7) le ha quitado su dinero u obligado a entregar su dinero? ..................................................


                                                                                                                          Secciones para la mujer casada o unida                                11
                                                                                                                                                                                                 161
                                                                                                                                                                                                                  V. FAMILIA DE ORIGEN

                                                                                                                                            5.12. ¿Alguna vez sus familiares u otras personas …                                                                      Sí ................. 1      ¿Quién o quiénes?
                                                                                                                                                                                                                                                                     No ................ 2     NO ANOTE NOMBRES PROPIOS,
                                                                                                                                                                                                                                                                                                SINO SUSTANTIVOS DEL TIPO
                                                                                                                                                                         ANOTE EN CADA CASILLA EL CÓDIGO INDICADO Y EN LOS CASOS                                     No aplica ..... 3        PADRE, HERMANO, VECINO, ETC.
                                                                                                                                                                            DE RESPUESTA AFIRMATIVA, PREGUNTE QUIÉN LO HIZO


                                                                                                                                            1) le han quitado o robado bienes o propiedades? .................................................................
                                                                                                                                            2) le han quitado o robado documentos que la acrediten como propietaria
                                                                                                                                               o posesionaria de algún bien? ..............................................................................................




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                            3) la han obligado a poner a nombre de otra persona las cosas
                                                                                                                                               o propiedades que usted compró o heredó? ......................................................................


                                                                                                                                            5.13 ¿Ha habido herencias                    5.14 En su familia ¿a quién se acostumbra                             5.15 ¿Siente que por ser mujer la herencia
                                                                                                                                            en su familia?                               heredar?                                                              fue desigual y favoreció a los hombres?




                                                                                                                                                                                         $
                                                                                                                                                 CIRCULE UN SOLO CÓDIGO                                    CIRCULE UN SOLO CÓDIGO                                                  CIRCULE UN SOLO CÓDIGO


                                                                                                                                                                                                Mujeres ........................................ 1                    Sí .................................................. 1




                                                                                                                                                                                        5
                                                                                                                                                Sí ........ 1
                                                                                                                                                                                                Hombres ..................................... 2                       No ................................................ 2
                                                                                                                                                                       PASE A LA
                                                                                                                                                No ...... 2                                     Ambos ......................................... 3                     No aplica ..................................... 3




                                                                                                                                                                                       7
                                                                                                                                                                      SECCIÓN VI




                                                                                                                                                                                     (6
                                                                                                                                                                                    8
                                                                                                                                                                                   0

                                                                                                                                        12         Secciones para la mujer casada o unida
                                                                                                                                      162
                                                                    VI. TENSIONES Y CONFLICTOS

 En la vida de las parejas es común que haya situaciones                                   Ahora veamos las cosas al revés.
 que provocan enojo, dígame ...


6.1 ¿Su esposo o pareja se molesta con usted porque ...                                   6.2 ¿Usted se molesta con su esposo o pareja porque ...

    CIRCULE LAS OPCIONES EN LAS QUE OBTENGA UNA RESPUESTA AFIRMATIVA                           CIRCULE LAS OPCIONES EN LAS QUE OBTENGA UNA RESPUESTA AFIRMATIVA




                                                                                                                                                                                             INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
usted trabaja o estudia? .................................................. 01            él le dedica demasiado tiempo a su trabajo
                                                                                          o por su horario? .............................................................. 01
usted no trabaja? .............................................................. 02
                                                                                          él no trabaja? ..................................................................... 02
usted gana más dinero que él? ....................................... 03
                                                                                          él no gana lo suficiente? .................................................. 03
usted dedica demasiado tiempo a su trabajo




                                                  $
o por su horario? .............................................................. 04       a usted no le gusta cómo trata o educa
                                                                                          a sus hijos? ....................................................................... 04
a él no le gusta cómo trata o educa a sus hijos? .......... 05
                                                                                          él es celoso? ..................................................................... 05




                                                 5
él dice que usted es celosa? ........................................... 06
                                                                                          él no respeta sus sentimientos o sus
usted usa anticonceptivos? ............................................. 07               opiniones? ......................................................................... 06




                                                7
dice que usted no le dedica suficiente tiempo                                             él visita demasiado a su familia o amistades? .............. 07
o atención? ........................................................................ 08
                                                                                          él es muy posesivo o absorbente? ................................. 08




                                               6
dice que usted es muy posesiva o absorbente? ........... 09
                                                                                          él no desea tener relaciones sexuales? ........................ 09
visita o la visitan amistades o familiares? ..................... 10
                                                                                          él no le da su lugar? .......................................................... 10




                                              (
a él no le gusta su manera de vestir o usted
no quiere vestirse como él prefiere? .............................. 11                    los parientes de él intervienen o quieren opinar
                                                                                          sobre la forma de educar a sus hijos? ........................... 11
él cree que usted no cumple como madre o esposa? . 12




                                             8
                                                                                          usted cree que él la engaña? .......................................... 12
algún pariente de usted interviene o quiere opinar
sobre la forma de educar a sus hijos? ........................... 13                      él no colabora en los quehaceres de la casa? .............. 13

se queda en algo y usted no cumple? ............................ 14                       él esta enfermo y usted lo tiene que cuidar? ................. 14




                                            0
usted no le obedece? ....................................................... 15           él no siempre cumple con lo que acuerdan? ................. 15

usted está enferma y él la tiene que cuidar? ................. 16                         él dice que es la única autoridad de la casa
                                                                                          y sólo su opinión es la que vale? ..................................... 16
usted toma decisiones en asuntos que él
considera su responsabilidad? ....................................... 17                  usted cree que él no cumple como esposo
                                                                                          o padre? ............................................................................. 17
usted opina diferente o lo desmiente en ciertas
situaciones? ...................................................................... 18    no cuida o usa bien el dinero? ......................................... 18

él dice que usted siempre llora por todo? ...................... 19                       él trae amigos a la casa? ................................................. 19
                                                                                          él no la obedece? .............................................................. 20
él cree que usted lo engaña? .......................................... 20
                                                                                          le quita su dinero o le pide cuentas sobre su dinero? .. 21
usted le dice o le recuerda sus obligaciones? .............. 21
                                                                                          él le recuerda a usted sus obligaciones? ...................... 22
usted sale de su casa sin avisarle o pedir permiso? ... 22
                                                                                          él toma alcohol o se droga? ............................................. 23
usted toma alcohol o se droga? ...................................... 23                  llega tarde o no llega a casa? .......................................... 24
usted no desea tener relaciones sexuales? ................. 24                            aunque él tenga dinero no da gasto o no da
                                                                                          lo suficiente? ..................................................................... 25
él se molesta por todo, sin razón aparente? ................. 25
                                                                                          usted se molesta por todo o sin razón aparente? ......... 26
Otra situación ..................................................................... 26
                                                                                          Otra situación ..................................................................... 27
No se molesta por nada ............................ 27                     PASE A 6.2     No se molesta por nada .............................. 28                        PASE A 6.3




                                                                                                                Secciones para la mujer casada o unida                                13
                                                                                                                                                                                       163
                                                                                                                                             APLIQUE ESTA PREGUNTA SÓLO SI EN 6.1 HUBO AL MENOS                               APLIQUE ESTA PREGUNTA SÓLO SI EN 6.2 HUBO AL MENOS
                                                                                                                                                          UNA RESPUESTA AFIRMATIVA                                                         UNA RESPUESTA AFIRMATIVA

                                                                                                                                            6.1.1 De todo lo que me dijo, ¿qué le molesta más a su                           6.2.1 De lo que me dijo, ¿qué es lo que más le molesta a
                                                                                                                                            esposo o pareja?                                                                 usted?



                                                                                                                                                                 ANOTE ELCÓDIGO CORRESPONDIENTE                                                   ANOTE ELCÓDIGO CORRESPONDIENTE




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                Todas le molestan por igual .................................. 28               Todas me molestan por igual ................................ 29

                                                                                                                                                No pudo decidir ....................................................... 29      No pudo decidir ....................................................... 30


                                                                                                                                                                                                            VI. TENSIONES Y CONFLICTOS




                                                                                                                                                                                       $
                                                                                                                                            LEA UNA POR UNA LAS SITUACIONES AQUÍ DESCRITAS, PRIMERO REFERIDAS AL ESPOSO O PAREJA (6.3) Y DESPUÉS RESPECTO A
                                                                                                                                            LA MUJER ENTREVISTADA (6.4). LEA DESPACIO Y CON CUIDADO PARA EVITAR CONFUSIONES.




                                                                                                                                                                                      5
                                                                                                                                                                                                                             6.3 Cuando su esposo o                       6.4 Cuando usted se
                                                                                                                                                                                                                             pareja se enoja con                          enoja con su esposo
                                                                                                                                                                                                                             usted, ...                                   o pareja ...




                                                                                                                                                                                     7
                                                                                                                                            EN CADA CASO ANOTE EL CÓDIGO EN LA CASILLA CORRESPONDIENTE

                                                                                                                                                                                                                                                            Sí ................ 1
                                                                                                                                                                                                                                                            No .............. 2




                                                                                                                                                                                    6
                                                                                                                                             1) ¿le deja de hablar?




                                                                                                                                                                                   (
                                                                                                                                             2) ¿discuten?

                                                                                                                                             3) ¿la(o) ofende o la(o) insulta?




                                                                                                                                                                                  8
                                                                                                                                             4) ¿golpea o avienta cosas?

                                                                                                                                             5) ¿la(o) empuja o jalonea?

                                                                                                                                             6) ¿la(o) amenaza con golpearla(o) o abandonarla(o)?




                                                                                                                                                                                 0
                                                                                                                                             7) ¿la(o) golpea o agrede físicamente?

                                                                                                                                             8) ¿generalmente no hace ni dice nada, se sale, se duerme?

                                                                                                                                             9) ¿hablan o platican?

                                                                                                                                            10) ¿generalmente no se enoja por nada?

                                                                                                                                            11) Otro
                                                                                                                                                                                                                                        ESPECIFIQUE                                   ESPECIFIQUE



                                                                                                                                            6.5 Comparando el inicio de su relación o vida en pareja                                      aumentaron? ........................................... 1
                                                                                                                                            con el momento actual, ¿usted diría que los conflictos o
                                                                                                                                                                                                                                          disminuyeron? ......................................... 2
                                                                                                                                            problemas entre ustedes …
                                                                                                                                                                                                                                          se resolvieron? ....................................... 3
                                                                                                                                                                     LEA Y CIRCULE SÓLO UN CÓDIGO
                                                                                                                                                                                                                                          se mantienen igual? ............................... 4




                                                                                                                                        14        Secciones para la mujer casada o unida
                                                                                                                                      164
                                                                 VII. RELACIÓN ACTUAL

Ahora quisiera preguntarle si ha vivido o experimentado situaciones o problemas difíciles con su esposo o pareja a lo largo
de su vida juntos y en especial en el último año (octubre de 2005 a la fecha).

                                                                  7.1 ¿Desde que inició       7.2 El que           7.3 ¿Desde             7.4 En el
                                                                  la relación con su          la(le) haya          hace cuántos           último año,
LEA PRIMERO LA PREGUNTA 7.1 Y APLÍQUELA VERTICALMENTE A TODAS     esposo o pareja,            (SITUACIÓN)          años pasa              ¿esto
   LAS SITUACIONES, DE LA 01 A LA 30, ANOTANDO EN CADA UNA LA
RESPUESTA INDICADA; DESPUÉS APLIQUE LA PREGUNTA 7.5 QUE ESTÁ      cuántas veces ...           ¿le parece ...       esto?                  ocurrió ...
AL FINAL DEL CONJUNTO DE SITUACIONES. CONTINÚE ENTONCES CON




                                                                                                                                                                     INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
  LAS PREGUNTAS 7.2, 7.3 Y 7.4 DE MANERA HORIZONTAL, PARA CADA     Una vez .............. 1   grave? ......... 1                          una vez? ...... 1
   UNA DE LAS SITUACIONES QUE EN 7.1 ANOTÓ LOS CÓDIGOS 1 Ó 2                                                         UN AÑO Y MENOS
                                                                   Varias veces ...... 2      sin impor-           DE UN AÑO, ANOTE 01.   varias
                                                                                                                      NO RECUERDA,
                                                                   Ninguna vez ....... 3      tancia? ........ 2         ANOTE 98         veces? ......... 2
                                                                                                                                          Ninguna vez .. 3
                         SITUACIÓN

1) la ha empujado o le ha jalado el pelo?




                                           $
2) la ha amarrado?

3) la ha pateado?




                                          5
4) le ha aventado algún objeto?

5) la ha golpeado con las manos




                                         7
   o con algún objeto?

6) la ha tratado de ahorcar o asfixiar?




                                        6
7) la ha agredido con cuchillo o navaja?

8) le ha disparado con un arma?




                                       (
9) la ha avergonzado, menospreciado o
   humillado (le ha dicho que es fea o la ha
   comparado con otras mujeres)?




                                      8
10) la ha ignorado, no la ha tomado en cuenta
    o no le ha brindado cariño?

11) le ha dicho que usted lo engaña?




                                     0
12) le ha hecho sentir miedo?

13) la ha amenazado con irse, dañarla, quitarle
    a los hijos o correrla?

14) la ha encerrado, le ha prohibido salir
    o que la visiten?

15) ha hecho que los hijos o parientes se pongan
    contra usted?

16) la ha vigilado o espiado?

17) la ha amenazado con algún arma (cuchillo,
    navaja, pistola o rifle)?

18) ha amenazado con matarla, matarse
    él o matar a los niños?

19) ha destruído, tirado o escondido cosas
    de usted o del hogar?

20) le ha dejado de hablar?

21) se ha enojado mucho porque no está listo el
    quehacer, porque la comida no está como él
    quiere o cree que usted no cumplió con sus
    obligaciones?

                                                                                                 Secciones para la mujer casada o unida                   15
                                                                                                                                                               165
                                                                                                                                                                                                       VII. RELACIÓN ACTUAL

                                                                                                                                                                                                           7.1 ¿Cuántas veces          7.2 ¿El que            7.3 ¿Desde                 7.4 En el
                                                                                                                                                                                                           su esposo o pareja ...      la(le) haya            hace cuántos               último año,
                                                                                                                                                                                                                                       (SITUACIÓN) le         años pasa                  ¿esto
                                                                                                                                                                                                                                       parece ...             esto?                      ocurrió ...
                                                                                                                                                                                                           Una vez .............. 1    grave? ......... 1       UN AÑO Y MENOS           una vez? ...... 1
                                                                                                                                                                                                           Varias veces ...... 2       sin impor-             DE UN AÑO, ANOTE 01.       varias
                                                                                                                                                                                                                                                                 NO RECUERDA,
                                                                                                                                                                                                           Ninguna vez ....... 3       tancia? ........ 2           ANOTE 98             veces? ......... 2




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                                                                                                                                         Ninguna vez .. 3
                                                                                                                                                                     SITUACIÓN

                                                                                                                                        22) le ha reclamado cómo gasta usted el dinero?

                                                                                                                                        23) aunque tenga dinero ha sido codo o tacaño
                                                                                                                                            con los gastos de la casa?




                                                                                                                                                                                     $
                                                                                                                                        24) no ha cumplido con dar el gasto o ha amenazado
                                                                                                                                            con no darlo?

                                                                                                                                        25) se ha gastado el dinero que se necesita para la




                                                                                                                                                                                    5
                                                                                                                                            casa?

                                                                                                                                        26) se ha adueñado o le ha quitado dinero o bienes




                                                                                                                                                                                   7
                                                                                                                                            (cosas, terrenos, etcétera)?

                                                                                                                                        27) le ha prohibido trabajar o estudiar?




                                                                                                                                                                                  6
                                                                                                                                        28) le ha exigido tener relaciones sexuales aunque
                                                                                                                                            usted no quiera?

                                                                                                                                        29) cuando tienen relaciones sexuales la ha obligado




                                                                                                                                                                                 (
                                                                                                                                            a hacer cosas que a usted no le gustan?

                                                                                                                                        30) ha usado su fuerza física para obligarla a tener
                                                                                                                                            relaciones sexuales?




                                                                                                                                                                                8
                                                                                                                                            SI EN LA PREGUNTA 7.1 TODAS LAS RESPUESTAS SON “Ninguna vez ... 3”                         PASE A 7.6 (FILTRO)


                                                                                                                                            7.5 De las agresiones anteriores ¿cuáles son las tres que más le han afectado?




                                                                                                                                                                               0
                                                                                                                                            31) Todas le han afectado por igual
                                                                                                                                            32) Ninguna                                                                                                     ANOTE LAS SITUACIONES INDICADAS

                                                                                                                                            33) No pudo decidir


                                                                                                                                            7.6 FILTRO

                                                                                                                                            – PASE A LA PREGUNTA 7.7, SI EN LA PREGUNTA 7.1 SE ANOTARON CÓDIGOS 1 Ó 2 EN ALGUNAS DE LAS SITUACIONES DE LA 01 A LA 08
                                                                                                                                              O DE LA 28 A LA 30.
                                                                                                                                            – PASE A LA PREGUNTA 7.14, SI EN 7.1 ÚNICAMENTE SE ANOTARON CÓDIGOS 1 Ó 2 EN LAS SITUACIONES DE LA 09 A LA 27.
                                                                                                                                            – PASE A LA SECCIÓN VIII, SI EN 7.1 SE ANOTARON ÚNICAMENTE CÓDIGOS 3 EN TODAS LAS SITUACIONES.

                                                                                                                                            7.7 Derivado de las agresiones de su                      7.8 ¿Cuándo fue la última vez que             7.9 ¿Cómo la atendió la autoridad a la
                                                                                                                                            esposo o pareja, ¿ha recurrido ...                        recurrió a la autoridad?                      que acudió?

                                                                                                                                                       CIRCULE LAS OPCIONES INDICADAS                                                                              CIRCULE UN SOLO CÓDIGO


                                                                                                                                                                                                                                                     La atendieron bien, la orientaron
                                                                                                                                            al ministerio público? .... 1
                                                                                                                                                                                                                                                     e informaron ....................................... 1
                                                                                                                                                                                                              MES                AÑO
                                                                                                                                            a la policía preventiva? .. 2                                                                            No hicieron nada,
                                                                                                                                                                                                                                                     no le hicieron caso ............................ 2
                                                                                                                                            a otra autoridad? ........... 3
                                                                                                                                                                                                                                                     La humillaron o la trataron mal ......... 3
                                                                                                                                            Ninguna ........................... 4       PASE A 7.12                                                  Otro                                               4
                                                                                                                                                                                                                                                                           ESPECIFIQUE



                                                                                                                                        16        Secciones para la mujer casada o unida
                                                                                                                                      166
                                                                         VII. RELACIÓN ACTUAL

7.10 ¿Una vez que acudió a la autoridad ...                        7.11 ¿Considera                       7.12 ¿Usted no acudió a la autoridad ...
                                                                   que por haberlo
            CIRCULE LAS OPCIONES INDICADAS                         denunciado, el trato de                                  CIRCULE LAS OPCIONES INDICADAS

                                                                   él hacia usted ...
                                                                                                         por miedo? .......................................................... 01
denunció a su esposo                                                    CIRCULE UN SOLO CÓDIGO
o pareja? ............................................   1                                               porque su esposo o pareja
                                                                                                         la amenazó? ....................................................... 02
detuvieron a su esposo




                                                                                                                                                                                                INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
o pareja? ............................................   2                                               por sus hijos? ..................................................... 03
emitieron la orden para                                            mejoró? ............ 1                su familia la convenció
desalojarlo de su casa? ....................             3                                               de no hacerlo? .................................................... 04
                                                                   mejoró
se separaron temporalmente? ........                     4         por un                        PASE    por vergüenza? .................................................. 05




                                                  $
                                                                                                   A
                                                                   tiempo? ............ 2
usted se fue de la casa? ..................              5                                        7.13
                                                                                                         para que su familia no
                                                                   siguió igual? .... 3                  se enterara? ....................................................... 06
él se fue de la casa? .........................          6
                                                                                                         no sabía que podía denunciar




                                                 5
Usted retiró la demanda o no                                       empeoró? ........ 4                   la agresión? ........................................................ 07
siguió los trámites, porque ...............              7
                                                                                                         se trató de algo sin importancia? .................... 08




                                                7
                                                                                                         porque piensa que su esposo o pareja
                                                                                                         tiene derecho a reprenderla? ........................... 09
                                                                                                         porque no confía en las autoridades? ............. 10




                                               6
                                                                                                         porque él no va a cambiar? ............................... 11
                                                                                                         Otro ...................................................................... 12




                                              (
                       ESPECIFIQUE




7.13 ¿Debido a las agresiones de su esposo o                                7.14 Desde que están             7.15 ¿Usted cree que el maltrato que recibe de
                                                                            juntos, ¿esta manera




                                             8
pareja…                                                                                                      su esposo o pareja, inició o empeoró, debido a ...
                                                                            de reaccionar de su
                CIRCULE LAS OPCIONES INDICADAS                              esposo o pareja ante                               CIRCULE LAS OPCIONES INDICADAS
                                                                            los problemas ha...
usted tuvo que operarse? ........................... 01




                                            0
usted tuvo moretones                                                                                          problemas económicos? ............................ 01
o hinchazón? ................................................ 02             CIRCULE UN SOLO CÓDIGO
                                                                                                              la pérdida de empleo? ................................. 02
usted tuvo cortadas, quemaduras
                                                                                                              que él tenía otra relación
o pérdida de dientes? .................................. 03
                                                                            mejorado? ........... 1           amorosa? ..................................................... 03
usted tuvo hemorragias
                                                                                                              que usted tenía otra
o sangrado? ................................................. 04            empeorado? ........ 2             relación amorosa? ...................................... 04
usted tuvo fracturas? .................................. 05
                                                                            siempre ha                        que usted comenzó a trabajar? ................. 05
usted tuvo un aborto                                                        sido igual? ........... 3         que recibe apoyo
o parto prematuro? ..................................... 06
                                                                                                              de Oportunidades? ...................................... 06
usted tuvo ardor o sangrado
                                                                                                              que llegó a vivir con ustedes
vaginal? ......................................................... 07
                                                                                                              alguna persona? ........................................... 07
usted tuvo desmayos? ................................ 08
                                                                                                              que usted no se embarazó? ....................... 08
no puede mover alguna
                                                                                                              que usted se embarazó? ............................ 09
parte de su cuerpo? ..................................... 09
                                                                                                              el nacimiento de un hijo? ............................ 10
resultó lesionado un familiar? .................... 10
                                                                                                              que él toma o tomaba? ................................ 11
falleció algún miembro
del hogar? ..................................................... 11                                           No sabe por qué lo hace .............................. 12
No le ha pasado nada .................................. 12                                                    Por ninguna razón ........................................ 13
Otro                                                             13                                           Otro                                                                 14
                            ESPECIFIQUE                                                                                                      ESPECIFIQUE



                                                                                                                Secciones para la mujer casada o unida                                17
                                                                                                                                                                                          167
                                                                                                                                                                                                                       VII. RELACIÓN ACTUAL

                                                                                                                                        7.16 Cuando hay problemas con su esposo                                     7.17 ¿Debido a los problemas con                                    7.18 ¿Los problemas con su esposo
                                                                                                                                        o pareja, ¿platica o pide ayuda a ...                                       su esposo o pareja, usted ha …                                      o pareja le provocaron …

                                                                                                                                                         CIRCULE LAS OPCIONES INDICADAS                                      CIRCULE LAS OPCIONES INDICADAS                                      CIRCULE LAS OPCIONES INDICADAS




                                                                                                                                        familiares? ...............................................        1        dejado de comer? ......................                 1           pérdida o aumento del apetito? .                       1
                                                                                                                                        sus amistades? ......................................              2        dejado de salir? ..........................             2




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                                                                                                                                                                        problemas nerviosos? ...............                   2
                                                                                                                                        un sicólogo, trabajador social? .............                      3        dejado de ver a sus familiares                                      angustia o miedo? ......................               3
                                                                                                                                        un sacerdote o instancias religiosas? .                            4        o amistades? ..............................             3
                                                                                                                                                                                                                                                                                        tristeza, aflicción o depresión? .                     4
                                                                                                                                        al DIF? .......................................................    5        dejado de ir al médico? .............                   4
                                                                                                                                                                                                                                                                                        insomnio? ....................................         5




                                                                                                                                                                                          $
                                                                                                                                        alguna organización no gubernamental                                        dejado de trabajar o estudiar? .                        5
                                                                                                                                        (ONG)? ......................................................      6                                                                            No le ha pasado nada .................                 6
                                                                                                                                                                                                                    perdido dinero o propiedades?                           6
                                                                                                                                        algún refugio para mujeres                                                                                                                      Otro ...............................................   7




                                                                                                                                                                                         5
                                                                                                                                        maltratadas? ...........................................           7        No ha pasado nada ....................                  7

                                                                                                                                        No platica ni pide ayuda ..........................                8        Otro ..............................................     8




                                                                                                                                                                                        7
                                                                                                                                        Otro ...........................................................   9


                                                                                                                                        7.19 ¿Ha tenido que                           7.20 ¿A dónde fue?                                                           7.21 Por los conflictos                         7.22 ¿Ha intentado




                                                                                                                                                                                       6
                                                                                                                                        recibir atención médica                                                                                                    con su esposo o pareja,                         hacerlo?
                                                                                                                                        por los problemas con                                        CIRCULE LAS OPCIONES INDICADAS                                ¿alguna vez ha pensado
                                                                                                                                        su esposo o pareja?                                                                                                        en quitarse la vida?                             CIRCULE UN SOLO CÓDIGO




                                                                                                                                                                                      (
                                                                                                                                                                                        Médico particular .................................... 1
                                                                                                                                              CIRCULE UN SOLO CÓDIGO                                                                                                   CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                        Cruz Roja ................................................ 2
                                                                                                                                                                                        IMSS ........................................................ 3                                                                     Sí ..... 1




                                                                                                                                                                                     8
                                                                                                                                                                                        ISSSTE ................................................... 4
                                                                                                                                            Sí ..... 1                                                                                                               Sí ..... 1                                             No ... 2
                                                                                                                                                                                        Salubridad .............................................. 5
                                                                                                                                            No ... 2              PASE A 7.21           Otro ......................................................... 6             No ... 2                 PASE A 7.23




                                                                                                                                        7.23 ¿A raíz de los problemas y conflictos
                                                                                                                                        con su pareja o esposo ...

                                                                                                                                                              CIRCULE UN SOLO CÓDIGO


                                                                                                                                            piensa separarse o terminar
                                                                                                                                                                                    0
                                                                                                                                            la relación? ............................................ 1
                                                                                                                                                                                                                       7.24 ¿Usted no se ha separado o no quiere separarse de su esposo o
                                                                                                                                                                                                                       pareja porque …

                                                                                                                                                                                                                                                             CIRCULE LAS OPCIONES INDICADAS



                                                                                                                                                                                                                        los problemas no son tan graves como para hacerlo? ........................

                                                                                                                                                                                                                        no tiene a dónde irse a vivir y él no quiere salirse de la casa? ............
                                                                                                                                                                                                                                                                                                                                             01

                                                                                                                                                                                                                                                                                                                                             02
                                                                                                                                            se separó un tiempo, pero
                                                                                                                                            volvió con él? ......................................... 2                  no tiene cómo sostenerse económicamente? ......................................                                      03

                                                                                                                                            No puede separarse ............................. 3                          sus hijos están pequeños? ......................................................................                     04

                                                                                                                                                                                                                        la tiene amenazada con quitarle a sus hijos y/o la casa? ....................                                        05
                                                                                                                                            No lo piensa o no quiere
                                                                                                                                            separarse ............................................... 4                 tiene miedo de lo que le pueda hacer a usted o a sus hijos? ..............                                           06

                                                                                                                                                                                                                        no cuenta con el apoyo de nadie y le da miedo? ...................................                                   07

                                                                                                                                                                                                                        lo quiere y/o lo necesita? ......................................................................... 08

                                                                                                                                                                                                                        una esposa debe sortear las dificultades
                                                                                                                                                                                                                        y mantenerse unida a su pareja? ............................................................                         09

                                                                                                                                                                                                                        Otro .............................................................................................................   10


                                                                                                                                       18        Secciones para la mujer casada o unida
                                                                                                                                      168
                                                                       VIII. DECISIONES

8.1 ¿Quién decide, la mayor parte de las veces,                                                                           PREGUNTE ÚNICAMENTE EN LOS CASOS
en el hogar o en su relación de pareja ...                                                                               CON RESPUESTA: “SÓLO LA ENTREVISTADA”
                                                                                                                                     (CÓDIGO 1)
ANOTE EN CADA CASILLA EL CÓDIGO INDICADO
                                                                                                                         8.2 Cuando usted decide sola (DECISIÓN),
                                                                      Sólo la entrevistada ............... 1
                                                                                                                         ¿su esposo o pareja ...
                                                                      Sólo el esposo o la pareja ..... 2                                      lo respeta o acepta? ..... 1
                                                                      Ambos .................................... 3                            discute o pelea? ............ 2




                                                                                                                                                                                               INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                      Otras personas ...................... 4                                 la maltrata? ...................... 3
                                                                      No aplica ................................. 5                           no hace ni dice nada? ... 4

 1) si usted puede trabajar o estudiar?

 2) si usted puede salir de su casa?




                                              $
 3) qué hacer con el dinero que usted gana o del que dispone?

 4) si puede comprar cosas para usted?




                                             5
 5) si puede participar en la vida social o política de su comunidad?

 6) cómo se gasta o economiza el dinero?




                                            7
 7) sobre los permisos a las hijas e hijos?

 8) cambiarse o mudarse de casa y/o ciudad?




                                           6
 9) cuándo tener relaciones sexuales?

10) si se usan anticonceptivos?




                                          (
11) quién debe usar los métodos anticonceptivos?


                                     IX. APORTES ECONÓMICOS Y DISPONIBILIDAD DE RECURSOS




                                         8
9.1 Para los gastos del hogar ¿cuánto                   9.2 ¿El ingreso del hogar ...                                                    9.3 ¿Usted cuenta con dinero
da ...                                                                                                                                   para sus cosas personales?
                                                                              CIRCULE UN SOLO CÓDIGO
   ANOTE EN CADA CASILLA EL CÓDIGO INDICADO                                                                                                    CIRCULE UN SOLO CÓDIGO




                                        0
                                                        lo maneja su esposo o pareja
                                                        y le da gasto? .................................................. 1
                 Sólo una parte ............... 1
                 Todo lo que gana .......... 2          se coloca en un fondo común y cada
                                                                                                                                                        Sí ........ 1
                 No da nada .................... 3      quien utiliza lo que necesita? ........................ 2
                 No aplica ........................ 4
                                                        su esposo o pareja le da lo que gana                                                            No ...... 2
                                                        y usted decide cómo se gasta? .................... 3
 usted (entrevistada)? ............                     cada quien maneja su ingreso? .................... 4
 su esposo o pareja? ..............                     Otro ................................................................... 5


9.4 ¿Algún(os) miembro(s) de este hogar es (son)                                                                                     9.5 ¿A nombre de quién están?
propietario(s) de ...                                                                                                                ¿A quién le pertenecen?

                                                                                                                                              Sólo entrevistada ............... 1
ANOTE EN CADA CASILLA EL CÓDIGO INDICADO
                                                                                        Sí ........ 1                                         Sólo el esposo o pareja ..... 2
                                                                                                                                              Ambos ................................ 3
                                                                                        No ....... 2                                          Otra(s) persona(s) ............ 4

1) terreno(s) o tierras de cultivo?

2) automóvil(es) o camioneta(s)?

3) ahorros?

4) la vivienda que habitan?

                                                                                                                      Secciones para la mujer casada o unida                         19
                                                                                                                                                                                         169
                                                                                                                                                                                                                 X. LIBERTAD PERSONAL

                                                                                                                                        LEA CADA UNA DE LAS OPCIONES Y ESCRIBA LA RESPUESTA INDICADA EN EL RECUADRO CORRESPONDIENTE.


                                                                                                                                        10.1 Ahora le preguntaré sobre los arreglos que hace con su esposo o pareja cuando necesita realizar
                                                                                                                                        algunas actividades

                                                                                                                                        ANOTE EN CADA CASILLA EL CÓDIGO INDICADO



                                                                                                                                        1) Para trabajar por un pago o remuneración




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                           ¿a su esposo o pareja …

                                                                                                                                        2) Si tiene que ir de compras
                                                                                                                                           ¿a su esposo o pareja …




                                                                                                                                                                                      $
                                                                                                                                        3) Si tiene o quiere visitar a sus parientes o amistades                                                                         le debe pedir permiso? ............. 1
                                                                                                                                           ¿a su esposo o pareja …
                                                                                                                                                                                                                                                                         le avisa o pide su opinión? ....... 2
                                                                                                                                        4) Si usted quiere comprar algo para usted o cambiar su arreglo                                                                  no tiene que hacer nada? .......... 3




                                                                                                                                                                                     5
                                                                                                                                           personal ¿a su esposo o pareja …                                                                                              No va sola; va con él ....................... 4
                                                                                                                                                                                                                                                                         No lo hace ........................................ 5
                                                                                                                                        5) Si usted quiere participar en alguna actividad vecinal                                                                        Otro ................................................... 6




                                                                                                                                                                                    7
                                                                                                                                           o política, ¿a su esposo o pareja …

                                                                                                                                        6) Si usted quiere hacer amistad con una persona que
                                                                                                                                           su esposo o pareja no conoce, ¿a él …




                                                                                                                                                                                   6
                                                                                                                                        7) Para votar por algún partido o candidato,
                                                                                                                                           ¿a su esposo o pareja …




                                                                                                                                                                                  (
                                                                                                                                                                                  XI. OPINIÓN SOBRE LOS ROLES MASCULINOS Y FEMENINOS




                                                                                                                                                                                 8
                                                                                                                                        11.1. Le voy a leer algunas frases, dígame SÍ cuando esté de acuerdo y NO cuando esté en desacuerdo.                                                                      Sí ........... 1
                                                                                                                                                                                                                                                                                                                  No .......... 2
                                                                                                                                                                                                  ANOTE EN CADA CASILLA EL CÓDIGO INDICADO




                                                                                                                                                                                0
                                                                                                                                            1) ¿Una buena esposa debe obedecer a su esposo en todo lo que él ordene? ...........................................................

                                                                                                                                            2) ¿Una mujer puede escoger sus amistades aunque a su esposo no le guste? ........................................................

                                                                                                                                            3) ¿El hombre debe responsabilizarse de todos los gastos de la familia? ...................................................................

                                                                                                                                            4) ¿Una mujer tiene la misma capacidad que un hombre para ganar dinero? .............................................................

                                                                                                                                            5) ¿Es obligación de la mujer tener relaciones sexuales con su esposo aunque ella no quiera? .............................

                                                                                                                                            6) ¿Cuando la mujer no cumple con sus obligaciones, el marido tiene el derecho de pegarle? ................................


                                                                                                                                        11.2. ¿Usted está de acuerdo en que ...                                            11.3 ¿Usted se considera …                                               11.4. ¿Usted ha oído
                                                                                                                                                                                                                                                                                                    hablar de la igualdad
                                                                                                                                        ANOTE EL CÓDIGO INDICADO EN CADA CASILLA                        Sí ........... 1             ANOTE EL CÓDIGO INDICADO              Sí ............ 1
                                                                                                                                                                                                                                         EN CADA CASILLA
                                                                                                                                                                                                                                                                                                    entre mujeres y
                                                                                                                                                                                                        No .......... 2                                                    No ........... 2         hombres?
                                                                                                                                       1) las mujeres y los hombres tengan los mismos
                                                                                                                                          derechos para tomar sus decisiones? .............                                                                                                           CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                                           1) valiosa? ........................................
                                                                                                                                       2) las mujeres y los hombres tengan
                                                                                                                                          la misma libertad? ................................................
                                                                                                                                                                                                                           2) atractiva? .....................................
                                                                                                                                       3) las mujeres tengan el derecho a defenderse
                                                                                                                                          y denunciar cualquier maltrato o agresión? ..                                                                                                                         Sí ........ 1
                                                                                                                                                                                                                           3) con derechos? .............................
                                                                                                                                       4) las mujeres tengan la posibilidad de decidir
                                                                                                                                          sobre su propia vida? ..........................................
                                                                                                                                                                                                                                                                                                                No ...... 2
                                                                                                                                                                                                                           4) que expresa sus opiniones? ......
                                                                                                                                       5) las mujeres tengan el derecho a vivir una
                                                                                                                                          vida libre de violencia? ........................................

                                                                                                                                       20        Secciones para la mujer casada o unida
                                                                                                                                      170
                                                                XII. RECURSOS SOCIALES

12.1 Cuando necesita dinero, sin                         12.2 ¿Acostumbra usted ...
contar a su esposo o pareja, ¿recurre
a sus ...                                                                                             CIRCULE LAS OPCIONES INDICADAS


        CIRCULE LAS OPCIONES INDICADAS                   salir con amigas a divertirse? ............................................................................           1

                                                         platicar con vecinas? ..........................................................................................      2

amigas? .......................................... 1     reunirse con familiares? .....................................................................................        3




                                                                                                                                                                                             INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
vecinas? ......................................... 2     asistir a reuniones religiosas? ...........................................................................           4
familiares? ...................................... 3
                                                         asistir a reuniones de colonos o de organizaciones? .....................................                             5
No pide dinero ................................ 4




                                             $
                                                         practicar deportes en equipo? ...........................................................................             6
Otro                                              5
                    ESPECIFIQUE                          Otro ____________________________________________________________                                                     7
                                                                                                                  ESPECIFIQUE




                                            5
              VERIFIQUE LA RESPUESTA EN LA PREGUNTA 2.4 DE LA SECCIÓN II Y SI LA MUJER ELEGIDA TIENE 60 AÑOS O
                           MÁS APLIQUE LA SECCIÓN XIII, EN CASO CONTRARIO PASE A LA SECCIÓN XIV.




                                           7
                                                         XIII. MUJERES DE 60 AÑOS O MÁS




                                          6
13.1 ¿Usted depende                                      13.2 ¿Usted a veces ayuda                                         13.3 ¿Mantiene económicamente a
económicamente de su(s) …                                económicamente, le da dinero o le                                 su(s) …
                                                         paga alguna cosa a su(s) …
        CIRCULE LAS OPCIONES INDICADAS                                                                                               CIRCULE LAS OPCIONES INDICADAS




                                         (
                                                                    CIRCULE LAS OPCIONES INDICADAS
esposo o pareja? ........................... 1
                                                         hija(s) o hijo(s)? ............................. 1                esposo o pareja? ........................... 1
hija(s) o hijo(s)? ............................. 2




                                        8
                                                         nieta(s) o nieto(s)? ......................... 2                  hija(s) o hijo(s)? ............................. 2
nieta(s) o nieto(s)? ......................... 3
                                                         No apoya a nadie ........................... 3                    nieta(s) o nieto(s)? ......................... 3
No depende de nadie ..................... 4




                                       0
                                                         Otro .................................................. 4         No mantiene a nadie ...................... 4
Otro                                              5
                    ESPECIFIQUE                                                                                            Otro .................................................. 5



13.4 ¿Usted cuida a sus nietos …                        13.5 ¿Es responsable de sus nietos                                 13.6 ¿Tiene alguna enfermedad o
                                                        porque sus padres …                                                impedimento que no le permiten
            CIRCULE UN SOLO CÓDIGO                                                                                         desplazarse sola?
                                                                       CIRCULE UN SOLO CÓDIGO

                                                                                                                                         CIRCULE UN SOLO CÓDIGO
todos los días? ................ 1                      trabajan y viven en Estados Unidos? .. 1

algún día de la semana? 2                               trabajan y viven en otro lugar                                                         Sí .......... 1
                                                        del país? ................................................ 2
de vez en cuando? .......... 3            PASE A 13.6                                                                                          No ....... 2
                                                        trabajan todo el día? ............................. 3
No los cuida ..................... 4
                                                        murieron? .............................................. 4
No tiene nietos ................. 5
                                                        Otro ......................................................... 5




                                                                                                                  Secciones para la mujer casada o unida                           21
                                                                                                                                                                                       171
                                                                                                                                                                                                 XIII. MUJERES DE 60 AÑOS O MÁS

                                                                                                                                                                                                                                                              Sí ................... 1
                                                                                                                                                ANOTE LA RESPUESTA INDICADA EN CADA UNA DE LAS CASILLAS                                                       No .................. 2
                                                                                                                                                                                                                                                              No aplica ....... 3

                                                                                                                                            13.7 Dígame si usted pasa o ha pasado por alguna de las siguientes                              Hija(s)     Hijo(s)                 Nieta(s) o           Otro
                                                                                                                                            situaciones con sus familiares cercanos o con quienes vive:                                                                          nieto(s)

                                                                                                                                              1) ¿Le dejan de hablar o no le hablan?




INEGI. Encuesta Nacional sobre la Dinámica de las Relaciones en los Hogares 2006 ENDIREH Tabulados básicos Estados Unidos Mexicanos
                                                                                                                                              2) ¿La dejan sola, la abandonan?

                                                                                                                                              3) ¿Le gritan, la insultan, la ofenden?

                                                                                                                                              4) ¿No le dan dinero?




                                                                                                                                                                                      $
                                                                                                                                              5) ¿La han amenazado con correrla o sacarla de su casa?

                                                                                                                                              6) ¿La han lastimado o golpeado?




                                                                                                                                                                                     5
                                                                                                                                              7) ¿Le han quitado su dinero o alguna pertenencia?




                                                                                                                                                                                    7
                                                                                                                                              8) ¿Le han dicho o le hacen sentir que es un estorbo?

                                                                                                                                              9) ¿No la atienden cuando se enferma o no le compran




                                                                                                                                                                                   6
                                                                                                                                                 sus medicamentos?

                                                                                                                                            10) ¿Le piden que haga quehaceres que no puede hacer
                                                                                                                                                o que le cuestan trabajo?




                                                                                                                                                                                  (
                                                                                                                                            11) ¿No la apoyan o ayudan cuando lo necesita?




                                                                                                                                                                                 8
                                                                                                                                                                                                         XIV. ENTREVISTADORA

                                                                                                                                            14.1 ¿Dónde se levantó la entrevista?                14.2 ¿La entrevista a la mujer elegida                 14.3 Durante la entrevista, ¿la mujer
                                                                                                                                                                                                 se ...                                                 elegida …




                                                                                                                                                                                0
                                                                                                                                                         CIRCULE UN SOLO CÓDIGO
                                                                                                                                                                                                              CIRCULE UN SOLO CÓDIGO                                  CIRCULE UN SOLO CÓDIGO


                                                                                                                                                                                                 realizó en el primer intento? ............ 1           estaba sola? ...................................... 1
                                                                                                                                            Dentro de la vivienda ......................... 1
                                                                                                                                                                                                 tuvo que regresar según                                estaba presente su esposo? ........... 2
                                                                                                                                            Fuera de la vivienda ........................... 2   indicaciones? .................................... 2
                                                                                                                                                                                                                                                        estaban sus hijos? ........................... 3
                                                                                                                                            En otro lugar                                   3    Otro                                              3    estaban otros familiares
                                                                                                                                                                                                                       ESPECIFIQUE
                                                                                                                                                                      ESPECIFIQUE                                                                       o personas? ...................................... 4


                                                                                                                                            VERIFIQUE LA PREGUNTA 2.11 DE LA SECCIÓN II: SI HAY MUJER SOLTERA ELEGIDA APLIQUE EL MÓDULO DE MUJERES SOLTERAS.




                                                                                                                                                   Secciones para la mujer casada o unida
                                                                                                                                      172
