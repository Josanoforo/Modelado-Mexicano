# Método: extracción fiel de especificación humana

## Qué mide

La proporción ponderada de **delitos personales no denunciados** cuya **razón
principal** declarada (`BP1_23`, ENVIPE 2025, delitos de 2024) es miedo o
desconfianza.

## Unidad de observación — declarada, porque cambia el denominador

**Escala:** proporción en `[0,1]`; **más alto = más peso del miedo/desconfianza
como razón principal**. Nunca porcentaje, nunca puntos porcentuales.

## Incertidumbre de diseño

## Guardias que PARAN (no arreglan)

`NO-ESTIMABLE-COLUMNA-AUSENTE:<col>` · `NO-ESTIMABLE-COLUMNA-VACIA:<col>` ·
`NO-ESTIMABLE-UNIVERSO-VACIO` · `NO-ESTIMABLE-DISENO-INCOMPLETO`.
Los `BP1_23` en blanco pese a `BP1_20 = 2` **no se imputan a cero**: se cuentan
aparte y quedan fuera de todo universo.
