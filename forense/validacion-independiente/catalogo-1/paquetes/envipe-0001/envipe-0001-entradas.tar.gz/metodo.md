# Método: extracción fiel de especificación humana

## Qué mide

La proporción ponderada de **delitos personales no denunciados** cuya **razón
principal** declarada (`BP1_23`, ENVIPE 2025, delitos de 2024) es miedo o
desconfianza.

## Unidad de observación — declarada, porque cambia el denominador

| universo | unidad | filtro | ponderador |
|---|---|---|---|
| **`U1` (PRIMARIO)** | **delito** (`ID_DEL`, tabla `tmod_vic`) | `BPCOD ∈ {05..15}` · `BP1_20 = 2` · `BP1_23 ∈ {01..08}` | `FAC_DEL` |
| `U3` | delito | idem, con `BP1_23 ∈ {01..09, 99}` | `FAC_DEL` |
| `U4` | **persona** (`ID_PER`, tabla `tper_vic2`) | persona con ≥1 delito en `U1`; colapso GEN1 (`máx`) | `FAC_ELE` |

`U2` de la sellada no se emite como estimación propia: sus dos piezas
(`N-BP1-23-09` y `P-OTRA-U3`) lo determinan sin ambigüedad.

## Codificación — dos, la primaria NO es la de GEN1

| | `= 1` | `= 0` |
|---|---|---|
| **`C1` (PRIMARIA)** — sólo los códigos cuyo texto literal dice «miedo» o «desconfianza» | `01`, `02`, `06` | `03`, `04`, `05`, `07`, `08` |
| `C2` (secundaria declarada) — partición GEN1, añade «actitud hostil de la autoridad» | `01`, `02`, `06`, `08` | `03`, `04`, `05`, `07` |

**Escala:** proporción en `[0,1]`; **más alto = más peso del miedo/desconfianza
como razón principal**. Nunca porcentaje, nunca puntos porcentuales.

## Incertidumbre de diseño

`EST_DIS` (001–607) y `UPM_DIS` están declarados en el descriptor de ambas
tablas: la varianza de diseño **sí** es identificable aquí (a diferencia de lo
que `FP-201` declaró para la corrida GEN1). Bootstrap de `UPM_DIS` con
reemplazo dentro de `EST_DIS`, 2000 réplicas, `numpy.PCG64`, semilla
`20260909`, percentiles 2.5/97.5. Un estrato con **una sola UPM** se
re-muestrea a sí mismo (varianza cero), se cuenta, y si hay alguno el
`METODO-IC` sale `IC-CON-ESTRATOS-DE-UPM-UNICA` — el IC se lee como **límite
inferior de la anchura verdadera**, no como IC exacto.

## Guardias que PARAN (no arreglan)

`NO-ESTIMABLE-COLUMNA-AUSENTE:<col>` · `NO-ESTIMABLE-COLUMNA-VACIA:<col>` ·
`NO-ESTIMABLE-UNIVERSO-VACIO` · `NO-ESTIMABLE-DISENO-INCOMPLETO`.
Los `BP1_23` en blanco pese a `BP1_20 = 2` **no se imputan a cero**: se cuentan
aparte y quedan fuera de todo universo.

