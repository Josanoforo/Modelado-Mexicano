`0` = No tiene · `1` = Sí tiene. `C_AFORE` ya es dicotómica: **no se recodifica**. Si el soporte observado no
es `⊆ {0,1}`, o trae nulos, el punto sale `NO-ESTIMABLE-CODIGO-FUERA-DE-MAPA`
y la spec **no** decide sobre la marcha qué hacer con el código nuevo.

---


Hogares: **todas** las filas de `TCONCENTRADORA.csv`, llave
`FOLIO + VIV_SEL + HOGAR`, **sin filtro adicional** — la regla no declara
ninguno. Entran las filas con `FAC_HOG` finito y `> 0`.

### 2.2 · Estimando

`A-P` = proporción ponderada de hogares con `C_AFORE == 1`:
`p = Σ(w·d) / Σ(w)`, `w = FAC_HOG`, `d = C_AFORE`, sumas en orden fijo de
llave. **DESCRIPTIVO.** El complemento `A-P-COMPLEMENTO` se cuenta
directamente sobre `d == 0`, **nunca** como `1 − p` — si los dos no suman 1
dentro de la tolerancia, hay filas fuera del mapa y el `RESULT`
`A-SUMA-UNO` lo dice.


`EDIS` y `UPM_DIS` **están en `TCONCENTRADORA.csv`** (§1.3):
   hay diseño que usar y esta corrida lo usa. Bootstrap de `UPM_DIS` con
   reemplazo **dentro de** `EDIS`, conservando el número de UPM por estrato,
   2 000 réplicas, `numpy.PCG64`, semilla `20260915`, percentiles 2.5/97.5.
2. **`EDIS`/`UPM_DIS` como llaves de texto opacas.** Cadena cruda, `dtype=str`.
   Nunca a entero, nunca re-rellenadas al ancho del descriptor: normalizarlas
   parte o fusiona estratos en silencio. El perfil de anchos sale como
   `RESULT` de texto.
3. **Estrato con UPM única no se colapsa ni se descarta.** Se re-muestrea a
   sí mismo (aporta varianza cero); si el conteo es `> 0`, `A-METODO-IC` sale
   `IC-CON-ESTRATOS-DE-UPM-UNICA` y el IC se lee como **límite inferior** de
   la anchura verdadera. Colapsar estratos es una decisión de diseño que esta
   spec no está autorizada a tomar.
4. **`FAC_HOG` se toma de `TCONCENTRADORA.csv`.** Declarado como decisión, no
   como detalle de implementación (§1.3). `THOGAR.csv` **no se abre**.
5. **La rama de robustez es secundaria y va rotulada.** `B-P` sobre
   `H_PPAL == 1` (hogar principal) es **sensibilidad de universo**, no el
   punto adoptable; `B-DELTA-VS-A` sale con signo.

