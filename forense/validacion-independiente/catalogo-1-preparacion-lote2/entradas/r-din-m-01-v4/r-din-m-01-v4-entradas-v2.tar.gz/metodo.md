# Método: extracción fiel de especificación humana

`codificacion-R-v1_2.tsv`, sucesora registral de v1.1 que conserva el estimando y explicita reservas: payload `ennvih1_2002_hogar_dta`,

codificación `y=1 si cr27=='1' (Si); y=0 si=='3' (No); 7 y 8 (no sabe / no responde) fuera`, ponderador `fac_3b@ehh02w_all/ehh02w_b3b.dta[folio+ls]`, estrato

`DISENO-APROXIMADO:CONSTANTE (un solo estrato: el estrato de diseno real -alto/medio/bajo, 14 indicadores de la ENE 2001- NO se publica en el microdato, ver ennvih_diseno/ennvih-1_muestra.pdf p.3; y `ent` no existe en ninguna de las dos tablas que esta fila nombra)` y UPM `DISENO-APROXIMADO:folio (hogar; la UPM real es un conglomerado de viviendas y NO se publica: grep -i upm sobre guiausuariov1.pdf, doc/ehh02cb_bc.pdf y doc/eloc02cb_bcc.pdf da 0 aciertos en los tres)`. Ninguno de esos campos se elige en la corrida.

Este sucesor técnico no añade una medición: hereda el conteo único de la cadena desde `CALC-R-DIN-M-01-v2`, sin sumar `-v3` ni `-v4`, cuyo objeto firmado es la medición R de `DIN-M-01`.
