# Método: extracción fiel de especificación humana

## Qué mide

**Estimador de RAZÓN**, no proporción de un binario:

`A-R = Σ_h w_h·(horas de cuidado de mujeres 40+ del hogar) / Σ_h w_h·(horas de cuidado totales del hogar)`

| | |
|---|---|
| unidad | **HOGAR** (`LLAVEHOG`) |
| horas | `CUID_ESP_INT_HOG_CON_CP + CUID_INT_0A5_CON_CP + CUID_INT_6A14_CON_CP + CUID_INT_60MAS_CON_CP`, en `tvar_crea.csv` |
| mujer 40+ | `SEXO == '2'` ∧ `EDAD >= 40` |
| ponderador | `FAC_HOG` **de `tsdem.csv`**, unido por `LLAVEHOG` |
| diseño | `EST_DIS`/`UPM_DIS` de `tvar_crea.csv`, verificados constantes dentro del hogar |

`CUID_INT_15A59` **queda fuera** (no tiene variante `CON_CP` en el FD);
`C-P-RESIDUO-15A59` mide su peso. La rama `SIN_CP` sale como
`C-P-SIN-CP` con delta con signo. Ninguna de las dos se elige sobre la marcha.
Hogares sin carga aportan `0/0` y **no se excluyen**: excluirlos cambiaría la
pregunta.

## Diseño

Conglomerado = `(EST_DIS, UPM_DIS)` del hogar, **verificado constante dentro
de `LLAVEHOG`** antes de usarlo (`G-DISENO-CONSTANTE-EN-HOGAR`). Se
re-muestrean **UPM con reemplazo dentro de `EST_DIS`**, y en cada réplica se
recalcula `Σw·num / Σw·den` — **numerador y denominador de la misma réplica**.
2 000 réplicas, `numpy.PCG64`, semilla `20260915`, percentiles 2.5/97.5.
`EST_DIS`/`UPM_DIS` como **cadena cruda opaca**. Estrato con UPM única se
re-muestrea a sí mismo, no se colapsa ni se descarta; si el conteo es `> 0`,
`A-METODO-IC = IC-CON-ESTRATOS-DE-UPM-UNICA` y el IC se lee como **límite
inferior**.

   `G-FAC-HOG-TSDEM-IGUAL-THOGAR` compara, hogar por hogar, el `FAC_HOG` de
   `tsdem.csv` contra el de `thogar.csv`. `IGUAL` / `DIFIERE:<n_hogares>`.
   Si difieren, la elección de archivo **cambia la cifra** y eso deja de ser
   un detalle de implementación para volverse una decisión de mesa: el punto
   se emite igualmente, con la marca.
