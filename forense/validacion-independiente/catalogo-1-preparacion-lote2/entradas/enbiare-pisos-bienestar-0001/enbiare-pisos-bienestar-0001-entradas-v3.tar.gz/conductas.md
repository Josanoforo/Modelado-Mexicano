|---|---|---|
| SATISFACCION-VIDA | PA1 «qué tan satisfecho(a) se encuentra actualmente con su vida» 0–10 | media |
| ESCALERA-CANTRIL | PA5 «¿En qué escalón siente que su vida se ubica actualmente?» 0–10 | media |
| DEPRESION-CESD7 | PD2_1–PD2_7 (0–3), PD2_6 invertido | ≥ 9 (18–59) / ≥ 5 (60+) → 1 |
| ANSIEDAD-GAD2 | PD3_1, PD3_2 (0–3) | suma ≥ 3 → 1 |
| CONFIANZA-MAYORIA-GENTE | PB1_01 «¿cuánto confía en la mayoría de la gente?» 0–10 | media |
| CONFIANZA-GENTE-CONOCIDA | PB1_02 | media |
| CONFIANZA-POLICIA-MUNICIPAL | PB1_04 | media |
| CONFIANZA-PARTIDOS | PB1_11 | media |
| CUENTA-APOYO-FAMILIA | PB2_1 «¿…siempre contará con la ayuda de personas de su familia?» | 1 → 1; 2, 3 («no tiene familia») → 0 |
| CUENTA-APOYO-AMISTADES | PB2_2 | ídem |
| TIENE-RELIGION | PG6 «¿Usted tiene una religión?» | 1 / 2 |
| ASISTE-SERVICIO-RELIGIOSO | PG7 «¿Acostumbra asistir a su iglesia, templo o servicio religioso?» | 1 → 1; 2 → 0; PG6 = 2 (blanco por secuencia) → 0 |

Cortes CESD-7 (≥ 9 en adultos, ≥ 5 en 60+): los de la validación del CESD-7 que usa el
INSP para ENSANUT (Salinas-Rodríguez et al., Salud Pública Mex 2013/2014), fijados aquí,
antes del dato, e idénticos en ENSANUT y ENBIARE. GAD-2 ≥ 3: corte de Kroenke et al.
