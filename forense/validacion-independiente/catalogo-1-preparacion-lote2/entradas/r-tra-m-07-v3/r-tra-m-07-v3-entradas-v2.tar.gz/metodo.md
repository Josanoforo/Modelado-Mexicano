# Método: extracción fiel de especificación humana

`codificacion-R-v1_2.tsv`, sucesora registral de v1.1 que conserva el estimando y explicita reservas: payload `encig2021_csv`,

codificación `y=1 si P8_3_1=='1' (Si); y=0 si=='2' (No); 9 (No sabe / no responde) fuera`, ponderador `FAC_P18`, estrato

`EST_DIS` y UPM `UPM_DIS`. Ninguno de esos campos se elige en la corrida.

Este sucesor técnico no añade una medición: hereda el conteo único de la cadena desde `CALC-R-TRA-M-07-v2`, cuyo objeto firmado es la medición R de `TRA-M-07`.
